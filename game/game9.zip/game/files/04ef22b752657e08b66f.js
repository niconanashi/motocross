function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      var Vector2 = require("./Vector2");

      var Size2 = require("./Size2");
      /**
       * AABBクラス。
       */


      var AABB = function () {
        function AABB() {
          this.origin = new Vector2();
          this.extent = new Size2();
        }

        return AABB;
      }();

      module.exports = AABB;
    }, {
      "./Size2": 21,
      "./Vector2": 24
    }],
    2: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var Skeleton = require("./Skeleton");

      var Attachment = require("./Attachment");

      var CellAttachment = require("./CellAttachment");

      var FinalizedCell = require("./FinalizedCell");

      var BoneCellCollider = require("./BoneCellCollider");

      var CircleCollider = require("./CircleCollider");

      var BoxVolume = require("./BoxVolume");

      var CircleVolume = require("./CircleVolume");

      var AttrId = require("./AttrId");

      var g_flipHMatrix = new g.PlainMatrix(0, 0, -1, 1, 0);
      var g_flipVMatrix = new g.PlainMatrix(0, 0, 1, -1, 0);
      /*
       * アニメーションフレームカウンタを適切な範囲に調整する。
       *
       * loop===falseの時:
       * cntrが０より小さければ0を、frameCount-1以上であればframeCount-1を返す。
       *
       * loop===trueの時:
       * cntrが時計の針のように[0,frameCount]で一周し循環するように調整されたものを返す。
       *
       * @param cntr アニメーションフレームカウンタ
       * @param frameCount アニメーションのフレーム数
       * @param loop ループ再生するアニメーションならtrueを与える
       */

      function adjustCounter(cntr, frameCount, loop) {
        if (loop) {
          while (cntr >= frameCount) {
            cntr -= frameCount;
          }

          while (cntr < 0) {
            cntr += frameCount;
          }
        } else {
          if (cntr < 0) {
            cntr = 0;
          } else if (cntr > frameCount - 1) {
            cntr = frameCount - 1;
          }
        }

        return cntr;
      }

      function setupColliderForCell(info, bone) {
        var collider;

        switch (info.boundType) {
          case "aabb":
          case "box":
            collider = new BoneCellCollider(bone.name, info.boundType === "aabb");
            break;

          default:
            g.game.logger.warn("Invalid type combination: " + info.geometryType + ", " + info.boundType);
            break;
        }

        return collider;
      }

      function setupColliderForCircle(info, bone) {
        var collider;

        switch (info.boundType) {
          case "aabb":
          case "circle":
            collider = new CircleCollider(bone.name, info.boundType === "aabb", info.scaleOption);
            break;

          default:
            g.game.logger.warn("Invalid type combination: " + info.geometryType + ", " + info.boundType);
            break;
        }

        return collider;
      } // 全てのgeometoryTypeと boundtypeの組み合わせが利用可能 というわけ**ではない**


      function setupCollider(bones, actor) {
        bones.forEach(function (bone) {
          if (!bone.colliderInfos) {
            return;
          }

          bone.colliderInfos.forEach(function (info) {
            var collider;

            switch (info.geometryType) {
              case "cell":
                collider = setupColliderForCell(info, bone);
                break;

              case "circle":
                collider = setupColliderForCircle(info, bone);
                break;

              case "box":
                g.game.logger.warn("Not implemented geometory type " + info.geometryType);
                break;

              default:
                g.game.logger.warn("Unknown geometory type " + info.geometryType);
                break;
            }

            if (collider) {
              actor.addCollider(collider);
            }
          });
        });
      }

      function getInverse(width, height, scaleX, scaleY, angle, x, y) {
        var m = new g.PlainMatrix();
        var r = angle * Math.PI / 180;

        var _cos = Math.cos(r);

        var _sin = Math.sin(r);

        var a = _cos / scaleX;
        var b = _sin / scaleY;
        var c = _sin / scaleX;
        var d = _cos / scaleY;
        var w = width / 2;
        var h = height / 2;
        m._matrix[0] = a;
        m._matrix[1] = -b;
        m._matrix[2] = c;
        m._matrix[3] = d;
        m._matrix[4] = -a * (w + x) - c * (h + y) + w;
        m._matrix[5] = b * (w + x) - d * (h + y) + h;
        return m;
      }
      /**
       * ボーンベースのアニメーションを描画するエンティティ。
       */


      var Actor = function (_super) {
        __extends(Actor, _super);
        /**
         * 各種パラメータを指定して `Actor` のインスタンスを生成する。
         */


        function Actor(param) {
          var _this = _super.call(this, param) || this; // resource


          _this.resource = param.resource; // skeleton

          var boneSet = _this.resource.getBoneSetByName(param.boneSetName);

          _this.skeleton = new Skeleton(boneSet.bones, function () {
            return _this.getMatrix();
          }); // collider

          _this.colliders = [];
          setupCollider(boneSet.bones, _this); // skin

          _this.skins = {};

          for (var i = 0; i < param.skinNames.length; i = i + 1 | 0) {
            var name_1 = param.skinNames[i];
            _this.skins[name_1] = _this.resource.getSkinByName(name_1);
          } // animation


          _this.animation = _this.resource.getAnimationByName(param.animationName); // TODO: アニメーションリソースから大きさを導き出す方法を考える

          _this.width = param.width;
          _this.height = param.height; // and others

          _this._cntr = 0;
          _this._nextCntr = 0;
          _this._elapse = 0;
          _this.pause = false;
          _this.loop = true;
          _this.playSpeed = param.playSpeed !== undefined && param.playSpeed !== null ? param.playSpeed : 1.0;
          _this.nullVisible = false;
          _this.boneCoordsVisible = false;
          _this.colliderVisible = false;
          return _this;
        }
        /**
         * コライダーを追加する。
         *
         * @param 追加されるコライダー
         */


        Actor.prototype.addCollider = function (collider) {
          // TODO: アタッチの成否を扱うべきか検討
          collider.onAttached(this);
          this.colliders.push(collider);
        };
        /**
         * コライダーを削除する。
         *
         * @param collider 削除されるコライダー
         */


        Actor.prototype.removeCollider = function (collider) {
          var index = this.colliders.indexOf(collider);

          if (index !== -1) {
            this.colliders.splice(index, 1);
          }
        };
        /**
         * スキンを追加する。
         *
         * 同じ名前を持つスキンがすでにActor内にあるとき、上書きされる。
         *
         * @param skins Actorに追加されるスキンの配列
         */


        Actor.prototype.setSkins = function (skins) {
          for (var i = 0; i < skins.length; i = i + 1 | 0) {
            var skin = skins[i];
            this.skins[skin.name] = skin;
          }
        };
        /**
         * アニメーションの計算を行う。
         *
         * フレームカウンタがインクリメントされ、アニメーションカーブに基づいた各種プロパティの計算を行います。
         */


        Actor.prototype.calc = function () {
          if (this.pause) {
            return;
          }

          var anime = this.animation;

          if (anime === undefined) {
            return;
          }

          if (this._elapse !== 0) {
            this.skeleton._handleUserEvent(this._cntr, this._elapse, anime);
          } // Set current frame counter


          this._cntr = this._nextCntr; // Update posture with animation

          this.skeleton.update(this._cntr, anime);

          if (!this.loop && (this._cntr === this.animation.frameCount - 1 && this.playSpeed >= 0 || this._cntr === 0 && this.playSpeed <= 0)) {
            this.ended.fire();
            this.pause = true;
          } // Update additional information around posture


          for (var i = 0; i < this.skeleton.composedCaches.length; i = i + 1 | 0) {
            var cc = this.skeleton.composedCaches[i];
            cc.finalizedCell = createFinalizedCell(cc, this.skins);
          } // Set dirty flag for colliders


          for (var i = 0; i < this.colliders.length; i = i + 1 | 0) {
            this.colliders[i].dirty = true;
          }

          this._elapse = anime.fps / this.scene.game.fps * this.playSpeed;
          var nextCntr = this._cntr + this._elapse;
          this._nextCntr = adjustCounter(nextCntr, anime.frameCount, this.loop);
        };
        /**
         * アニメーションを再生する。
         *
         * @param animationName アニメーション名
         * @param startFrame 再生開始フレーム
         * @param loopFlag 再生をループするか指定するフラグ。真の時ループ再生
         * @param playSpeed 再生速度。1.0で通常の再生速度
         */


        Actor.prototype.play = function (animationName, startFrame, loopFlag, playSpeed) {
          this.pause = false;
          this.animation = this.resource.getAnimationByName(animationName);
          this.loop = loopFlag;
          this.playSpeed = playSpeed;
          this._nextCntr = adjustCounter(startFrame, this.animation.frameCount, this.loop);
          this._cntr = this._nextCntr;
          this._elapse = 0;
        };

        Object.defineProperty(Actor.prototype, "currentFrame", {
          get: function get() {
            return this._cntr;
          },

          /**
           * 現在のアニメーション再生位置。
           */
          set: function set(frame) {
            this._nextCntr = adjustCounter(frame, this.animation.frameCount, this.loop);
            this._cntr = this._nextCntr;
            this._elapse = 0;
          },
          enumerable: true,
          configurable: true
        });
        Object.defineProperty(Actor.prototype, "ended", {
          /**
           * アニメーション再生終了イベント。
           */
          get: function get() {
            if (!this._ended) {
              this._ended = new g.Trigger();
            }

            return this._ended;
          },
          enumerable: true,
          configurable: true
        });
        /**
         * アニメーション計算ハンドラを扱うg.Triggerを取得する。
         *
         * @param boneName ボーン名
         * @param createIfNotExists? g.Triggerが存在しない時、生成するなら true を与える。省略した時 undefined
         */

        Actor.prototype.calculated = function (boneName, createIfNotExists) {
          return this.skeleton._getTrigger(boneName, createIfNotExists);
        };
        /**
         * アタッチメントを追加する。
         *
         * 返り値は追加されたアタッチメントである。
         * 第一引数に文字列を指定した時、同名のセルをスキン中から探索、それをboneNameで指定したボーンにアタッチする。
         *
         * @param attachable アタッチメントインスタンスまたは装着済みのスキン中のセルを指定する文字列(セル名)
         * @param boneName アタッチ先のボーン名
         * @param matrix? アタッチ位置を調節するマトリクス
         */


        Actor.prototype.attach = function (attachable, boneName, matrix) {
          var _this = this;

          var attachment = undefined;

          if (typeof attachable === "string") {
            var cellName_1 = attachable;
            Object.keys(this.skins).some(function (key) {
              var skin = _this.skins[key];
              var cell = skin.cells[cellName_1];

              if (cell) {
                attachment = new CellAttachment(cellName_1, skin, matrix);
              }

              return !!cell; // trueを返すとsome()を終了する
            });
          } else if (attachable instanceof Attachment) {
            attachment = attachable;
          }

          if (attachment) {
            this.skeleton.attach(attachment, boneName);
          }

          return attachment;
        };
        /**
         * アタッチメントを削除する。
         *
         * @param attachment 削除するアタッチメント。
         */


        Actor.prototype.removeAttachment = function (attachment) {
          this.skeleton.removeAttachment(attachment);
        };
        /**
         * ボーンの行列を取得する。
         *
         * @param boneName ボーン名。
         */


        Actor.prototype.getBoneMatrix = function (boneName) {
          var bones = this.skeleton.bones;

          for (var i = 0, len = bones.length; i < len; i++) {
            if (bones[i].name === boneName) {
              return this.skeleton.composedCaches[bones[i].arrayIndex].m;
            }
          }

          return undefined;
        };

        Actor.prototype.renderSelf = function (renderer, camera) {
          // E#render()から呼ばれる
          // すでに E#x, E#y で translate されている
          // # compoedCachesのソートをやめる
          //
          // ソートは最後の最後なのでなんの影響も残さないと考えていたが間違いだった
          // 例えばクリックイベントでActorの機能を使用し、それがcompsosedCachesにアクセスするとする
          // それはゲームループ(大抵はScene#update())以外のタイミングで実行される
          // そのため期待した並び(ソート済み)では *ない* データへのアクセスとなる
          //
          // ソートされた後もcomposedCachesは再利用され、その時の並びでBone#arrayIndexに応じたボーン情報を持つ
          // つまりActor#calc()の時点でcomposedCachesの各Postureは担当するボーンが変化している
          //
          // そのことでわかりにくいバグが生まれた。BoneCellColliderの参照するセルが変化した
          //
          // 単純のためここで配列を複製し、それをソートする
          var sortedComposedCaches = [].concat(this.skeleton.composedCaches);
          sortedComposedCaches.sort(function (a, b) {
            if (a.attrs[AttrId.prio] === b.attrs[AttrId.prio]) {
              // Array.prototype.sort()は不安定。安定にするために一手間加える
              // DCCツールで優先順位の指定がないとき（全て等しい時）
              // postureの配列の順に描画することを保証したい
              // そのため、prioが等しい時は配列の添字で比較する
              return a.index - b.index;
            } else {
              return a.attrs[AttrId.prio] - b.attrs[AttrId.prio];
            }
          });
          renderer.save();
          {
            // E#render()が乗算したActor#getMatrix()をキャンセルする。Postureはこのマトリクスを含んでいる
            var inv = getInverse(this.width, this.height, this.scaleX, this.scaleY, this.angle, this.x, this.y);
            renderer.transform(inv._matrix); // render myself

            this.renderPostures(sortedComposedCaches, renderer, camera); // render bone local coordinates

            if (this.boneCoordsVisible) {
              this.renderAxes(renderer);
            } // render colliders


            if (this.colliderVisible) {
              this.renderColliders(renderer);
            }
          }
          renderer.restore();
          return true;
        };

        Actor.prototype.renderAxes = function (renderer) {
          this.skeleton.composedCaches.forEach(function (cc) {
            renderer.save();
            {
              renderer.transform(cc.m._matrix);
              renderer.fillRect(0, 0, 16, 1, "#ff0000");
              renderer.fillRect(0, 0, 1, 16, "#00ff00");
            }
            renderer.restore();
          });
        };

        Actor.prototype.renderColliders = function (renderer) {
          renderer.save();
          {
            renderer.opacity(0.25);
            this.colliders.forEach(function (c) {
              var v = c.getVolume();
              if (!v) return; // Draw AABB

              var aabb = v.aabb();
              renderer.fillRect(aabb.origin.x - aabb.extent.width, aabb.origin.y - aabb.extent.height, // position
              aabb.extent.width * 2, aabb.extent.height * 2, // width, height
              "#ff0000"); // Draw Box

              if (v instanceof BoxVolume) {
                var box = v;
                renderer.save();
                {
                  renderer.transform(box.matrix._matrix);
                  renderer.fillRect(box.origin.x, box.origin.y, box.size.width, box.size.height, // width, height
                  "#00ff00");
                }
                renderer.restore();
              } else if (v instanceof CircleVolume) {
                var circle = v;
                renderer.save();
                {
                  var div = 128;

                  for (var i = 0; i < div; i++) {
                    renderer.fillRect(circle.pos.x + Math.cos(2 * Math.PI / div * i) * circle.r, circle.pos.y + Math.sin(2 * Math.PI / div * i) * circle.r, 4, 4, "#0000ff");
                  }
                }
                renderer.restore();
              }
            });
          }
          renderer.restore();
        };

        Actor.prototype.renderPostures = function (sortedComposedCaches, renderer, camera) {
          var length = sortedComposedCaches.length;

          for (var i = 0; i < length; i = i + 1 | 0) {
            var cc = sortedComposedCaches[i];

            if (!cc.attrs[AttrId.visibility]) {
              continue;
            }

            renderer.save();
            {
              renderer.opacity(this.opacity * cc.attrs[AttrId.alpha]);
              renderer.transform(cc.m._matrix); // ボーンのマトリクスを乗算

              renderer.save();
              {
                if (cc.finalizedCell) {
                  renderer.transform(cc.finalizedCell.matrix._matrix);
                }

                this.renderSelfCore(renderer, camera, cc.finalizedCell);
              }
              renderer.restore();
              cc.attachments.forEach(function (attachment) {
                attachment.render(renderer);
              });
            }
            renderer.restore();
          }
        };

        Actor.prototype.renderSelfCore = function (renderer, camera, finalizedCell) {
          // 原点に描画する。CANVAS座標系
          // +----------> x
          // |   /\
          // |  /__\
          // | /    \
          // |
          // v
          if (finalizedCell) {
            renderer.drawImage(finalizedCell.surface, finalizedCell.cell.pos.x + finalizedCell.u * finalizedCell.surface.width, finalizedCell.cell.pos.y + finalizedCell.v * finalizedCell.surface.height, finalizedCell.cell.size.width, finalizedCell.cell.size.height, 0, 0 // 転送先座標
            );
          } else if (this.nullVisible) {
            renderer.fillRect(0, 0, 16, 16, "#ff00ff");
          }
        };

        return Actor;
      }(g.E);

      function createFinalizedCell(posture, skins) {
        if (posture === undefined || posture.attrs[AttrId.cv] === undefined) {
          return undefined;
        }

        var attrs = posture.attrs;
        var skinName = attrs[AttrId.cv].skinName;
        var skin = skins[skinName];

        if (!skin) {
          return undefined;
        }

        var cell = skin.cells[attrs[AttrId.cv].cellName];

        if (!cell) {
          return undefined;
        } // セル中心位置


        var pvtx = cell.pivot.x;
        var pvty = cell.pivot.y; // アニメーションを反映

        pvtx += attrs[AttrId.pvtx];
        pvty += attrs[AttrId.pvty]; // 正規化された値からピクセル座標系へ

        pvtx = cell.size.width * pvtx;
        pvty = cell.size.height * pvty; // セルのボーンに対する姿勢を表す行列を求める

        var m = new g.PlainMatrix();

        if (cell.rz === 0) {
          // pivot(セル中心)がセンターに来るようにマトリクスを操作
          // m = [pivot平行移動] x [センタリング]
          m._matrix[4] = -pvtx - cell.size.width / 2;
          m._matrix[5] = -pvty - cell.size.height / 2;
        } else {
          // NOTE: `Cell#rz`のアニメーションをサポートするならキャッシュを諦めることになる
          if (!cell.m) {
            // m = [回転] x [センタリング]
            var m_1 = new g.PlainMatrix();
            var th = Math.PI * (cell.rz / 180);
            var c = Math.cos(th);
            var s = Math.sin(th);
            var tx = -(cell.size.width / 2);
            var ty = -(cell.size.height / 2);
            m_1._matrix[0] = c;
            m_1._matrix[1] = s;
            m_1._matrix[2] = -s;
            m_1._matrix[3] = c;
            m_1._matrix[4] = c * tx - s * ty;
            m_1._matrix[5] = s * tx + c * ty;
            cell.m = m_1;
          } // pivot(セル中心)がセンターに来るようにマトリクスを操作
          // m = [pivot平行移動] x [回転] x [センタリング]


          m._matrix[4] = -pvtx;
          m._matrix[5] = -pvty;
          m.multiply(cell.m);
        }

        if (attrs[AttrId.flipH]) {
          m = g_flipHMatrix.multiplyNew(m);
        }

        if (attrs[AttrId.flipV]) {
          m = g_flipVMatrix.multiplyNew(m);
        }

        var finalizedCell = new FinalizedCell();
        finalizedCell.surface = skin.surface;
        finalizedCell.cell = cell;
        finalizedCell.u = attrs[AttrId.tu];
        finalizedCell.v = attrs[AttrId.tv];
        finalizedCell.matrix = m;
        return finalizedCell;
      }

      module.exports = Actor;
    }, {
      "./Attachment": 5,
      "./AttrId": 6,
      "./BoneCellCollider": 8,
      "./BoxVolume": 10,
      "./CellAttachment": 12,
      "./CircleCollider": 14,
      "./CircleVolume": 15,
      "./FinalizedCell": 18,
      "./Skeleton": 22
    }],
    3: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
    }, {}],
    4: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * セルアニメーションの値。
       *
       * KeyFrame<CellValue>に格納されセルアニメーション（時間とともに変化するセル）に利用される。
       */

      var CellValue = function () {
        function CellValue() {}

        return CellValue;
      }();

      exports.CellValue = CellValue;

      var IpCurve = function () {
        function IpCurve() {
          this.values = [];
        }

        return IpCurve;
      }();

      exports.IpCurve = IpCurve;

      var KeyFrame = function () {
        function KeyFrame() {}

        return KeyFrame;
      }();

      exports.KeyFrame = KeyFrame;

      var Curve = function () {
        function Curve() {
          this.attribute = "";
          this.keyFrames = [];
        }

        return Curve;
      }();

      exports.Curve = Curve;

      var CurveTie = function () {
        function CurveTie() {
          this.boneName = "";
          this.curves = [];
        }

        return CurveTie;
      }();

      exports.CurveTie = CurveTie;

      var Animation = function () {
        function Animation() {
          this.name = "";
          this.fps = 0;
          this.frameCount = 0;
          this.curveTies = {}; // key = curveTie.boneName
        }

        return Animation;
      }();

      exports.Animation = Animation;
    }, {}],
    5: [function (require, module, exports) {
      "use strict";
      /**
       * アタッチメントクラス
       */

      var Attachment = function () {
        function Attachment() {}

        return Attachment;
      }();

      module.exports = Attachment;
    }, {}],
    6: [function (require, module, exports) {
      "use strict";
      /**
       * 属性ID
       *
       * Posture#attrs 属性配列に格納された値にアクセスするための添字として用いる。
       * 例えばX方向移動量にアクセスするには posture.attrs[AttrId.tx] とする。
       */

      var AttrId;

      (function (AttrId) {
        /**
         * X方向移動。
         */
        AttrId[AttrId["tx"] = 0] = "tx";
        /**
         * Y方向移動。
         */

        AttrId[AttrId["ty"] = 1] = "ty";
        /**
         * Z軸回転(deg)。
         */

        AttrId[AttrId["rz"] = 2] = "rz";
        /**
         * X方向スケール。
         */

        AttrId[AttrId["sx"] = 3] = "sx";
        /**
         * Y方向スケール。
         */

        AttrId[AttrId["sy"] = 4] = "sy";
        /**
         * 半透明度。
         *
         * 0で透明、1で不透明を表す。
         */

        AttrId[AttrId["alpha"] = 5] = "alpha";
        /**
         * セル値。
         *
         * CellValueクラスを参照。
         */

        AttrId[AttrId["cv"] = 6] = "cv";
        /**
         * セル回転位置X座標。
         *
         * セルの中心位置は pvtx, pvty 属性によって与えられる。
         */

        AttrId[AttrId["pvtx"] = 7] = "pvtx";
        /**
         * セル回転位置Y座標。
         *
         * セルの中心位置は pvtx, pvty 属性によって与えられる。
         */

        AttrId[AttrId["pvty"] = 8] = "pvty";
        /**
         * セルテクスチャU座標。
         *
         * セルの参照する画像上の参照位置。正規化されている。
         */

        AttrId[AttrId["tu"] = 9] = "tu";
        /**
         * セルテクスチャV座標。
         *
         * セルの参照する画像上の参照位置。正規化されている。
         */

        AttrId[AttrId["tv"] = 10] = "tv";
        /**
         * セル描画優先順位。
         *
         * あるActorをレンダリングするときのセル間の描画優先順位。
         */

        AttrId[AttrId["prio"] = 11] = "prio";
        /**
         * 可視属性。
         */

        AttrId[AttrId["visibility"] = 12] = "visibility";
        /**
         * 円アタリ判定半径。
         */

        AttrId[AttrId["ccr"] = 13] = "ccr";
        /**
         * 水平フリップ。
         */

        AttrId[AttrId["flipH"] = 14] = "flipH";
        /**
         * 垂直フリップ。
         */

        AttrId[AttrId["flipV"] = 15] = "flipV";
        /**
         * ユーザデータ。
         */

        AttrId[AttrId["userData"] = 16] = "userData";
      })(AttrId || (AttrId = {}));

      module.exports = AttrId;
    }, {}],
    7: [function (require, module, exports) {
      "use strict";
      /**
       * ボーンクラス。
       */

      var Bone = function () {
        function Bone() {
          this.children = [];
          this.arrayIndex = -1;
          this.parentIndex = -1;
        }

        return Bone;
      }();

      module.exports = Bone;
    }, {}],
    8: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var Collider = require("./Collider");

      var BoxVolume = require("./BoxVolume");

      var AttrId = require("./AttrId");
      /**
       * セル用コライダー
       *
       * セルの矩形から当たり判定用ボリュームを算出するコライダー
       * 初期化にはセルを含むPostureを与える
       */


      var BoneCellCollider = function (_super) {
        __extends(BoneCellCollider, _super);

        function BoneCellCollider(name, aabbFirst) {
          var _this = _super.call(this, aabbFirst) || this;

          _this.dirty = true;
          _this.name = name;
          return _this;
        }

        BoneCellCollider.prototype.onAttached = function (actor) {
          var _this = this;

          actor.skeleton.bones.some(function (bone) {
            if (bone.name !== _this.name) {
              return false;
            }

            _this._posture = actor.skeleton.composedCaches[bone.arrayIndex];
            return true;
          });
        };

        BoneCellCollider.prototype.getVolume = function () {
          // TODO: 以下の処理の流れを定式化し、必要なoverrideのみ実装させるようにするべきか
          if (!this.enabled || !this._posture.finalizedCell || !this._posture.attrs[AttrId.visibility]) {
            return undefined;
          }

          if (this.dirty) {
            this.dirty = false;

            if (!this._volume) {
              this._volume = new BoxVolume();
            }

            var fCell = this._posture.finalizedCell;
            this._volume.aabbFirst = this.aabbFirst;
            this._volume.origin.x = 0;
            this._volume.origin.y = 0;
            this._volume.size.width = fCell.cell.size.width;
            this._volume.size.height = fCell.cell.size.height;
            this._volume.matrix = this._posture.m.multiplyNew(fCell.matrix);
            this._volume.dirty = true; // trigger to update aabb
          }

          return this._volume;
        };

        return BoneCellCollider;
      }(Collider);

      module.exports = BoneCellCollider;
    }, {
      "./AttrId": 6,
      "./BoxVolume": 10,
      "./Collider": 16
    }],
    9: [function (require, module, exports) {
      "use strict";
      /**
       * ボーン集合。
       */

      var BoneSet = function () {
        function BoneSet(name, bones) {
          this.name = name;
          this.bones = bones;
        }

        return BoneSet;
      }();

      module.exports = BoneSet;
    }, {}],
    10: [function (require, module, exports) {
      "use strict";

      var AABB = require("./AABB");

      var Vector2 = require("./Vector2");

      var Size2 = require("./Size2");
      /**
       * BoxVolume
       *
       * アタリ判定用矩形Volume。
       *
       * 実際にアタリ判定を行うときは `BoxVolume#matrix`,`origin` そして, `size` を用いてワールド座標系での領域を求める必要があります。
       */


      var BoxVolume = function () {
        function BoxVolume() {
          this.origin = new Vector2();
          this.size = new Size2();
          this.aabbFirst = false;
          this.dirty = true;
        }

        BoxVolume.prototype.aabb = function () {
          if (!this._aabb || this.dirty) {
            this.dirty = false;
            var points = []; // ! 実際は CommonOffsetがpushされる
            // TODO: 直す。multplyPointはtypoで廃止されるが、手元に新しいのがないのでこちらを使う。いまだけ

            points.push(this.matrix.multplyPoint(this.origin));
            points.push(this.matrix.multplyPoint(new Vector2(this.origin.x + this.size.width, this.origin.y)));
            points.push(this.matrix.multplyPoint(new Vector2(this.origin.x, this.origin.y + this.size.height)));
            points.push(this.matrix.multplyPoint(new Vector2(this.origin.x + this.size.width, this.origin.y + this.size.height))); // AABBの左上隅

            var lefttop_1 = new Vector2(Number.MAX_VALUE, Number.MAX_VALUE); // AABBの右下隅

            var rightbottom_1 = new Vector2(-Number.MAX_VALUE, -Number.MAX_VALUE);
            points.forEach(function (p) {
              if (p.x > rightbottom_1.x) rightbottom_1.x = p.x;
              if (p.x < lefttop_1.x) lefttop_1.x = p.x;
              if (p.y > rightbottom_1.y) rightbottom_1.y = p.y;
              if (p.y < lefttop_1.y) lefttop_1.y = p.y;
            });
            this._aabb = new AABB();
            this._aabb.origin.x = (lefttop_1.x + rightbottom_1.x) / 2;
            this._aabb.origin.y = (lefttop_1.y + rightbottom_1.y) / 2;
            this._aabb.extent.width = rightbottom_1.x - this._aabb.origin.x;
            this._aabb.extent.height = rightbottom_1.y - this._aabb.origin.y;
          }

          return this._aabb;
        };

        return BoxVolume;
      }();

      module.exports = BoxVolume;
    }, {
      "./AABB": 1,
      "./Size2": 21,
      "./Vector2": 24
    }],
    11: [function (require, module, exports) {
      "use strict";

      var Vector2 = require("./Vector2");

      var Size2 = require("./Size2");
      /**
       * セル
       */


      var Cell = function () {
        function Cell() {
          this.pos = new Vector2();
          this.size = new Size2();
          this.pivot = new Vector2();
          this.rz = 0;
          this.m = undefined;
        }

        return Cell;
      }();

      module.exports = Cell;
    }, {
      "./Size2": 21,
      "./Vector2": 24
    }],
    12: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var Attachment = require("./Attachment");
      /**
       * セル用アタッチメント
       *
       * セルを`Actor`の任意のボーンにアタッチするためのアタッチメント。
       */


      var CellAttachment = function (_super) {
        __extends(CellAttachment, _super);
        /**
         * コンストラクタ
         *
         * @param cellName セル名
         * @param skin スキン
         * @param matrix? ボーンに対してセルの位置や向きを変えるための行列(optional)
         */


        function CellAttachment(cellName, skin, matrix) {
          var _this = _super.call(this) || this;

          _this.matrix = matrix;
          _this.cell = skin.cells[cellName];
          _this.skin = skin; // pvtx, pvtyはセル矩形の中心を原点とした正規化された座標 [-0.5, +0.5]
          // ピクセル単位に変換してから行列の平行移動成分に与える

          if (_this.cell.pivot.x !== 0 || _this.cell.pivot.y !== 0) {
            var pvtx = _this.cell.size.width * _this.cell.pivot.x + _this.cell.size.width / 2;
            var pvty = _this.cell.size.height * _this.cell.pivot.y + _this.cell.size.height / 2;
            _this.pivotTransform = [1, 0, 0, 1, -pvtx, -pvty]; // (pvtx, pvty) がボーンの位置に来るように逆に移動
          }

          return _this;
        }

        CellAttachment.prototype.render = function (renderer) {
          renderer.save();
          {
            if (this.matrix) {
              renderer.transform(this.matrix._matrix);
            }

            if (this.pivotTransform) {
              renderer.transform(this.pivotTransform);
            }

            renderer.drawImage(this.skin.surface, this.cell.pos.x, this.cell.pos.y, this.cell.size.width, this.cell.size.height, 0, 0 // 転送先座標
            );
          }
          renderer.restore();
        };

        return CellAttachment;
      }(Attachment);

      module.exports = CellAttachment;
    }, {
      "./Attachment": 5
    }],
    13: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var Collider = require("./Collider");

      var BoxVolume = require("./BoxVolume");

      function multiply(m1, m2) {
        var m10 = m1[0];
        var m11 = m1[1];
        var m12 = m1[2];
        var m13 = m1[3];
        m1[0] = m10 * m2[0] + m12 * m2[1];
        m1[1] = m11 * m2[0] + m13 * m2[1];
        m1[2] = m10 * m2[2] + m12 * m2[3];
        m1[3] = m11 * m2[2] + m13 * m2[3];
        m1[4] = m10 * m2[4] + m12 * m2[5] + m1[4];
        m1[5] = m11 * m2[4] + m13 * m2[5] + m1[5];
      }
      /**
       * CellAttachmentをアタリ判定に用いるコライダー
       */


      var CellAttachmentCollider = function (_super) {
        __extends(CellAttachmentCollider, _super);

        function CellAttachmentCollider(cellAttachment, name, aabbFirst) {
          var _this = _super.call(this, aabbFirst) || this;

          _this.name = name;
          _this.dirty = true;
          _this.cellAttachment = cellAttachment;
          return _this;
        }

        CellAttachmentCollider.prototype.getVolume = function () {
          if (!this.enabled || !this.cellAttachment || !this.cellAttachment.posture) {
            return undefined;
          }

          if (this.dirty) {
            this.dirty = false;

            if (!this._volume) {
              // 以下は静的な値であるとみなす
              this._volume = new BoxVolume();
              this._volume.matrix = new g.PlainMatrix();
              this._volume.origin.x = 0;
              this._volume.origin.y = 0;
              this._volume.size.width = this.cellAttachment.cell.size.width;
              this._volume.size.height = this.cellAttachment.cell.size.height;
            }

            this._volume.aabbFirst = this.aabbFirst;
            var m = [].concat(this.cellAttachment.posture.m._matrix);

            if (this.cellAttachment.matrix) {
              multiply(m, this.cellAttachment.matrix._matrix);
            }

            if (this.cellAttachment.pivotTransform) {
              multiply(m, this.cellAttachment.pivotTransform);
            } // 矩形の位置を変えない鏡像のマトリクスなので無用
            // multiply(m, this.cellAttachment.mirrorTransform);


            this._volume.matrix._matrix = m;
            this._volume.dirty = true; // trigger to update aabb
          }

          return this._volume;
        };

        return CellAttachmentCollider;
      }(Collider);

      module.exports = CellAttachmentCollider;
    }, {
      "./BoxVolume": 10,
      "./Collider": 16
    }],
    14: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var Collider = require("./Collider");

      var CircleVolume = require("./CircleVolume");

      var AttrId = require("./AttrId");

      function getScaleFromMatrix(m) {
        var sx = Math.sqrt(m._matrix[0] * m._matrix[0] + m._matrix[1] * m._matrix[1]);
        var sy = Math.sqrt(m._matrix[2] * m._matrix[2] + m._matrix[3] * m._matrix[3]);
        return [sx, sy];
      }
      /**
       * 円形コライダー
       */


      var CircleCollider = function (_super) {
        __extends(CircleCollider, _super);
        /**
         * `CircleCollider` のインスタンスを生成する
         *
         * @param name コライダー名。Actorにアタッチすると同じ名前のboneをActorから探索し参照する
         * @param aabbFirst 衝突判定のさいAABBを優先することを示すフラグ
         * @param scaleOption CircleColiderのがスケールの影響をどのようになつかうかを指定する。
         *
         * scaleOptionは次の値のいずれかを与える。
         * - "min": スケールのX,Y成分を比較し小さい方を影響させる
         * - "max": スケールのX,Y成分を比較し大きい方を影響させる
         * - "none": スケールを影響させない
         */


        function CircleCollider(name, aabbFirst, scaleOption) {
          var _this = _super.call(this, aabbFirst) || this;

          _this.dirty = true;
          _this.name = name;
          _this._scaleOption = scaleOption;
          return _this;
        }

        CircleCollider.prototype.onAttached = function (actor) {
          var _this = this;

          actor.skeleton.bones.some(function (bone) {
            if (bone.name !== _this.name) {
              return false;
            }

            _this._posture = actor.skeleton.composedCaches[bone.arrayIndex];
            return true;
          });
        };

        CircleCollider.prototype.getVolume = function () {
          if (!this.enabled || !this._posture.finalizedCell || !this._posture.attrs[AttrId.visibility]) {
            return undefined;
          }

          if (!this.dirty) {
            return this._volume;
          }

          this.dirty = false;

          if (!this._volume) {
            this._volume = new CircleVolume();
          }

          this._volume.pos.x = this._posture.m._matrix[4];
          this._volume.pos.y = this._posture.m._matrix[5]; // scale option に「スケールあり」が無いのは、楕円を許さないため

          if (this._scaleOption === "none") {
            this._volume.r = this._posture.attrs[AttrId.ccr];
          } else {
            // TODO: 大小を比較してからsqrtしたほうが高速
            var scales = getScaleFromMatrix(this._posture.m);
            this._volume.r = this._posture.attrs[AttrId.ccr];

            if (this._scaleOption === "min") {
              this._volume.r *= scales[0] < scales[1] ? scales[0] : scales[1];
            } else if (this._scaleOption === "max") {
              this._volume.r *= scales[0] > scales[1] ? scales[0] : scales[1];
            } else {
              g.game.logger.warn("Unknown scale option: " + this._scaleOption);
            }
          }

          this._volume.aabbFirst = this.aabbFirst;
          this._volume.dirty = true; // trigger to update aabb

          return this._volume;
        };

        return CircleCollider;
      }(Collider);

      module.exports = CircleCollider;
    }, {
      "./AttrId": 6,
      "./CircleVolume": 15,
      "./Collider": 16
    }],
    15: [function (require, module, exports) {
      "use strict";

      var AABB = require("./AABB");

      var Vector2 = require("./Vector2");
      /**
       * CircleVolume。
       *
       * アタリ判定用真円形Volume。
       */


      var CircleVolume = function () {
        function CircleVolume() {
          this.pos = new Vector2();
          this.r = 0;
        }

        CircleVolume.prototype.aabb = function () {
          if (!this._aabb || this.dirty) {
            this.dirty = false;
            if (!this._aabb) this._aabb = new AABB();
            this._aabb.origin.x = this.pos.x;
            this._aabb.origin.y = this.pos.y;
            this._aabb.extent.width = this.r;
            this._aabb.extent.height = this.r;
          }

          return this._aabb;
        };

        return CircleVolume;
      }();

      module.exports = CircleVolume;
    }, {
      "./AABB": 1,
      "./Vector2": 24
    }],
    16: [function (require, module, exports) {
      "use strict";
      /**
       * コリジョンのためのVolume算出役
       */

      var Collider = function () {
        function Collider(aabbFirst) {
          this.dirty = false;
          this.enabled = true;
          this.aabbFirst = !!aabbFirst;
        }

        Collider.prototype.getVolume = function () {
          return undefined;
        };

        Collider.prototype.onAttached = function (actor) {// nothing to do
        };

        return Collider;
      }();

      module.exports = Collider;
    }, {}],
    17: [function (require, module, exports) {
      "use strict";
      /**
       * アニメーションデータコンテナ
       *
       * ASAファイル(拡張子がasa...(asapj, asaan and etc))に格納されるデータにバージョン情報を追加する
       */

      var Container = function () {
        function Container(version, contents) {
          this.version = version;
          this.contents = contents;
        }

        return Container;
      }();

      module.exports = Container;
    }, {}],
    18: [function (require, module, exports) {
      "use strict"; // FinalizedCell = 画像 + Cell(静的データ) + アニメーション(動的)パラメタ

      var FinalizedCell = function () {
        function FinalizedCell() {}

        return FinalizedCell;
      }();

      module.exports = FinalizedCell;
    }, {}],
    19: [function (require, module, exports) {
      "use strict";

      var AttrId = require("./AttrId");

      var AnimeParams_1 = require("./AnimeParams"); // 動的ボーン
      // Boneが静的で様々なシステムから参照されるのに対し、
      // Postureは実行時に定まるボーンの情報を扱う
      // 主なものはAnimationの計算結果
      //


      var Posture = function () {
        function Posture() {
          this.attrs = [];
          this.m = new g.PlainMatrix();
          this.attrs[AttrId.cv] = new AnimeParams_1.CellValue();
          this.attachments = [];

          if (Posture._costbl.length === 0) {
            // [0, 90] degree の範囲をテーブル化
            for (var i = 0; i <= 0x4000; i++) {
              var rad = Math.PI / 2 * (i / 0x4000);

              Posture._costbl.push(Math.cos(rad));
            }
          }
        }

        Posture.prototype.reset = function () {
          var attrs = this.attrs;
          attrs[AttrId.tx] = attrs[AttrId.ty] = 0;
          attrs[AttrId.rz] = 0;
          attrs[AttrId.sx] = attrs[AttrId.sy] = 1;
          attrs[AttrId.alpha] = 1;
          attrs[AttrId.tu] = attrs[AttrId.tv] = 0;
          attrs[AttrId.pvtx] = attrs[AttrId.pvty] = 0;
          attrs[AttrId.prio] = 0;
          attrs[AttrId.visibility] = true;
          attrs[AttrId.cv] = undefined;
          attrs[AttrId.ccr] = 0;
          attrs[AttrId.flipH] = false;
          attrs[AttrId.flipV] = false;
          this.m.reset(); // アニメーション以外の処理で与えられた値はクリアしない
        };

        Posture.prototype.quickcos = function (rz_in) {
          var rz = rz_in * 65536 / 360 | 0; // JSにrzが整数であると伝える。僅かに性能が良くなる気がする、程度だが

          if (rz >= 0) {
            rz = rz & 0xFFFF;
          } else {
            rz = 0x10000 - (-rz & 0xFFFF);
          }

          if (rz < 0x4000) {
            return Posture._costbl[rz];
          } else if (rz < 0x8000) {
            return -Posture._costbl[0x4000 - (rz - 0x4000)];
          } else if (rz < 0xC000) {
            return -Posture._costbl[rz - 0x8000];
          } else {
            return Posture._costbl[0x4000 - (rz - 0xC000)];
          }
        };

        Posture.prototype.updateMatrix = function () {
          var attrs = this.attrs;

          var _cos = this.quickcos(attrs[AttrId.rz]);

          var _sin = this.quickcos(attrs[AttrId.rz] - 90);

          var m = this.m._matrix;
          m[0] = _cos * attrs[AttrId.sx];
          m[1] = _sin * attrs[AttrId.sx];
          m[2] = -_sin * attrs[AttrId.sy];
          m[3] = _cos * attrs[AttrId.sy];
          m[4] = attrs[AttrId.tx];
          m[5] = attrs[AttrId.ty];
        };

        return Posture;
      }();

      Posture._costbl = [];
      module.exports = Posture;
    }, {
      "./AnimeParams": 4,
      "./AttrId": 6
    }],
    20: [function (require, module, exports) {
      "use strict";

      var AttrId = require("./AttrId");

      function checkVersion(version, fname) {
        var r = version.match(/(\d+)\.\d+.\d+/);

        if (!r || r[1] !== "2") {
          throw g.ExceptionFactory.createAssertionError("Invalid fileformat version: " + fname + ", " + version + "<2.0.0");
        }
      }

      function bindTextureFromAsset(skin, assets) {
        var assetName = skin.imageAssetName ? skin.imageAssetName : skin.name;
        var anAsset = assets[assetName];
        skin.surface = anAsset.asSurface();
      }

      function constructBoneTree(bones) {
        for (var i = 0; i < bones.length; i++) {
          var bone = bones[i]; // シリアライズの時点で欠落するのでここで追加

          bone.parent = undefined;
          bone.children = [];
        }

        for (var i = 0; i < bones.length; i++) {
          var bone = bones[i];

          if (bone.parentIndex >= 0) {
            bone.parent = bones[bone.parentIndex];
            bone.parent.children.push(bone);
          }
        }
      }

      function loadResourceFromTextAsset(fileNames, assets, resolver) {
        var resources = [];
        fileNames.forEach(function (fname) {
          var assetName = fname.split(".")[0]; // アセット名は拡張子を覗いたファイル名

          var data = JSON.parse(assets[assetName].data);
          checkVersion(data.version, fname);

          if (resolver) {
            resolver(data.contents, assets);
          }

          resources.push(data.contents);
        });
        return resources;
      }

      function assignAttributeID(animation) {
        var ct = animation.curveTies;

        for (var key in ct) {
          if (ct.hasOwnProperty(key)) {
            ct[key].curves.forEach(function (c) {
              var attrId = AttrId[c.attribute];
              c.attrId = attrId;
            });
          }
        }
      }

      function mergeAssetArray(assetArray) {
        var merged = {};

        for (var i = 0; i < assetArray.length; i++) {
          var assets = assetArray[i];

          for (var key in assets) {
            if (assets.hasOwnProperty(key)) {
              merged[key] = assets[key];
            }
          }
        }

        return merged;
      }
      /**
       * アニメーションリソースクラス
       */


      var Resource = function () {
        function Resource() {
          this.skins = [];
          this.boneSets = [];
          this.animations = []; // ...
        }
        /**
         * asapjテキストアセットを読み込み、さらに関連するアセットも読み込む
         *
         * @param assetName asapjテキストアセット名
         * @param assets 利用できるアセット
         * @param ...otherAssets 利用できるアセット（可変長引数）
         */


        Resource.prototype.loadProject = function (assetName, assets) {
          var otherAssets = [];

          for (var _i = 2; _i < arguments.length; _i++) {
            otherAssets[_i - 2] = arguments[_i];
          }

          var mergedAssets = mergeAssetArray([assets].concat(otherAssets));
          var json = mergedAssets[assetName].data;
          var data = JSON.parse(json);
          checkVersion(data.version, assetName);
          this.boneSets = loadResourceFromTextAsset(data.contents.boneSetFileNames, mergedAssets, function (c, asseta) {
            constructBoneTree(c.bones);
          });
          this.skins = loadResourceFromTextAsset(data.contents.skinFileNames, mergedAssets, bindTextureFromAsset);
          this.animations = loadResourceFromTextAsset(data.contents.animationFileNames, mergedAssets, undefined);
          this.animations.forEach(function (animation) {
            assignAttributeID(animation);
          });
        };
        /**
         * スキンを取得する。
         *
         * @param name スキン名
         */


        Resource.prototype.getSkinByName = function (name) {
          for (var i = 0; i < this.skins.length; i++) {
            if (this.skins[i].name === name) {
              return this.skins[i];
            }
          }

          return undefined;
        };
        /**
         * ボーンセットを取得する。
         *
         * @param name ボーンセット名
         */


        Resource.prototype.getBoneSetByName = function (name) {
          var found;
          this.boneSets.some(function (boneSet) {
            if (boneSet.name === name) {
              found = boneSet;
              return true;
            } else {
              return false;
            }
          });
          return found;
        };
        /**
         * アニメーションを取得する。
         *
         * @param name アニメーション名
         */


        Resource.prototype.getAnimationByName = function (name) {
          for (var i = 0; i < this.animations.length; i++) {
            if (this.animations[i].name === name) {
              return this.animations[i];
            }
          }

          return undefined;
        };

        return Resource;
      }();

      module.exports = Resource;
    }, {
      "./AttrId": 6
    }],
    21: [function (require, module, exports) {
      "use strict";
      /**
       * 2Dサイズクラス
       */

      var Size2 = function () {
        function Size2(width, height) {
          this.width = width !== undefined ? width : 0;
          this.height = height !== undefined ? height : 0;
        }

        return Size2;
      }();

      module.exports = Size2;
    }, {}],
    22: [function (require, module, exports) {
      "use strict";

      var Posture = require("./Posture");

      var AttrId = require("./AttrId");

      var AnimeParams_1 = require("./AnimeParams"); // 属性初期値テーブル
      //
      // akashic-animationの扱える属性の一覧でもある
      // ここに無いものにアクセスすると undefined となる
      // ss2asa の SpriteStudio.ts にも扱える属性に関するテーブルが存在する
      // 機能を追加する際は両方に食い違いがないようにすること


      var attributeInitialValues = {
        tx: 0,
        ty: 0,
        rz: 0,
        sx: 1.0,
        sy: 1.0,
        alpha: 1.0,
        cv: undefined,
        pvtx: 1.0,
        pvty: 1.0,
        tu: 1.0,
        tv: 1.0,
        prio: 0,
        visibility: true,
        ccr: 0.0,
        flipH: false,
        flipV: false,
        userData: undefined
      };

      function makeLinearKey(time, value) {
        var r = new AnimeParams_1.KeyFrame();
        r.time = time;
        r.value = value;
        r.ipType = "linear";
        r.ipCurve = undefined;
        return r;
      }

      function makeLastKey(time, value) {
        var r = new AnimeParams_1.KeyFrame();
        r.time = time;
        r.value = value;
        r.ipType = undefined;
        r.ipCurve = undefined;
        return r;
      }

      function makeDefaultKey(attribute) {
        var r = new AnimeParams_1.KeyFrame();
        r.time = 0;
        r.value = attributeInitialValues[attribute];
        r.ipType = undefined; // no interpolation

        r.ipCurve = undefined;
        return r;
      }
      /*
       * 与えられた時刻に関係する２つのキーを取り出す
       *
       * アニメーションから値を導くには２つのキーが必要になる
       *
       * ２つのキーが得られない状況
       * 1. 最初のキーが（ゼロでなく）１フレーム目以降に打たれている
       * 2. 最後のキーが最終フレームより前に打たれている
       *
       * それぞれ次のように扱う
       * 1. 初期値を持ったキーが０フレーム目に打たれているとみなす
       * 2. 最後のキーと全く同じものが最終フレームにも打たれているとみなす
       *
       * そのようにキーが外挿される
       *
       * 返り値: 以下の２要素の配列
       * 1. 開始キー
       * 2. 終了キー
       *
       * @param keyFrames キーフレーム配列
       * @param time 現在時刻
       * @param frameCount keyFramesを格納するAnimationの定義するアニメーション全体の長さ（時間）
       * @param attribute この関数の返すキーフレームペアを用いる属性
       */


      function pickKeyFramePairByTime(keyFrames, time, frameCount, attribute) {
        var kFrom = undefined;
        var kTo = undefined; // ループアニメーション用の処理
        // ループアニメーションではこの区間が存在する。この時キーを補う

        if (frameCount - 1 < time && time < frameCount) {
          kFrom = makeLinearKey(frameCount - 1, keyFrames[keyFrames.length - 1].value); // 外挿

          kTo = makeLinearKey(frameCount, keyFrames[0].value); // 外挿

          return [kFrom, kTo];
        }

        if (time < keyFrames[0].time) {
          kFrom = makeDefaultKey(attribute); // 外挿

          kTo = keyFrames[0]; // kFromは"補間なし"設定。結果この区間ではkFrom.valueが採用される

          return [kFrom, kTo];
        }

        for (var k = 1; k < keyFrames.length; k++) {
          if (time < keyFrames[k].time) {
            kTo = keyFrames[k];
            kFrom = keyFrames[k - 1];
            return [kFrom, kTo];
          }
        }

        kFrom = keyFrames[keyFrames.length - 1];
        kTo = makeLastKey(frameCount - 1, kFrom.value); // 外挿

        return [kFrom, kTo];
      }

      function interpolateLinear(kFrom, kTo, time) {
        var t = (time - kFrom.time) / (kTo.time - kFrom.time);
        return kFrom.value * (1 - t) + kTo.value * t;
      } // kFrom.time, kTo.timeをベジェ補間した結果 key.time === time となるような 媒介変数を逆算する
      // SSに倣った
      // https://github.com/SpriteStudio/SpriteStudio5-SDK/blob/master/Common/Loader/ssInterpolation.cpp#L52


      function calcBackParameter(kFrom, kTo, time) {
        // ２分探索。探索回数次第で精度が決まる.
        // 探索回数８はSpriteStudioに従った
        // 30FPSから考えると、８回なら誤差は1フレーム(0.033sec)に満たない
        var t = 0.5;
        var stride = 0.25;
        var values = kFrom.ipCurve.values;
        var p1 = kFrom.time;
        var p2 = kFrom.time + values[0];
        var p3 = kTo.time + values[2];
        var p4 = kTo.time;

        for (var i = 0; i < 8; i = i + 1 | 0) {
          var s = 1 - t;
          var s2 = s * s;
          var t2 = t * t;
          var interpolated = s * s2 * p1 + 3 * t * s2 * p2 + 3 * s * t2 * p3 + t * t2 * p4;

          if (interpolated > time) {
            t -= stride;
          } else {
            t += stride;
          }

          stride /= 2;
        }

        return t;
      }

      function interpolateBezier(kFrom, kTo, time) {
        var t = calcBackParameter(kFrom, kTo, time);
        var values = kFrom.ipCurve.values;
        var s = 1 - t;
        var s2 = s * s;
        var t2 = t * t;
        return s * s2 * kFrom.value + 3 * t * s2 * (kFrom.value + values[1]) + 3 * s * t2 * (kTo.value + values[3]) + t * t2 * kTo.value;
      } // see: https://github.com/SpriteStudio/SpriteStudio5-SDK/blob/master/Common/Loader/ssInterpolation.cpp#L112


      function interpolateHermite(kFrom, kTo, time) {
        var t = (time - kFrom.time) / (kTo.time - kFrom.time);
        var values = kFrom.ipCurve.values;
        var from = kFrom.value;
        var to = kTo.value;
        var t2 = t * t;
        var t3 = t2 * t;
        return (2 * t3 - 3 * t2 + 1) * from + (-2 * t3 + 3 * t2) * to + (t3 - 2 * t2 + t) * (values[1] - from) + (t3 - t2) * (values[3] - to);
      } // SSの実装は次の通り
      // https://github.com/SpriteStudio/SpriteStudio5-SDK/blob/master/Common/Animator/ssplayer_animedecode.cpp
      // https://github.com/SpriteStudio/SpriteStudio5-SDK/blob/master/Common/Loader/ssInterpolation.cpp


      function interpolate(kFrom, kTo, time) {
        // 非numberの補間は最初のキーの値を採用する（ステップ関数）
        // ipType===undefinedは「補間しない」を表す有効な値である
        // ２つのキーが同時刻を指すとき最初のキーの値を採用する
        if (typeof kFrom.value !== "number" || typeof kFrom.ipType === "undefined" || kFrom.time === kTo.time) {
          return kFrom.value;
        } else {
          switch (kFrom.ipType) {
            case "linear":
              return interpolateLinear(kFrom, kTo, time);

            case "bezier":
              return interpolateBezier(kFrom, kTo, time);

            case "hermite":
              return interpolateHermite(kFrom, kTo, time);
            // case "acceleration": // SpriteStuioのサポートする方式。一般的でないかもしれないので対応保留
            // case "deceleration": // SpriteStuioのサポートする方式。一般的でないかもしれないので対応保留

            default:
              // 未知の補間方法は不正なデータである
              g.game.logger.warn("Unknown interpolation: " + kFrom.ipType); // 補間できない。最初のキーの値を採用する

              return kFrom.value;
          }
        }
      }
      /**
       * スケルトンクラス
       *
       * スケルトンクラスはアニメーションの計算と結果の保持を行う。
       */


      var Skeleton = function () {
        /**
         * Skeletonのインスタンスを生成する。
         *
         * @param bones ボーン配列
         * @param matrixFunc ルートボーンに前から乗算されるマトリクスを返す関数オブジェクト
         */
        function Skeleton(bones, matrixFunc) {
          this.bones = bones;
          this.matrixFunc = matrixFunc;
          this._triggeringBones = [];
          this.caches = new Array(bones.length);

          for (var i = 0; i < this.caches.length; i++) {
            this.caches[i] = new Posture();
            this.caches[i].index = i;
          }

          this.composedCaches = new Array(bones.length);

          for (var i = 0; i < this.composedCaches.length; i++) {
            this.composedCaches[i] = new Posture();
            this.composedCaches[i].index = i;
          }
        }

        Skeleton.prototype.getPostureByName = function (name) {
          for (var i = 0; i < this.bones.length; i = i + 1 | 0) {
            if (this.bones[i].name === name) {
              return this.caches[this.bones[i].arrayIndex];
            }
          }

          return undefined;
        };
        /**
         * アタッチメントを取り付ける
         *
         * 通常ゲーム開発者はこのメソッドを直接呼び出す必要はない。
         *
         * @param attachment アタッチメント
         * @param boneName 取り付ける先のボーン名
         */


        Skeleton.prototype.attach = function (attachment, boneName) {
          var _this = this;

          this.bones.some(function (bone) {
            if (bone.name === boneName) {
              _this.caches[bone.arrayIndex].attachments.push(attachment);

              attachment.posture = _this.composedCaches[bone.arrayIndex];
              return true;
            }

            return false;
          });
        };
        /**
         * アタッチメントを取り外す。
         *
         * @param attachment 取り外すアタッチメント
         */


        Skeleton.prototype.removeAttachment = function (attachment) {
          var _this = this;

          this.bones.some(function (bone) {
            var posture = _this.caches[bone.arrayIndex];
            var index = posture.attachments.indexOf(attachment);

            if (index === -1) {
              return false;
            }

            var removed = posture.attachments.splice(index, 1);
            removed[0].posture = undefined;
            return true;
          });
        };
        /**
         * アニメーションの計算と描画の準備を行う。
         *
         * 通常ゲーム開発者はこのメソッドを直接呼び出す必要はない。
         *
         * @param time 現在のフレーム
         * @param anim 計算に用いるアニメーション
         */


        Skeleton.prototype.update = function (time, anim) {
          // アニメーションを計算。結果をcacheに収める
          this.updateCache(time, anim); // キャッシュの中身を接続

          this.traverse(this.bones[0]); // 0 番目にrootがあること
        };

        Skeleton.prototype._getBoneByName = function (boneName) {
          var bones = this.bones;

          for (var i = 0; i < bones.length; i = i + 1 | 0) {
            if (bones[i].name === boneName) {
              return bones[i];
            }
          }

          return undefined;
        };
        /**
         * ボーンからアニメーションハンドラのためのg.Triggerインスタンスを取得する。
         *
         * @param boneName ボーン名
         * @param createIfNotExists 無ければg.Triggerインスタンスを生成するならtrueを与える
         */


        Skeleton.prototype._getTrigger = function (boneName, createIfNotExists) {
          var bone = this._getBoneByName(boneName);

          if (!bone) {
            return undefined;
          }

          var posture = this.caches[bone.arrayIndex];

          if (!posture) {
            return undefined;
          }

          if (!posture._trigger && createIfNotExists) {
            posture._trigger = new g.Trigger();

            this._triggeringBones.push(bone);
          }

          return posture._trigger;
        };
        /**
         * アニメーション計算ハンドラを実行する。
         */


        Skeleton.prototype._handleUserEvent = function (startFrame, elapse, anim) {
          for (var i = 0; i < this._triggeringBones.length; i++) {
            var bone = this._triggeringBones[i];
            var cache = this.caches[bone.arrayIndex]; // skip if there's no handler

            if (!cache._trigger.hasHandler()) {
              continue;
            } // skip if there's no curve for the bone


            var ct = anim.curveTies[bone.name];

            if (ct === undefined) {
              continue;
            } // NOTE: データ読み込み時にuserDataがあるかどうか目印を付けて実行時の探索を軽減可能では


            for (var j = 0; j < ct.curves.length; j++) {
              var curve = ct.curves[j];

              if (curve.attrId === AttrId.userData && curve.keyFrames.length > 0) {
                if (elapse > 0) {
                  this.fastForward(cache, curve.keyFrames, startFrame, elapse, anim.frameCount);
                } else {
                  this.fastBackward(cache, curve.keyFrames, startFrame, elapse, anim.frameCount);
                }
              }
            }
          }
        };

        Skeleton.prototype.fastForward = function (cache, keyFrames, startFrame, elapse, animFrameCount) {
          var i = 0;
          var nLoop = 0;
          var endFrame = startFrame + elapse;

          while (true) {
            var keyFrame = keyFrames[i];
            var time = keyFrame.time + animFrameCount * nLoop;

            if (time >= endFrame) {
              break;
            }

            if (startFrame < time) {
              cache._trigger.fire({
                left: {
                  time: keyFrame.time,
                  userData: keyFrame.value
                },
                currentFrame: keyFrame.time,
                frameCount: animFrameCount
              });
            }

            if (++i === keyFrames.length) {
              i = 0;
              nLoop++;
            }
          }
        };

        Skeleton.prototype.fastBackward = function (cache, keyFrames, startFrame, elapse, animFrameCount) {
          var i = keyFrames.length - 1;
          var nLoop = 0;
          var endFrame = startFrame + elapse;

          while (true) {
            var keyFrame = keyFrames[i];
            var time = keyFrame.time - animFrameCount * nLoop;

            if (time <= endFrame) {
              break;
            }

            if (time < startFrame) {
              cache._trigger.fire({
                left: {
                  time: keyFrame.time,
                  userData: keyFrame.value
                },
                currentFrame: keyFrame.time,
                frameCount: animFrameCount
              });
            }

            if (--i === -1) {
              i = keyFrames.length - 1;
              nLoop++;
            }
          }
        };

        Skeleton.prototype.updateCache = function (time, anim) {
          for (var i = 0; i < this.bones.length; i++) {
            var bone = this.bones[i];
            var cache = this.caches[bone.arrayIndex];
            cache.reset();
            var ct = anim.curveTies[bone.name];

            if (ct === undefined) {
              continue;
            }

            var left = void 0;
            var right = void 0;

            for (var j = 0; j < ct.curves.length; j++) {
              var c = ct.curves[j]; // pick key frame pair

              var pair = pickKeyFramePairByTime(c.keyFrames, time, anim.frameCount, c.attribute);
              var kFrom = pair[0];
              var kTo = pair[1];
              var attrId = c.attrId;

              if (attrId === AttrId.userData) {
                left = {
                  time: kFrom.time,
                  userData: kFrom.value
                };
                right = {
                  time: kTo.time,
                  userData: kTo.value
                };
              } // interpolation


              cache.attrs[attrId] = interpolate(kFrom, kTo, time);
            }

            if (cache._trigger && cache._trigger.hasHandler()) {
              // handler should call cache.updateMatrix()
              cache._trigger.fire({
                posture: cache,
                left: left,
                right: right,
                currentFrame: time,
                frameCount: anim.frameCount
              });
            } else {
              cache.updateMatrix();
            }
          }
        };

        Skeleton.prototype.traverse = function (bone) {
          var cache = this.caches[bone.arrayIndex];
          var composedCache = this.composedCaches[bone.arrayIndex]; // compose

          if (bone.parent) {
            var parentComposedCache = this.composedCaches[bone.parent.arrayIndex];

            if (parentComposedCache === undefined) {
              g.game.logger.warn("Invalid array index for " + bone.parent.name);
            } else {
              var m0 = composedCache.m._matrix;
              var m1 = parentComposedCache.m._matrix;
              var m2 = cache.m._matrix; // m0 = m1 * m2

              m0[0] = m1[0] * m2[0] + m1[2] * m2[1];
              m0[1] = m1[1] * m2[0] + m1[3] * m2[1];
              m0[2] = m1[0] * m2[2] + m1[2] * m2[3];
              m0[3] = m1[1] * m2[2] + m1[3] * m2[3];
              m0[4] = m1[0] * m2[4] + m1[2] * m2[5] + m1[4];
              m0[5] = m1[1] * m2[4] + m1[3] * m2[5] + m1[5];
              composedCache.attrs[AttrId.alpha] = parentComposedCache.attrs[AttrId.alpha] * cache.attrs[AttrId.alpha];
            }
          } else {
            var m1 = composedCache.m._matrix;

            if (this.matrixFunc) {
              var m2 = this.matrixFunc()._matrix;

              m1[0] = m2[0];
              m1[1] = m2[1];
              m1[2] = m2[2];
              m1[3] = m2[3];
              m1[4] = m2[4];
              m1[5] = m2[5];
            } else {
              m1[0] = 1;
              m1[1] = 0;
              m1[2] = 0;
              m1[3] = 1;
              m1[4] = 0;
              m1[5] = 0;
            }

            composedCache.m.multiply(cache.m);
            composedCache.attrs[AttrId.alpha] = 1.0;
          } // copy


          var src = cache.attrs;
          var dst = composedCache.attrs;
          dst[AttrId.cv] = src[AttrId.cv];
          dst[AttrId.pvtx] = src[AttrId.pvtx];
          dst[AttrId.pvty] = src[AttrId.pvty];
          dst[AttrId.tu] = src[AttrId.tu];
          dst[AttrId.tv] = src[AttrId.tv];
          dst[AttrId.prio] = src[AttrId.prio];
          dst[AttrId.visibility] = src[AttrId.visibility];
          composedCache.attachments = cache.attachments;
          dst[AttrId.ccr] = src[AttrId.ccr];
          dst[AttrId.flipH] = src[AttrId.flipH];
          dst[AttrId.flipV] = src[AttrId.flipV]; // go down well.

          if (bone.children) {
            for (var i = 0; i < bone.children.length; i++) {
              this.traverse(bone.children[i]);
            }
          }
        };

        return Skeleton;
      }();

      module.exports = Skeleton;
    }, {
      "./AnimeParams": 4,
      "./AttrId": 6,
      "./Posture": 19
    }],
    23: [function (require, module, exports) {
      "use strict";
      /**
       * スキンクラス
       *
       * スキンはActorの各ボーンに取り付けられる表示物であるセルの集合です
       */

      var Skin = function () {
        function Skin() {
          this.cells = {};
        }

        return Skin;
      }();

      module.exports = Skin;
    }, {}],
    24: [function (require, module, exports) {
      "use strict";
      /**
       * 2Dベクトルクラス
       */

      var Vector2 = function () {
        function Vector2(x, y) {
          this.x = x ? x : 0;
          this.y = y ? y : 0;
        }

        return Vector2;
      }();

      module.exports = Vector2;
    }, {}],
    25: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Actor = require("./Actor");
      exports.Skeleton = require("./Skeleton");
      exports.Skin = require("./Skin");
      exports.Cell = require("./Cell");
      exports.FinalizedCell = require("./FinalizedCell");
      exports.Posture = require("./Posture");
      exports.Bone = require("./Bone");
      exports.BoneSet = require("./BoneSet");
      exports.AnimeParams = require("./AnimeParams");
      exports.Resource = require("./Resource");
      exports.Container = require("./Container");
      exports.Collider = require("./Collider");
      exports.BoneCellCollider = require("./BoneCellCollider");
      exports.CircleCollider = require("./CircleCollider");
      exports.CellAttachmentCollider = require("./CellAttachmentCollider");
      exports.Attachment = require("./Attachment");
      exports.CellAttachment = require("./CellAttachment");
      exports.Vector2 = require("./Vector2");
      exports.Size2 = require("./Size2");
      exports.AABB = require("./AABB");
      exports.BoxVolume = require("./BoxVolume");
      exports.CircleVolume = require("./CircleVolume");
      exports.AttrId = require("./AttrId");
      exports.AnimationHandlerParams = require("./AnimationHandlerParams");
    }, {
      "./AABB": 1,
      "./Actor": 2,
      "./AnimationHandlerParams": 3,
      "./AnimeParams": 4,
      "./Attachment": 5,
      "./AttrId": 6,
      "./Bone": 7,
      "./BoneCellCollider": 8,
      "./BoneSet": 9,
      "./BoxVolume": 10,
      "./Cell": 11,
      "./CellAttachment": 12,
      "./CellAttachmentCollider": 13,
      "./CircleCollider": 14,
      "./CircleVolume": 15,
      "./Collider": 16,
      "./Container": 17,
      "./FinalizedCell": 18,
      "./Posture": 19,
      "./Resource": 20,
      "./Size2": 21,
      "./Skeleton": 22,
      "./Skin": 23,
      "./Vector2": 24
    }],
    26: [function (require, module, exports) {
      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType || (ActionType = {}));

      module.exports = ActionType;
    }, {}],
    27: [function (require, module, exports) {
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */
      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
      })(Easing || (Easing = {}));

      module.exports = Easing;
    }, {}],
    28: [function (require, module, exports) {
      var Tween = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline = function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.update.handle(this, this._handler);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween(target, option);

          this._tweens.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          if (index < 0) {
            return;
          }

          this._tweens.splice(index, 1);
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this._tweens.length = 0;
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this._tweens.length = 0;

          if (!this._scene.destroyed()) {
            this._scene.update.remove(this, this._handler);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this._tweens.length === 0 || this.paused) {
            return;
          }

          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.destroyed()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      module.exports = Timeline;
    }, {
      "./Tween": 29
    }],
    29: [function (require, module, exports) {
      var Easing = require("./Easing");

      var ActionType = require("./ActionType");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween = function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._modifiedHandler = option && option.modified ? option.modified : undefined;
          this._destroyedHandler = option && option.destroyed ? option.destroyed : undefined;
          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * Tweenが破棄されたかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.destroyed = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.destroyed() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType.TweenTo:
              case ActionType.TweenBy:
              case ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j];

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType.TweenTo && action.type !== ActionType.TweenBy && action.type !== ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      module.exports = Tween;
    }, {
      "./ActionType": 26,
      "./Easing": 27
    }],
    30: [function (require, module, exports) {
      exports.Timeline = require("./Timeline");
      exports.Tween = require("./Tween");
      exports.Easing = require("./Easing");
    }, {
      "./Easing": 27,
      "./Timeline": 28,
      "./Tween": 29
    }],
    31: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * asapj関連の静的情報
       */

      var AsaInfo =
      /** @class */
      function () {
        function AsaInfo() {} // tslint:disable-next-line:typedef


        AsaInfo.surfing = {
          pj: "pj_surfing",
          anim: {
            waveFlat: "wave_flat",
            waveSL: "wave_move_s_l",
            waveLS: "wave_move_l_s",
            waveLowerMost: "wave_lowermost",
            pcNormal: "pc_nomal",
            pcDamage: "pc_damage",
            pcReturn: "pc_return",
            pcRunup: "pc_strongest" // ＰＣ（復帰後の無敵状態）

          }
        }; // tslint:disable-next-line:typedef

        AsaInfo.obstacle = {
          pj: "pj_obstacle",
          anim: {
            gull: "enemy_01_a",
            rock: "enemy_02_a",
            shark: "enemy_03_a",
            pteranodon: "enemy_04_a" // 障害物Ｄ（プテラノドン）

          }
        };
        return AsaInfo;
      }();

      exports.AsaInfo = AsaInfo;
    }, {}],
    32: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 画像アセット関連の静的情報
       */

      var AssetInfo =
      /** @class */
      function () {
        function AssetInfo() {} // tslint:disable-next-line:typedef


        AssetInfo.numBlack = {
          img: "img_numbers_n",
          json: "json_numbers_n",
          numFrames: ["numbers_n_10.png", "numbers_n_01.png", "numbers_n_02.png", "numbers_n_03.png", "numbers_n_04.png", "numbers_n_05.png", "numbers_n_06.png", "numbers_n_07.png", "numbers_n_08.png", "numbers_n_09.png"],
          frames: {
            cross: "numbers_n_11.png",
            plus: "numbers_n_12.png",
            minus: "numbers_n_13.png"
          },
          fontWidth: 26,
          fontHeight: 30
        }; // tslint:disable-next-line:typedef

        AssetInfo.numRed = {
          img: "img_numbers_n_red",
          json: "json_numbers_n_red",
          numFrames: ["numbers_n_red_10.png", "numbers_n_red_01.png", "numbers_n_red_02.png", "numbers_n_red_03.png", "numbers_n_red_04.png", "numbers_n_red_05.png", "numbers_n_red_06.png", "numbers_n_red_07.png", "numbers_n_red_08.png", "numbers_n_red_09.png"],
          frames: {
            cross: "numbers_n_red_11.png",
            plus: "numbers_n_red_12.png",
            minus: "numbers_n_red_13.png"
          },
          fontWidth: 26,
          fontHeight: 30
        }; // tslint:disable-next-line:typedef

        AssetInfo.ui = {
          img: "img_ui",
          json: "json_ui",
          frames: {
            iconT: "icon_t.png",
            iconPt: "ui_icon_pt_export.png" // UIアイコン（pt）

          }
        }; // tslint:disable-next-line:typedef

        AssetInfo.bgObj = {
          img: "img_bg_obj",
          json: "json_bg_obj",
          frames: {
            bgObj01: "bg_obj01.png",
            bgObj02: "bg_obj02.png",
            bgObj03: "bg_obj03.png",
            bgObj04: "bg_obj04.png",
            bgObj05: "bg_obj05.png",
            bgObj06: "bg_obj06.png",
            bgObj07: "bg_obj07.png",
            bgObj08: "bg_obj08.png",
            bgObj09: "bg_obj09.png" // 背景オブジェクト（モアイ2）

          }
        };
        return AssetInfo;
      }();

      exports.AssetInfo = AssetInfo;
    }, {}],
    33: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var assetInfo_1 = require("./assetInfo");
      /**
       * ゲーム関連の静的情報
       */


      var define;

      (function (define) {
        /** デバッグ用：タッチしている間PCが上昇するようにするフラグ */
        define.DEBUG_HOLD_TO_UP = false;
        /** デバッグ用：障害物にあたらなくするフラグ */

        define.DEBUG_COLLISION = false;
        /** デバッグ用：あたり判定範囲を表示するフラグ */

        define.DEBUG_SHOW_COLLISION_RECT = false;
        /** デバッグ用：あたり判定範囲表示の色 */

        define.DEBUG_COLLISION_RECT_COLOR = "red";
        /** デバッグ用：あたり判定範囲表示の不透明度 */

        define.DEBUG_COLLISION_RECT_OPACITY = 0.3;
        /** 制限時間[秒] */

        define.GAME_TIME = 45;
        /** このゲームが許容する最長の制限時間[秒] */

        define.GAME_TIME_MAX = 99;
        /** 残り時間警告が始まる残り時間[秒]（この時間未満になった時に始まる） */

        define.CAUTION_TIME_CONDITION = 10;
        /** 横解像度を480から640に変更した際のX座標オフセット値 */

        define.OFFSET_X = (640 - 480) / 2;
        /** ゲーム中の数字の桁数 */

        define.GAME_TIMER_DIGIT = 2;
        /** ゲーム中の数字のX座標 */

        define.GAME_TIMER_X = 70 + define.OFFSET_X;
        /** ゲーム中の数字のY座標 */

        define.GAME_TIMER_Y = 3;
        /** ポイント用の数字の桁数 */

        define.GAME_SCORE_DIGIT = 5;
        /** ポイント用の数字のX座標 */

        define.GAME_SCORE_X = 403 + define.OFFSET_X;
        /** ポイント用の数字のY座標 */

        define.GAME_SCORE_Y = 3;
        /** スコア上限 */

        define.SCORE_LIMIT = Math.pow(10, define.GAME_SCORE_DIGIT) - 1;
        /** UIアイコン（時計）のX座標 */

        define.ICON_T_X = 8 + define.OFFSET_X;
        /** UIアイコン（時計）のY座標 */

        define.ICON_T_Y = 0;
        /** UIアイコン（pt）のX座標 */

        define.ICON_PT_X = 432 + define.OFFSET_X;
        /** UIアイコン（pt）のY座標 */

        define.ICON_PT_Y = 0;
        /** PC/波/水面のX座標 */

        define.SURFING_X = -100;
        /** PC/波/水面のY座標 */

        define.SURFING_Y = 30;
        /** PCのアタッチ先ボーン名 */

        define.PC_PIVOT_NAME = "pc_null";
        /** ミスからの復帰後の無敵時間[フレーム] */

        define.RUNUP_FRAMES = 40;
        /** タッチ時に設定される上昇時間[フレーム] */

        define.UP_FRAMES_PER_TOUCH = 5;
        /** タッチ時に設定されるタッチ受付不能時間[フレーム] */

        define.TOUCH_COOLING_FRAMES = 30;
        /** 上昇アニメの再生速度 */

        define.PLAYSPEED_UP = 1.5;
        /** 下降アニメの再生速度 */

        define.PLAYSPEED_DOWN = 0.9;
        /** スクロール速度[px/フレーム]：分子 */

        define.SCROLL_PX_PER_FRAME_NUM = 38 * 160 * 2;
        /** スクロール速度[px/フレーム]：分母 */

        define.SCROLL_PX_PER_FRAME_DENOM = 60 * 30;
        /** スクロール量とメートル値の比[m/px]：分子 */

        define.SCROLL_METER_PER_PX_NUM = 1;
        /** スクロール量とメートル値の比[m/px]：分母 */

        define.SCROLL_METER_PER_PX_DENOM = 1;
        /** SCROLL_PX_PER_FRAME_NUMを基準とした最大速度 */

        define.SCROLL_FACTOR_MAX = 2;
        /** 最大速度に対応するPCせり出し量[px] */

        define.PC_OVERHANG_MAX = 50;
        /** 障害物の表示を開始する画面右端からのピクセル距離 */

        define.OBSTACLE_APPEAR_AREA_WIDTH = 480;
        /** 障害物の表示を終了する画面左端からのピクセル距離 */

        define.OBSTACLE_WIDTH_TO_VANISH_AREA = 480;
        /** プテラノドンのアニメを開始するX座標 */

        define.PTERANODON_WAKE_X = 534 + define.OFFSET_X;
        /** プテラノドンのあたり判定位置のボーン名 */

        define.PTERANODON_PIVOT_NAME = "obstacle_pteranodon_01_1";
        /** PCのあたり判定矩形 */

        define.COLLISION_PC = {
          x: -55 + 0,
          y: -18,
          width: 78 - 0,
          height: 35 - 20
        };
        /** 障害物のあたり判定矩形配列：カモメ */

        define.COLLISIONS_GULL = [{
          x: 15,
          y: -60,
          width: 44,
          height: 50
        }];
        /** 障害物のあたり判定矩形配列：岩 */

        define.COLLISIONS_ROCK = [{
          x: 29,
          y: -250,
          width: 30,
          height: 50
        }];
        /** 障害物のあたり判定矩形配列：サメ */

        define.COLLISIONS_SHARK = [{
          x: 70,
          y: -95,
          width: 40,
          height: 30
        }, {
          x: 59,
          y: -85,
          width: 5,
          height: 30
        }, {
          x: 48,
          y: -75,
          width: 5,
          height: 30
        }, {
          x: 37,
          y: -65,
          width: 5,
          height: 30
        }, {
          x: 26,
          y: -55,
          width: 5,
          height: 30
        }, {
          x: 15,
          y: -45,
          width: 5,
          height: 30
        }, {
          x: 4,
          y: -35,
          width: 5,
          height: 30
        }];
        /** 障害物のあたり判定矩形配列：プテラノドン */

        define.COLLISIONS_PTERANODON = [{
          x: 12,
          y: 200,
          width: 64,
          height: 23
        }];
        /** 障害物に対する背景物のスクロール速度比 */

        define.LANDMARK_SCROLL_RATE = 1;
        /** 背景物の下端のY座標 */

        define.LANDMARK_BOTTOM_Y = 355;
        /** 背景物の配置位置情報配列 */

        define.LANDMARK_PLACEINFO = [{
          frameName: assetInfo_1.AssetInfo.bgObj.frames.bgObj01,
          x: -61 * 30
        }, {
          frameName: assetInfo_1.AssetInfo.bgObj.frames.bgObj03,
          x: 80 * 30
        }, {
          frameName: assetInfo_1.AssetInfo.bgObj.frames.bgObj02,
          x: 620 * 30
        }, //ウシ
        {
          frameName: assetInfo_1.AssetInfo.bgObj.frames.bgObj04,
          x: 360 * 30
        }, {
          frameName: assetInfo_1.AssetInfo.bgObj.frames.bgObj05,
          x: 480 * 30
        }, {
          frameName: assetInfo_1.AssetInfo.bgObj.frames.bgObj07,
          x: 640 * 30
        }, //木
        {
          frameName: assetInfo_1.AssetInfo.bgObj.frames.bgObj06,
          x: 790 * 30
        }, //トラック 
        {
          frameName: assetInfo_1.AssetInfo.bgObj.frames.bgObj08,
          x: 720 * 30
        }, {
          frameName: assetInfo_1.AssetInfo.bgObj.frames.bgObj09,
          x: 850 * 30
        }];
        /** マップの終端座標 */

        define.MAP_END_PIXEL = 30630 + 88 + 640;
        /** マップループ時開始座標 */

        define.MAP_REPEATED_START_PIXEL = -1500;
      })(define = exports.define || (exports.define = {}));
    }, {
      "./assetInfo": 32
    }],
    34: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var waveGame_1 = require("./waveGame");
      /**
       * GameBaseの実装クラスのインスタンス生成を行うだけのクラス
       * GameSubsceneに対して実装クラスの名前を隠ぺいする
       */


      var GameCreator =
      /** @class */
      function () {
        function GameCreator() {}
        /**
         * GameBaseの実装クラスのインスタンスを生成する
         * @param {g.Scene}  _scene インスタンス生成に使用するScene
         * @return {GameBase} 生成されたインスタンス
         */


        GameCreator.createGame = function (_scene) {
          return new waveGame_1.WaveGame(_scene);
        };

        return GameCreator;
      }();

      exports.GameCreator = GameCreator;
    }, {
      "./waveGame": 40
    }],
    35: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var commonParameterReader_1 = require("../commonNicowariGame/commonParameterReader");

      var miscAssetInfo_1 = require("./miscAssetInfo");
      /**
       * ゲーム固有パラメータの読み込みクラス
       * 省略されたパラメータ項目の補完などを行う
       */


      var GameParameterReader =
      /** @class */
      function () {
        function GameParameterReader() {}
        /**
         * 起動パラメータから対応するメンバ変数を設定する
         * @param {g.Scene} _scene Sceneインスタンス
         */


        GameParameterReader.read = function (_scene) {
          this.startPixel = 0;

          if (!commonParameterReader_1.CommonParameterReader.nicowari) {
            if (commonParameterReader_1.CommonParameterReader.useDifficulty) {
              // 難易度指定によるパラメータを設定
              this.loadFromJson(_scene);
            } else {
              var param = _scene.game.vars.parameters;

              if (typeof param.startPixel === "number") {
                this.startPixel = param.startPixel;
              }
            }
          }
        };
        /**
         * JSONから難易度指定によるパラメータを設定
         * @param {g.Scene} _scene Sceneインスタンス
         */


        GameParameterReader.loadFromJson = function (_scene) {
          var difficultyJson = JSON.parse(_scene.assets[miscAssetInfo_1.MiscAssetInfo.difficultyData.name].data);
          var difficultyList = difficultyJson.difficultyParameterList;

          if (difficultyList.length === 0) {
            return;
          }

          var index = 0;

          for (var i = difficultyList.length - 1; i >= 0; --i) {
            if (difficultyList[i].minimumDifficulty <= commonParameterReader_1.CommonParameterReader.difficulty) {
              index = i; // console.log("minimumDifficulty[" + i + "]:" + difficultyList[i].minimumDifficulty + ".");

              break;
            }
          }

          if (typeof difficultyList[index].startPixel === "number") {
            this.startPixel = difficultyList[index].startPixel;
          }
        };

        return GameParameterReader;
      }();

      exports.GameParameterReader = GameParameterReader;
    }, {
      "../commonNicowariGame/commonParameterReader": 42,
      "./miscAssetInfo": 36
    }],
    36: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 画像以外のアセット関連の静的情報
       */

      var MiscAssetInfo =
      /** @class */
      function () {
        function MiscAssetInfo() {} // tslint:disable-next-line:typedef


        MiscAssetInfo.mapData = {
          name: "json_map01",

          /** tiledデータのオブジェクト種別名 */
          objectType: {
            /** tiledデータのオブジェクト種別名：カモメ */
            gull: "enemy_01",

            /** tiledデータのオブジェクト種別名：岩 */
            rock: "enemy_02",

            /** tiledデータのオブジェクト種別名：サメ */
            shark: "enemy_03",

            /** tiledデータのオブジェクト種別名：プテラノドン */
            pteranodon: "enemy_04"
          }
        }; // tslint:disable-next-line:typedef

        MiscAssetInfo.difficultyData = {
          name: "json_difficultyParameters"
        };
        return MiscAssetInfo;
      }();

      exports.MiscAssetInfo = MiscAssetInfo;
    }, {}],
    37: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var define_1 = require("./define");

      var asaInfo_1 = require("./asaInfo");

      var miscAssetInfo_1 = require("./miscAssetInfo");

      var soundInfo_1 = require("./soundInfo");

      var assetInfo_1 = require("./assetInfo");

      var entityUtil_1 = require("../util/entityUtil");

      var spriteUtil_1 = require("../util/spriteUtil");

      var tiledUtil_1 = require("../util/tiledUtil");

      var audioUtil_1 = require("../util/audioUtil");

      var asaEx_1 = require("../util/asaEx");

      var gameParameterReader_1 = require("./gameParameterReader");

      var commonParameterReader_1 = require("../commonNicowariGame/commonParameterReader");
      /** 障害物種別 */


      var ObstacleType;

      (function (ObstacleType) {
        /** enemy_01 */
        ObstacleType[ObstacleType["GULL"] = 0] = "GULL";
        /** enemy_02 */

        ObstacleType[ObstacleType["ROCK"] = 1] = "ROCK";
        /** enemy_03 */

        ObstacleType[ObstacleType["SHARK"] = 2] = "SHARK";
        /** enemy_04 */

        ObstacleType[ObstacleType["PTERANODON"] = 3] = "PTERANODON";
      })(ObstacleType = exports.ObstacleType || (exports.ObstacleType = {}));
      /**
       * スクロールを管理し、障害物を表示、管理するクラス
       */


      var ObstacleManager =
      /** @class */
      function (_super) {
        __extends(ObstacleManager, _super);
        /**
         * コンストラクタ
         * @param  {g.Scene} _scene Sceneインスタンス
         */


        function ObstacleManager(_scene) {
          return _super.call(this, {
            scene: _scene
          }) || this;
        }
        /**
         * ObstaclePlaceInfoをx座標昇順でソートするためのコンパレータ関数
         * @param {ObstaclePlaceInfo} _a 比較するObstaclePlaceInfo
         * @param {ObstaclePlaceInfo} _b 比較するObstaclePlaceInfo
         * @return {number} 比較結果
         */


        ObstacleManager.compareObstaclePlaceInfo = function (_a, _b) {
          return _a.x - _b.x;
        };
        /**
         * このクラスで使用するオブジェクトを生成するメソッド
         * @param {g.E} _landmarkLayer 背景物用のレイヤー
         * @param {g.E} _swimmerLayer 水中障害物用のレイヤー
         * @param {g.E} _fryerLayer 空中障害物用のレイヤー
         */


        ObstacleManager.prototype.init = function (_landmarkLayer, _swimmerLayer, _fryerLayer) {
          this.landmarkLayer = _landmarkLayer;
          this.swimmerLayer = _swimmerLayer;
          this.fryerLayer = _fryerLayer;
          this.obstaclePlaceInfos = this.makeObstaclePlaceInfos();
          this.liveObstacles = [];
          this.liveLandmarks = [];
          this.spoLandmark = spriteUtil_1.spriteUtil.createSpriteParameter(assetInfo_1.AssetInfo.bgObj);
          this.sfmLandmark = spriteUtil_1.spriteUtil.createSpriteFrameMap(assetInfo_1.AssetInfo.bgObj);
        };
        /**
         * 初期表示時の処理を行うメソッド
         */


        ObstacleManager.prototype.showContent = function () {
          this.isScrolling = false;
          this.scrolledPixelCount = gameParameterReader_1.GameParameterReader.startPixel;
          this.scrolledSubPixel = 0;
          this.scrolledMeterCount = 0;
          this.scrolledSubMeter = 0;
          entityUtil_1.entityUtil.setX(this, this.scene.game.width);
          entityUtil_1.entityUtil.setX(this.landmarkLayer, this.x);
          entityUtil_1.entityUtil.setX(this.swimmerLayer, this.x);
          entityUtil_1.entityUtil.setX(this.fryerLayer, this.x);
          entityUtil_1.entityUtil.setX(this, this.scene.game.width - this.scrolledPixelCount);
          entityUtil_1.entityUtil.setX(this.landmarkLayer, this.scene.game.width - (this.scrolledPixelCount * define_1.define.LANDMARK_SCROLL_RATE | 0));
          entityUtil_1.entityUtil.setX(this.swimmerLayer, this.x);
          entityUtil_1.entityUtil.setX(this.fryerLayer, this.x);
          this.landmarkInfoIndex = 0;
          this.checkLandmarkPlaceInfo(); // 背景物の表示開始判定

          this.placeInfoIndex = 0;
          this.checkObstaclePlaceInfo(); // 障害物の表示開始判定

          this.checkObstaclePlaceInfo(); // 障害物の表示開始判定
          // 表示中の障害物のactorのmodified/calcを行う

          this.updateObstacleActor();
        };
        /**
         * 表示終了時の処理を行うメソッド
         */


        ObstacleManager.prototype.hideContent = function () {
          this.clearLandmarks(); // 表示中の背景物情報をクリアする

          this.clearObstacles(); // 表示中の障害物情報をクリアする
        };
        /**
         * スクロールを開始するメソッド
         */


        ObstacleManager.prototype.startScroll = function () {
          this.isScrolling = true;
        };
        /**
         * スクロールを停止するメソッド
         */


        ObstacleManager.prototype.stopScroll = function () {
          this.isScrolling = false;
        };
        /**
         * スクロールしたメートル数を取得するメソッド
         * @return {number} スクロールしたメートル数
         */


        ObstacleManager.prototype.getScrolledMeter = function () {
          return this.scrolledMeterCount;
        };
        /**
         * フレームごとの処理を行うメソッド
         * @param {number} _scrollFactor スクロール加速割合（0～1）
         */


        ObstacleManager.prototype.onUpdate = function (_scrollFactor) {
          if (this.isScrolling) {
            this.incrementScrollFrame(_scrollFactor);
            entityUtil_1.entityUtil.setX(this, this.scene.game.width - this.scrolledPixelCount);
            entityUtil_1.entityUtil.setX(this.landmarkLayer, this.scene.game.width - (this.scrolledPixelCount * define_1.define.LANDMARK_SCROLL_RATE | 0));
            entityUtil_1.entityUtil.setX(this.swimmerLayer, this.x);
            entityUtil_1.entityUtil.setX(this.fryerLayer, this.x);
            this.checkLandmarkLifeTime(); // 表示中の背景物の表示終了判定

            this.checkLandmarkPlaceInfo(); // 背景物の表示開始判定

            this.checkObstacleLifeTime(); // 表示中の障害物の表示終了判定

            this.checkObstaclePlaceInfo(); // 障害物の表示開始判定
            // 表示中の障害物のactorのmodified/calcを行う

            this.updateObstacleActor();
          }
        };
        /**
         * PCと障害物の衝突判定を行うメソッド
         * @param {g.CommonArea} _pcRect PCの衝突判定領域
         * @return {boolean} 障害物に衝突した場合はtrue
         */


        ObstacleManager.prototype.checkCollision = function (_pcRect) {
          if (define_1.define.DEBUG_COLLISION) {
            return false;
          }

          var lives = this.liveObstacles;
          var iEnd = lives.length;

          for (var i = 0; i < iEnd; ++i) {
            var actor = lives[i].actor;
            var pos = {
              x: actor.x + this.x,
              y: actor.y + this.y
            };
            var info = this.obstaclePlaceInfos[lives[i].placeInfoIndex];

            if (info.type === ObstacleType.PTERANODON) {
              var offset = actor.getBonePosition(define_1.define.PTERANODON_PIVOT_NAME);
              pos.x += offset.x;
              pos.y += offset.y;
            }

            if (this.checkCollisionCore(_pcRect, pos, lives[i].collisions)) {
              this.playCollisionSe(info.type);
              return true;
            }
          }

          return false;
        };
        /**
         * 障害物配置情報を生成するメソッド
         * @return {ObstaclePlaceInfo[]} 障害物配置情報配列
         */


        ObstacleManager.prototype.makeObstaclePlaceInfos = function () {
          var objectType = miscAssetInfo_1.MiscAssetInfo.mapData.objectType;
          var typeTable = {};
          typeTable[objectType.gull] = ObstacleType.GULL;
          typeTable[objectType.rock] = ObstacleType.ROCK;
          typeTable[objectType.shark] = ObstacleType.SHARK;
          typeTable[objectType.pteranodon] = ObstacleType.PTERANODON;
          var placeInfos = [];
          var objects = tiledUtil_1.tiledUtil.getObjects(miscAssetInfo_1.MiscAssetInfo.mapData.name, undefined, false, true);
          var iEnd = objects.length;

          for (var i = 0; i < iEnd; ++i) {
            var object = objects[i];

            if (!typeTable.hasOwnProperty(object.type)) {
              continue;
            }

            placeInfos[placeInfos.length] = {
              type: typeTable[object.type],
              x: object.x,
              y: object.y
            };
          }

          placeInfos.sort(ObstacleManager.compareObstaclePlaceInfo);
          return placeInfos;
        };
        /**
         * スクロールを1フレーム分進めるメソッド
         * @param {number} _scrollFactor スクロール加速割合（0～1）
         */


        ObstacleManager.prototype.incrementScrollFrame = function (_scrollFactor) {
          // ニコ割ではない場合かつマップ終端に到達した場合、マップを繰り返す
          if (!commonParameterReader_1.CommonParameterReader.nicowari) {
            if (this.scrolledPixelCount > define_1.define.MAP_END_PIXEL) {
              this.scrolledPixelCount = define_1.define.MAP_REPEATED_START_PIXEL;
              this.scrolledSubPixel = 0;
              this.landmarkInfoIndex = 0;
              this.placeInfoIndex = 0;
              this.clearObstacles();
              this.clearLandmarks();
            }
          }

          var pixelAdder = (define_1.define.SCROLL_FACTOR_MAX - 1) * _scrollFactor * define_1.define.SCROLL_PX_PER_FRAME_NUM; // console.log("incrementScrollFrame: pixelAdder:" + pixelAdder + ", _scrollFactor:" + _scrollFactor + ".");

          this.scrolledSubPixel += define_1.define.SCROLL_PX_PER_FRAME_NUM + pixelAdder;

          while (this.scrolledSubPixel >= define_1.define.SCROLL_PX_PER_FRAME_DENOM) {
            ++this.scrolledPixelCount;
            this.scrolledSubPixel -= define_1.define.SCROLL_PX_PER_FRAME_DENOM;
            this.scrolledSubMeter += define_1.define.SCROLL_METER_PER_PX_NUM;

            while (this.scrolledSubMeter >= define_1.define.SCROLL_METER_PER_PX_DENOM) {
              ++this.scrolledMeterCount;
              this.scrolledSubMeter -= define_1.define.SCROLL_METER_PER_PX_DENOM;
            }
          }
        };
        /**
         * スクロール位置に対応した背景物表示開始判定を行うメソッド
         */


        ObstacleManager.prototype.checkLandmarkPlaceInfo = function () {
          var appearLine = this.scrolledPixelCount * define_1.define.SCROLL_METER_PER_PX_NUM / define_1.define.SCROLL_METER_PER_PX_DENOM;
          var infos = define_1.define.LANDMARK_PLACEINFO;
          var index = this.landmarkInfoIndex;

          while (index < infos.length && infos[index].x < appearLine) {
            this.appearLandmark(index);
            ++index;
            this.landmarkInfoIndex = index;
          }
        };
        /**
         * 背景物の表示開始処理を行うメソッド
         * @param {number} _index 対象の背景物配置情報のインデックス
         */


        ObstacleManager.prototype.appearLandmark = function (_index) {
          var info = define_1.define.LANDMARK_PLACEINFO[_index];
          var sprite = spriteUtil_1.spriteUtil.createFrameSprite(this.spoLandmark, this.sfmLandmark, info.frameName);
          sprite.x = info.x * define_1.define.LANDMARK_SCROLL_RATE / define_1.define.SCROLL_METER_PER_PX_NUM * define_1.define.SCROLL_METER_PER_PX_DENOM;
          sprite.y = define_1.define.LANDMARK_BOTTOM_Y - sprite.height;
          entityUtil_1.entityUtil.appendEntity(sprite, this.landmarkLayer);
          this.liveLandmarks[this.liveLandmarks.length] = {
            placeInfoIndex: _index,
            sprite: sprite
          };
        };
        /**
         * 表示中の背景物の表示終了判定と表示終了処理を行うメソッド
         */


        ObstacleManager.prototype.checkLandmarkLifeTime = function () {
          var deadLine = 0 - this.landmarkLayer.x;
          var survivals = [];
          var lives = this.liveLandmarks;
          var iEnd = lives.length;

          for (var i = 0; i < iEnd; ++i) {
            var survived = true;

            if (lives[i].sprite.x + lives[i].sprite.width < deadLine) {
              survived = false;
            }

            if (survived) {
              survivals[survivals.length] = lives[i];
            } else {
              lives[i].sprite.destroy();
              lives[i].sprite = null;
            }
          }

          this.liveLandmarks.length = 0;
          this.liveLandmarks = survivals;
        };
        /**
         * スクロール位置に対応した障害物表示開始判定を行うメソッド
         */


        ObstacleManager.prototype.checkObstaclePlaceInfo = function () {
          var appearLine = define_1.define.OBSTACLE_APPEAR_AREA_WIDTH + this.scrolledPixelCount;
          var infos = this.obstaclePlaceInfos;
          var index = this.placeInfoIndex;

          while (index < infos.length && infos[index].x < appearLine) {
            this.appearObstacle(index);
            ++index;
            this.placeInfoIndex = index;
          }
        };
        /**
         * 障害物の表示開始処理を行うメソッド
         * @param {number} _index 対象の障害物配置情報のインデックス
         */


        ObstacleManager.prototype.appearObstacle = function (_index) {
          var info = this.obstaclePlaceInfos[_index];
          var animName = asaInfo_1.AsaInfo.obstacle.anim.gull;
          var collisions = [];
          var parent = this;

          switch (info.type) {
            case ObstacleType.GULL:
              animName = asaInfo_1.AsaInfo.obstacle.anim.gull;
              collisions = define_1.define.COLLISIONS_GULL;
              parent = this.fryerLayer;
              break;

            case ObstacleType.ROCK:
              animName = asaInfo_1.AsaInfo.obstacle.anim.rock;
              collisions = define_1.define.COLLISIONS_ROCK;
              parent = this.swimmerLayer;
              break;

            case ObstacleType.SHARK:
              animName = asaInfo_1.AsaInfo.obstacle.anim.shark;
              collisions = define_1.define.COLLISIONS_SHARK;
              parent = this.fryerLayer;
              break;

            case ObstacleType.PTERANODON:
              animName = asaInfo_1.AsaInfo.obstacle.anim.pteranodon;
              collisions = define_1.define.COLLISIONS_PTERANODON;
              parent = this.fryerLayer;
              break;
          }

          var actor = new asaEx_1.asaEx.Actor(this.scene, asaInfo_1.AsaInfo.obstacle.pj, animName);
          actor.x = info.x;
          actor.y = info.y;
          entityUtil_1.entityUtil.appendEntity(actor, parent);

          if (define_1.define.DEBUG_SHOW_COLLISION_RECT) {
            for (var i = 0; i < collisions.length; ++i) {
              var rectCollision = new g.FilledRect({
                scene: this.scene,
                cssColor: define_1.define.DEBUG_COLLISION_RECT_COLOR,
                width: collisions[i].width,
                height: collisions[i].height
              });
              rectCollision.x = collisions[i].x;
              rectCollision.y = collisions[i].y;
              rectCollision.opacity = define_1.define.DEBUG_COLLISION_RECT_OPACITY;
              entityUtil_1.entityUtil.appendEntity(rectCollision, actor);
            }
          }

          if (info.type === ObstacleType.PTERANODON) {
            actor.modified();
            actor.calc();
            actor.pause = true;
            actor.loop = false;
          }

          this.liveObstacles[this.liveObstacles.length] = {
            placeInfoIndex: _index,
            actor: actor,
            collisions: collisions
          }; // console.log(this.fryerLayer.children.length);
        };
        /**
         * 表示中の障害物の表示終了判定と表示終了処理を行うメソッド
         */


        ObstacleManager.prototype.checkObstacleLifeTime = function () {
          var deadLine = 0 - this.scene.game.width - define_1.define.OBSTACLE_WIDTH_TO_VANISH_AREA + this.scrolledPixelCount;
          var survivals = [];
          var lives = this.liveObstacles;
          var iEnd = lives.length;

          for (var i = 0; i < iEnd; ++i) {
            var survived = true;

            if (lives[i].actor.x > deadLine) {
              if (!this.checkPteranodonLifeCycle(lives[i])) {
                survived = false;
              }
            }

            if (survived) {
              survivals[survivals.length] = lives[i];
            } else {
              lives[i].actor.destroy();
              lives[i].actor = null;
            }
          }

          this.liveObstacles.length = 0;
          this.liveObstacles = survivals;
        };
        /**
         * プテラノドン固有の状態変化処理を行うメソッド
         * @param {LiveObstacleInfo} _live 処理対象がのLiveObstacleInfo
         * @return {boolean} 処理対象がプテラノドンで、表示終了する場合はfalse
         */


        ObstacleManager.prototype.checkPteranodonLifeCycle = function (_live) {
          var info = this.obstaclePlaceInfos[_live.placeInfoIndex];

          if (info.type !== ObstacleType.PTERANODON) {
            return true;
          }

          var actor = _live.actor;

          if (actor.pause && actor.currentFrame < actor.animation.frameCount - 1) {
            if (actor.x + this.x > define_1.define.PTERANODON_WAKE_X) {
              return true;
            } // アニメ開始位置まで到達した時の処理


            actor.pause = false;
          } else {
            if (actor.currentFrame === actor.animation.frameCount - 1) {
              // 表示終了する場合
              return false;
            }
          }

          actor.x = define_1.define.PTERANODON_WAKE_X - this.x; // この後modified/calcされるはずなのでここでのmodifiedは省略

          return true;
        };
        /**
         * 表示中の障害物のactorのmodified/calcを行うメソッド
         */


        ObstacleManager.prototype.updateObstacleActor = function () {
          var lives = this.liveObstacles;
          var iEnd = lives.length;

          for (var i = 0; i < iEnd; ++i) {
            var actor = lives[i].actor;
            actor.modified();
            actor.calc();

            if (define_1.define.DEBUG_SHOW_COLLISION_RECT) {
              var info = this.obstaclePlaceInfos[lives[i].placeInfoIndex];

              if (info.type === ObstacleType.PTERANODON) {
                var offset = actor.getBonePosition(define_1.define.PTERANODON_PIVOT_NAME);

                for (var j = 0; j < actor.children.length; ++j) {
                  entityUtil_1.entityUtil.setXY(actor.children[j], lives[i].collisions[j].x + offset.x, lives[i].collisions[j].y + offset.y);
                }
              }
            }
          }
        };
        /**
         * 表示中の背景物をすべて消去するメソッド
         */


        ObstacleManager.prototype.clearLandmarks = function () {
          var lives = this.liveLandmarks;
          var iEnd = lives.length;

          for (var i = 0; i < iEnd; ++i) {
            lives[i].sprite.destroy();
            lives[i].sprite = null;
          }

          this.liveLandmarks.length = 0;
        };
        /**
         * 表示中の障害物をすべて消去するメソッド
         */


        ObstacleManager.prototype.clearObstacles = function () {
          var lives = this.liveObstacles;
          var iEnd = lives.length;

          for (var i = 0; i < iEnd; ++i) {
            lives[i].actor.destroy();
            lives[i].actor = null;
          }

          this.liveObstacles.length = 0;
        };
        /**
         * 矩形と障害物の衝突判定を行うメソッド
         * @param  {g.CommonArea} _rect 判定対象1の領域
         * @param  {g.CommonOffset} _pos 判定対象2の基準位置
         * @param  {g.CommonArea[]} _collisions _posからの相対領域配列
         * @return {boolean} 衝突した場合はtrue
         */


        ObstacleManager.prototype.checkCollisionCore = function (_rect, _pos, _collisions) {
          var iEnd = _collisions.length;

          for (var i = 0; i < iEnd; ++i) {
            var collision = {
              x: _pos.x + _collisions[i].x,
              y: _pos.y + _collisions[i].y,
              width: _collisions[i].width,
              height: _collisions[i].height
            };

            if (g.Collision.intersectAreas(_rect, collision)) {
              return true;
            }
          }

          return false;
        };
        /**
         * 衝突時のSEを再生する
         * @param {ObstacleType} type 衝突した障害物の種別
         */


        ObstacleManager.prototype.playCollisionSe = function (type) {
          var seName = ""; // no sound

          switch (type) {
            case ObstacleType.GULL:
              seName = soundInfo_1.SoundInfo.seSet.gull;
              break;

            case ObstacleType.SHARK:
              seName = soundInfo_1.SoundInfo.seSet.shark;
              break;

            case ObstacleType.PTERANODON:
              seName = soundInfo_1.SoundInfo.seSet.pteranodon;
              break;
          }

          audioUtil_1.audioUtil.play(seName);
        };

        return ObstacleManager;
      }(g.E);

      exports.ObstacleManager = ObstacleManager;
    }, {
      "../commonNicowariGame/commonParameterReader": 42,
      "../util/asaEx": 59,
      "../util/audioUtil": 60,
      "../util/entityUtil": 61,
      "../util/spriteUtil": 63,
      "../util/tiledUtil": 64,
      "./asaInfo": 31,
      "./assetInfo": 32,
      "./define": 33,
      "./gameParameterReader": 35,
      "./miscAssetInfo": 36,
      "./soundInfo": 38
    }],
    38: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 音声アセット関連の静的情報
       */

      var SoundInfo =
      /** @class */
      function () {
        function SoundInfo() {}
        /** SE名のマップ */
        // tslint:disable-next-line:typedef


        SoundInfo.seSet = {
          tap: "se_wave_tap",
          gull: "se_comedy10",
          shark: "se_character16",
          pteranodon: "se_character03",
          miss: "se_No4_Miss",
          gameover: ""
        };
        /** BGM名のマップ */
        // tslint:disable-next-line:typedef

        SoundInfo.bgmSet = {
          title: "bgm_nico_wave",
          main: "bgm_nico_wave"
        };
        return SoundInfo;
      }();

      exports.SoundInfo = SoundInfo;
    }, {}],
    39: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var commonDefine_1 = require("../common/commonDefine");

      var entityUtil_1 = require("../util/entityUtil");

      var gameUtil_1 = require("../util/gameUtil");

      var define_1 = require("./define");
      /**
       * 残り時間の管理、表示を行うクラス
       * 残り時間警告の演出も管理する。
       */


      var TimerLabel =
      /** @class */
      function (_super) {
        __extends(TimerLabel, _super);
        /**
         * コンストラクタ
         * @param  {g.Scene} _scene Sceneインスタンス
         */


        function TimerLabel(_scene) {
          var _this = _super.call(this, {
            scene: _scene
          }) || this;

          _this.timeCaution = new g.Trigger();
          _this.timeCautionCancel = new g.Trigger();
          return _this;
        }
        /**
         * 表示系以外のオブジェクトをdestroyするメソッド
         * 表示系のオブジェクトはg.Eのdestroyに任せる。
         * @override
         */


        TimerLabel.prototype.destroy = function () {
          if (this.destroyed()) {
            return;
          }

          if (this.timeCaution) {
            this.timeCaution.destroy();
            this.timeCaution = null;
          }

          if (this.timeCautionCancel) {
            this.timeCautionCancel.destroy();
            this.timeCautionCancel = null;
          }

          _super.prototype.destroy.call(this);
        };
        /**
         * フォントのアセット情報を渡してラベルを生成するメソッド
         * @param {AssetInfoType} _numBlackInfo 黒文字のアセット情報
         * @param {AssetInfoType} _numRedInfo 赤文字のアセット情報
         */


        TimerLabel.prototype.createLabel = function (_numBlackInfo, _numRedInfo) {
          this.remainFrameCount = 0;
          this.currentCount = 0;
          var fontBlack = gameUtil_1.gameUtil.createNumFontWithAssetInfo(_numBlackInfo);
          var labelBlack = this.labelBlack = entityUtil_1.entityUtil.createNumLabel(this.scene, fontBlack, define_1.define.GAME_TIMER_DIGIT);
          entityUtil_1.entityUtil.appendEntity(labelBlack, this);
          var scaleLayer = this.scaleLayer = new g.E({
            scene: this.scene
          });
          entityUtil_1.entityUtil.appendEntity(scaleLayer, this);
          var fontRed = gameUtil_1.gameUtil.createNumFontWithAssetInfo(_numRedInfo);
          var labelRed = this.labelRed = entityUtil_1.entityUtil.createNumLabel(this.scene, fontRed, define_1.define.GAME_TIMER_DIGIT);
          entityUtil_1.entityUtil.appendEntity(labelRed, scaleLayer);
          this.stopBlink();
        };
        /**
         * 右端の数字の左上を指定してラベルの位置を設定するメソッド
         * @param {number} _x 右端の数字の左上のx座標
         * @param {number} _y 右端の数字の左上のy座標
         */


        TimerLabel.prototype.moveLabelTo = function (_x, _y) {
          if (!this.labelBlack) {
            return;
          } // 点滅時の拡大基準点


          var label = this.labelBlack;
          var font = label.bitmapFont;
          var pivotX = _x + font.defaultGlyphWidth / 2;
          var pivotY = _y + font.defaultGlyphHeight / 2;
          entityUtil_1.entityUtil.setXY(this.scaleLayer, pivotX, pivotY); // ラベルの左上

          var labelX = _x + font.defaultGlyphWidth - label.width;
          var labelY = _y;
          entityUtil_1.entityUtil.setXY(this.labelBlack, labelX, labelY);
          entityUtil_1.entityUtil.setXY(this.labelRed, labelX - pivotX, labelY - pivotY);
        };
        /**
         * 現在の残り秒数を設定するメソッド
         * @param {number} _seconds 設定する値
         */


        TimerLabel.prototype.setTimeCount = function (_seconds) {
          this.setTimeFrameCount(gameUtil_1.gameUtil.sec2Frame(_seconds));
        };
        /**
         * 現在の残り秒数をフレーム数で設定するメソッド
         * @param {number} _frames 設定する値
         */


        TimerLabel.prototype.setTimeFrameCount = function (_frames) {
          this.remainFrameCount = _frames;
          this.renewCurrentNumber(true);
        };
        /**
         * 現在の残り秒数を取得するメソッド（小数部は切り上げる）
         * @return {number} 秒数
         */


        TimerLabel.prototype.getTimeCount = function () {
          return Math.ceil(gameUtil_1.gameUtil.frame2Sec(this.remainFrameCount));
        };
        /**
         * 現在の残り秒数を取得するメソッド（小数部あり）
         * @return {number} 秒数
         */


        TimerLabel.prototype.getTimeCountReal = function () {
          return gameUtil_1.gameUtil.frame2Sec(this.remainFrameCount);
        };
        /**
         * 現在の残り秒数をフレーム数で取得するメソッド
         * @return {number} フレーム数
         */


        TimerLabel.prototype.getTimeFrameCount = function () {
          return this.remainFrameCount;
        };
        /**
         * 点滅状態を取得するメソッド
         * @return {boolean} 点滅中ならばtrue
         */


        TimerLabel.prototype.isBlinking = function () {
          return this.isBlinking_;
        };
        /**
         * 1フレーム分時間を進めるメソッド
         */


        TimerLabel.prototype.tick = function () {
          if (this.remainFrameCount > 0) {
            --this.remainFrameCount; // remainFrameCountの値が小数である場合を考慮した条件

            if (this.remainFrameCount < 0) {
              this.remainFrameCount = 0;
            }

            this.renewCurrentNumber();
          }
        };
        /**
         * 残り時間によらず赤点滅演出を終了するメソッド
         */


        TimerLabel.prototype.forceStopBlink = function () {
          if (this.isBlinking_) {
            this.stopBlink();
          }
        };
        /**
         * 残り時間表示の更新を行うメソッド
         * opt_isForceがtrueでなければ現在の表示内容と変化がある場合のみ
         * ラベル内容を設定する
         * @param {boolean = false} opt_isForce (optional)強制設定フラグ
         */


        TimerLabel.prototype.renewCurrentNumber = function (opt_isForce) {
          if (opt_isForce === void 0) {
            opt_isForce = false;
          }

          var seconds = this.getTimeCount();

          if (opt_isForce || seconds !== this.currentCount) {
            var text = String(seconds);
            entityUtil_1.entityUtil.setLabelText(this.labelBlack, text);
            entityUtil_1.entityUtil.setLabelText(this.labelRed, text);
            this.currentCount = seconds;
            this.checkBlinkState();
          }
        };
        /**
         * 赤点滅状態を確認、更新するメソッド
         */


        TimerLabel.prototype.checkBlinkState = function () {
          if (this.currentCount > 0 && this.currentCount < define_1.define.CAUTION_TIME_CONDITION) {
            if (!this.isBlinking_) {
              this.startBlink();
            }
          } else {
            if (this.isBlinking_) {
              this.stopBlink();
            }
          }
        };
        /**
         * 赤点滅演出を開始するメソッド
         */


        TimerLabel.prototype.startBlink = function () {
          this.isBlinking_ = true;
          this.setTween();
          entityUtil_1.entityUtil.hideEntity(this.labelBlack);
          entityUtil_1.entityUtil.showEntity(this.labelRed);
          this.timeCaution.fire();
        };
        /**
         * 赤点滅演出を終了するメソッド
         */


        TimerLabel.prototype.stopBlink = function () {
          this.isBlinking_ = false;
          entityUtil_1.entityUtil.hideEntity(this.labelRed);
          entityUtil_1.entityUtil.showEntity(this.labelBlack);
          this.timeCautionCancel.fire(); // stopBlinkのあと実行中のtweenが終了する前にstartBlinkされると
          // 正常に動かないが仕様上起きない前提とする。
        };
        /**
         * 赤点滅一周期分のtweenを設定するメソッド
         */


        TimerLabel.prototype.setTween = function () {
          var _this = this;

          var scaleOff = commonDefine_1.commonDefine.CAUTION_TIME_SCALE_OFF;
          var scaleOn = commonDefine_1.commonDefine.CAUTION_TIME_SCALE_ON;
          entityUtil_1.entityUtil.setScale(this.scaleLayer, scaleOff);
          var timeline = this.scene.game.vars.scenedata.timeline;
          gameUtil_1.gameUtil.createTween(timeline, this.scaleLayer).to({
            scaleX: scaleOn,
            scaleY: scaleOn
          }, gameUtil_1.gameUtil.frame2MSec(commonDefine_1.commonDefine.CAUTION_TIME_ON)).to({
            scaleX: scaleOff,
            scaleY: scaleOff
          }, gameUtil_1.gameUtil.frame2MSec(commonDefine_1.commonDefine.CAUTION_TIME_OFF)).call(function () {
            if (_this.isBlinking_) {
              _this.setTween();
            }
          });
        };

        return TimerLabel;
      }(g.E);

      exports.TimerLabel = TimerLabel;
    }, {
      "../common/commonDefine": 49,
      "../util/entityUtil": 61,
      "../util/gameUtil": 62,
      "./define": 33
    }],
    40: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var define_1 = require("./define");

      var assetInfo_1 = require("./assetInfo");

      var soundInfo_1 = require("./soundInfo");

      var entityUtil_1 = require("../util/entityUtil");

      var spriteUtil_1 = require("../util/spriteUtil");

      var gameUtil_1 = require("../util/gameUtil");

      var audioUtil_1 = require("../util/audioUtil");

      var timerLabel_1 = require("./timerLabel");

      var waveManager_1 = require("./waveManager");

      var obstacleManager_1 = require("./obstacleManager");

      var gameParameterReader_1 = require("./gameParameterReader");

      var gameBase_1 = require("../commonNicowariGame/gameBase");

      var commonParameterReader_1 = require("../commonNicowariGame/commonParameterReader");
      /**
       * ニコニコウェーブゲームの実体を実装するクラス
       */


      var WaveGame =
      /** @class */
      function (_super) {
        __extends(WaveGame, _super);
        /**
         * コンストラクタ
         * @param  {g.Scene} _scene Sceneインスタンス
         */


        function WaveGame(_scene) {
          return _super.call(this, _scene) || this;
        }
        /**
         * このクラスで使用するオブジェクトを生成するメソッド
         * Scene#loadedを起点とする処理からコンストラクタの直後に呼ばれる。
         * このクラスはゲーム画面終了時も破棄されず、次のゲームで再利用される。
         * そのためゲーム状態の初期化はinitではなくshowContentで行う必要がある。
         * @override
         */


        WaveGame.prototype.init = function () {
          _super.prototype.init.call(this);

          var scene = this.scene;
          var spoUi = spriteUtil_1.spriteUtil.createSpriteParameter(assetInfo_1.AssetInfo.ui);
          var sfmUi = spriteUtil_1.spriteUtil.createSpriteFrameMap(assetInfo_1.AssetInfo.ui);
          gameParameterReader_1.GameParameterReader.read(scene);
          var landmarkLayer = new g.E({
            scene: scene
          });
          var swimmerLayer = new g.E({
            scene: scene
          });
          var fryerLayer = new g.E({
            scene: scene
          });
          landmarkLayer.moveTo(define_1.define.OFFSET_X, 0);
          swimmerLayer.moveTo(define_1.define.OFFSET_X, 0);
          fryerLayer.moveTo(define_1.define.OFFSET_X, 0);
          entityUtil_1.entityUtil.appendEntity(landmarkLayer, this);
          entityUtil_1.entityUtil.appendEntity(swimmerLayer, this);
          var obstacleManager = this.obstacleManager = new obstacleManager_1.ObstacleManager(scene);
          obstacleManager.moveTo(define_1.define.OFFSET_X, 0);
          obstacleManager.init(landmarkLayer, swimmerLayer, fryerLayer);
          entityUtil_1.entityUtil.appendEntity(obstacleManager, this);
          var waveManager = this.waveManager = new waveManager_1.WaveManager(scene);
          waveManager.moveTo(define_1.define.OFFSET_X, 0);
          waveManager.init();
          entityUtil_1.entityUtil.appendEntity(waveManager, this);
          entityUtil_1.entityUtil.appendEntity(fryerLayer, this);
          var iconT = spriteUtil_1.spriteUtil.createFrameSprite(spoUi, sfmUi, assetInfo_1.AssetInfo.ui.frames.iconT);
          iconT.moveTo(define_1.define.ICON_T_X, define_1.define.ICON_T_Y);
          entityUtil_1.entityUtil.appendEntity(iconT, this);
          var iconPt = spriteUtil_1.spriteUtil.createFrameSprite(spoUi, sfmUi, assetInfo_1.AssetInfo.ui.frames.iconPt);
          iconPt.moveTo(define_1.define.ICON_PT_X, define_1.define.ICON_PT_Y);
          entityUtil_1.entityUtil.appendEntity(iconPt, this);
          var timer = this.timerLabel = new timerLabel_1.TimerLabel(this.scene);
          timer.createLabel(assetInfo_1.AssetInfo.numBlack, assetInfo_1.AssetInfo.numRed);
          timer.moveLabelTo(define_1.define.GAME_TIMER_X, define_1.define.GAME_TIMER_Y);
          entityUtil_1.entityUtil.appendEntity(timer, this);
          var fontBlack = gameUtil_1.gameUtil.createNumFontWithAssetInfo(assetInfo_1.AssetInfo.numBlack);
          var score = this.scoreLabel = entityUtil_1.entityUtil.createNumLabel(this.scene, fontBlack, define_1.define.GAME_SCORE_DIGIT);
          entityUtil_1.entityUtil.moveNumLabelTo(score, define_1.define.GAME_SCORE_X, define_1.define.GAME_SCORE_Y);
          entityUtil_1.entityUtil.appendEntity(score, this);
        };
        /**
         * 表示系以外のオブジェクトをdestroyするメソッド
         * 表示系のオブジェクトはg.Eのdestroyに任せる。
         * @override
         */


        WaveGame.prototype.destroy = function () {
          _super.prototype.destroy.call(this);
        };
        /**
         * タイトル画面のBGMのアセット名を返すメソッド
         * 共通フロー側でBGMを鳴らさない場合は実装クラスでオーバーライドして
         * 空文字列を返すようにする
         * @return {string} アセット名
         * @override
         */


        WaveGame.prototype.getTitleBgmName = function () {
          return soundInfo_1.SoundInfo.bgmSet.title;
        };
        /**
         * ゲーム中のBGMのアセット名を返すメソッド
         * 共通フロー側でBGMを鳴らさない場合は実装クラスでオーバーライドして
         * 空文字列を返すようにする
         * @return {string} アセット名
         * @override
         */


        WaveGame.prototype.getMainBgmName = function () {
          return soundInfo_1.SoundInfo.bgmSet.main;
        };
        /**
         * 表示を開始するメソッド
         * ゲーム画面に遷移するワイプ演出で表示が始まる時点で呼ばれる。
         * @override
         */


        WaveGame.prototype.showContent = function () {
          this.inGame = false;
          this.inMiss = false;
          this.inHold = false;
          this.touchCoolingFrames = 0;
          this.obstacleManager.showContent();
          this.waveManager.showContent();
          this.scoreValue = 0;
          entityUtil_1.entityUtil.setLabelText(this.scoreLabel, String(this.scoreValue));
          var timeLimit = define_1.define.GAME_TIME;

          if (commonParameterReader_1.CommonParameterReader.useGameTimeLimit) {
            timeLimit = commonParameterReader_1.CommonParameterReader.gameTimeLimit;

            if (timeLimit > define_1.define.GAME_TIME_MAX) {
              timeLimit = define_1.define.GAME_TIME_MAX;
            }
          }

          this.timerLabel.setTimeCount(timeLimit);
          this.timerLabel.timeCaution.handle(this, this.onTimeCaution);
          this.timerLabel.timeCautionCancel.handle(this, this.onTimeCautionCancel);

          _super.prototype.showContent.call(this);
        };
        /**
         * ゲームを開始するメソッド
         * ReadyGo演出が完了した時点で呼ばれる。
         * @override
         */


        WaveGame.prototype.startGame = function () {
          this.inGame = true;
          this.obstacleManager.startScroll();
          this.waveManager.startGame();
          this.scene.pointDownCapture.handle(this, this.onTouch);

          if (define_1.define.DEBUG_HOLD_TO_UP) {
            this.scene.pointUpCapture.handle(this, this.onTouchOff);
          }
        };
        /**
         * 表示を終了するメソッド
         * このサブシーンから遷移するワイプ演出で表示が終わる時点で呼ばれる。
         * @override
         */


        WaveGame.prototype.hideContent = function () {
          this.obstacleManager.hideContent();
          this.timerLabel.timeCaution.removeAll(this);
          this.timerLabel.timeCautionCancel.removeAll(this);

          _super.prototype.hideContent.call(this);
        };
        /**
         * Scene#updateを起点とする処理から呼ばれるメソッド
         * ゲーム画面でない期間には呼ばれない。
         * @override
         */


        WaveGame.prototype.onUpdate = function () {
          if (this.inGame) {
            if (!this.inMiss) {
              this.obstacleManager.onUpdate(this.waveManager.getScrollFactor());
              this.checkScrolledMeter();
            }

            this.timerLabel.tick();

            if (!this.inMiss) {
              if (this.timerLabel.getTimeCount() === 0) {
                this.finishGame();
              }
            }
          }

          if (this.inGame) {
            if (this.touchCoolingFrames > 0) {
              --this.touchCoolingFrames;
            }

            if (define_1.define.DEBUG_HOLD_TO_UP) {
              if (this.inHold && this.waveManager.isTouchable()) {
                this.waveManager.onTouch();
              }
            }

            this.waveManager.onUpdate();

            if (this.inMiss) {
              if (this.waveManager.isTouchable()) {
                // ミス処理終了時
                this.inMiss = false;
              } else if (this.waveManager.isStartedPcReturn()) {// PC復帰演出開始時
              }
            } else {
              this.checkCollision(); // PCと障害物のあたり判定
            }
          }
        };
        /**
         * TimerLabel#timeCautionのハンドラ
         */


        WaveGame.prototype.onTimeCaution = function () {
          this.timeCaution.fire();
        };
        /**
         * TimerLabel#timeCautionCancelのハンドラ
         */


        WaveGame.prototype.onTimeCautionCancel = function () {
          this.timeCautionCancel.fire();
        };
        /**
         * 必要に応じてメートル数表示を更新するメソッド
         */


        WaveGame.prototype.checkScrolledMeter = function () {
          var scrolledMeter = this.obstacleManager.getScrolledMeter();

          if (this.scoreValue !== scrolledMeter) {
            this.scoreValue = scrolledMeter;

            if (this.scoreValue > define_1.define.SCORE_LIMIT) {
              this.scoreValue = define_1.define.SCORE_LIMIT;
            }

            gameUtil_1.gameUtil.updateGameStateScore(this.scoreValue);
            entityUtil_1.entityUtil.setLabelText(this.scoreLabel, String(this.scoreValue));
          }
        };
        /**
         * PCと障害物のあたり判定を行うメソッド
         */


        WaveGame.prototype.checkCollision = function () {
          if (this.waveManager.isRunup()) {
            return;
          }

          var pos = this.waveManager.getPcPosition();
          var rect = {
            x: pos.x + define_1.define.COLLISION_PC.x,
            y: pos.y + define_1.define.COLLISION_PC.y,
            width: define_1.define.COLLISION_PC.width,
            height: define_1.define.COLLISION_PC.height
          };

          if (this.obstacleManager.checkCollision(rect)) {
            // ミス処理
            audioUtil_1.audioUtil.play(soundInfo_1.SoundInfo.seSet.miss);
            this.inMiss = true;
            this.waveManager.onMiss();
          }
        };
        /**
         * ゲームを終了するメソッド
         * gameUtil.setGameScoreしたスコアが結果画面で表示される。
         * @param {boolean = false} opt_isLifeZero
         * (optional)ライフ消滅によるゲーム終了の場合はtrue
         */


        WaveGame.prototype.finishGame = function (opt_isLifeZero) {
          if (opt_isLifeZero === void 0) {
            opt_isLifeZero = false;
          }

          this.inGame = false;
          this.obstacleManager.stopScroll();
          this.scene.pointDownCapture.removeAll(this);

          if (define_1.define.DEBUG_HOLD_TO_UP) {
            this.scene.pointUpCapture.removeAll(this);
          }

          gameUtil_1.gameUtil.setGameScore(this.scoreValue); // 呼び出すトリガーによって共通フローのジングルアニメが変化する

          if (opt_isLifeZero) {
            this.gameOver.fire();
            this.timerLabel.forceStopBlink();
            audioUtil_1.audioUtil.play(soundInfo_1.SoundInfo.seSet.gameover);
          } else {
            this.timeup.fire();
          }
        };
        /**
         * Scene#pointDownCaptureのハンドラ
         * @param {g.PointDownEvent} _e イベントパラメータ
         * @return {boolean} ゲーム終了時はtrueを返す
         */


        WaveGame.prototype.onTouch = function (_e) {
          if (!this.inGame) {
            return true;
          }

          if (define_1.define.DEBUG_HOLD_TO_UP) {
            this.inHold = true;
          }

          if (this.inMiss || this.touchCoolingFrames > 0) {
            return false;
          }

          audioUtil_1.audioUtil.play(soundInfo_1.SoundInfo.seSet.tap);

          if (this.waveManager.isTouchable()) {
            this.waveManager.onTouch();
            this.touchCoolingFrames = define_1.define.TOUCH_COOLING_FRAMES;
          }

          return false;
        };
        /**
         * Scene#pointUpCaptureのハンドラ
         * @param {g.PointUpEvent} _e イベントパラメータ
         * @return {boolean} ゲーム終了時はtrueを返す
         */


        WaveGame.prototype.onTouchOff = function (_e) {
          if (!this.inGame) {
            return true;
          }

          if (define_1.define.DEBUG_HOLD_TO_UP) {
            this.inHold = false;
          }

          return false;
        };

        return WaveGame;
      }(gameBase_1.GameBase);

      exports.WaveGame = WaveGame;
    }, {
      "../commonNicowariGame/commonParameterReader": 42,
      "../commonNicowariGame/gameBase": 43,
      "../util/audioUtil": 60,
      "../util/entityUtil": 61,
      "../util/gameUtil": 62,
      "../util/spriteUtil": 63,
      "./assetInfo": 32,
      "./define": 33,
      "./gameParameterReader": 35,
      "./obstacleManager": 37,
      "./soundInfo": 38,
      "./timerLabel": 39,
      "./waveManager": 41
    }],
    41: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var define_1 = require("./define");

      var asaInfo_1 = require("./asaInfo");

      var entityUtil_1 = require("../util/entityUtil");

      var gameUtil_1 = require("../util/gameUtil");

      var asaEx_1 = require("../util/asaEx");
      /** PC状態 */


      var PcState;

      (function (PcState) {
        /** 通常 */
        PcState[PcState["NORMAL"] = 0] = "NORMAL";
        /** ダメージ */

        PcState[PcState["DAMAGE"] = 1] = "DAMAGE";
        /** 復帰 */

        PcState[PcState["RETURN"] = 2] = "RETURN";
      })(PcState = exports.PcState || (exports.PcState = {}));
      /** 波状態 */


      var WaveState;

      (function (WaveState) {
        /** 上昇 */
        WaveState[WaveState["UP"] = 0] = "UP";
        /** 下降 */

        WaveState[WaveState["DOWN"] = 1] = "DOWN";
        /** 底 */

        WaveState[WaveState["FLOOR"] = 2] = "FLOOR";
      })(WaveState = exports.WaveState || (exports.WaveState = {}));
      /**
       * PC/波/水面を表示、管理するクラス
       */


      var WaveManager =
      /** @class */
      function (_super) {
        __extends(WaveManager, _super);
        /**
         * コンストラクタ
         * @param  {g.Scene} _scene Sceneインスタンス
         */


        function WaveManager(_scene) {
          return _super.call(this, {
            scene: _scene
          }) || this;
        }
        /**
         * このクラスで使用するオブジェクトを生成するメソッド
         */


        WaveManager.prototype.init = function () {
          this.touchable = false;
          this.pcState = PcState.NORMAL;
          this.isStartedPcReturn_ = false;
          this.runupFrames = 0;
          this.waveState = WaveState.FLOOR;
          this.upCount = 0;
          var actorPC = this.actorPC = new asaEx_1.asaEx.Actor(this.scene, asaInfo_1.AsaInfo.surfing.pj, asaInfo_1.AsaInfo.surfing.anim.pcNormal);

          if (define_1.define.DEBUG_SHOW_COLLISION_RECT) {
            var rectCollision = new g.FilledRect({
              scene: this.scene,
              cssColor: define_1.define.DEBUG_COLLISION_RECT_COLOR,
              width: define_1.define.COLLISION_PC.width,
              height: define_1.define.COLLISION_PC.height
            });
            rectCollision.x = define_1.define.COLLISION_PC.x;
            rectCollision.y = define_1.define.COLLISION_PC.y;
            rectCollision.opacity = define_1.define.DEBUG_COLLISION_RECT_OPACITY;
            entityUtil_1.entityUtil.appendEntity(rectCollision, actorPC);
          }

          var attachmentPC = this.attachmentPC = new asaEx_1.asaEx.ActorAttachment(actorPC);
          attachmentPC.cancelParentSR = true;
          var actorWave = this.actorWave = new asaEx_1.asaEx.Actor(this.scene, asaInfo_1.AsaInfo.surfing.pj, asaInfo_1.AsaInfo.surfing.anim.waveLowerMost);
          actorWave.x = define_1.define.SURFING_X;
          actorWave.y = define_1.define.SURFING_Y;
          actorWave.attach(attachmentPC, define_1.define.PC_PIVOT_NAME);
          entityUtil_1.entityUtil.appendEntity(actorWave, this);
          var actorPlane = this.actorPlane = new asaEx_1.asaEx.Actor(this.scene, asaInfo_1.AsaInfo.surfing.pj, asaInfo_1.AsaInfo.surfing.anim.waveFlat);
          actorPlane.x = define_1.define.SURFING_X;
          actorPlane.y = define_1.define.SURFING_Y;
          entityUtil_1.entityUtil.appendEntity(actorPlane, this);
        };
        /**
         * 初期表示を行うメソッド
         */


        WaveManager.prototype.showContent = function () {
          this.touchable = false;
          this.pcState = PcState.NORMAL;
          this.actorPC.angle = -5;
          this.isStartedPcReturn_ = false;
          this.runupFrames = 0;
          this.waveState = WaveState.FLOOR;
          this.upCount = 0;
          this.actorPC.play(asaInfo_1.AsaInfo.surfing.anim.pcNormal, 0, true, 1);
          this.actorWave.play(asaInfo_1.AsaInfo.surfing.anim.waveLowerMost, 0, true, 1);
          this.actorPlane.play(asaInfo_1.AsaInfo.surfing.anim.waveFlat, 0, true, 1);
        };
        /**
         * ゲーム開始時の処理を行うメソッド
         */


        WaveManager.prototype.startGame = function () {
          this.touchable = true;
        };
        /**
         * タッチ可能状態かどうかを返すメソッド
         * @return {boolean} タッチ可能ならばtrue
         */


        WaveManager.prototype.isTouchable = function () {
          return this.touchable;
        };
        /**
         * PC状態がダメージから復帰に変わったフレームのみtrueを返すメソッド
         * onUpdateの後から次のonUpdate呼び出しまでが一つの判定区間
         * @return {boolean} 復帰に変わったフレームならばtrue
         */


        WaveManager.prototype.isStartedPcReturn = function () {
          return this.isStartedPcReturn_;
        };
        /**
         * 復帰後の無敵時間かどうかを返す返すメソッド
         * @return {boolean} 復帰後の無敵時間中ならばtrue
         */


        WaveManager.prototype.isRunup = function () {
          return this.runupFrames > 0;
        };
        /**
         * PCの座標を取得するメソッド
         * @return {g.CommonOffset} thisの親を基準としたPCの座標
         */


        WaveManager.prototype.getPcPosition = function () {
          var actorWave = this.actorWave;
          var pos = actorWave.getBonePosition(define_1.define.PC_PIVOT_NAME);
          pos.x += actorWave.x + gameUtil_1.gameUtil.getMatrixDx(this.attachmentPC.matrix) + this.x;
          pos.y += actorWave.y;
          return pos;
        };
        /**
         * 波の高さに対応したスクロール加速割合を取得するメソッド
         * @return {number} スクロール加速割合（0～1）
         */


        WaveManager.prototype.getScrollFactor = function () {
          var framePosition = this.getUpFramePosition();
          var asaResource = asaEx_1.asaEx.ResourceManager.getResource(this.scene, asaInfo_1.AsaInfo.surfing.pj);
          var downFrames = asaResource.getAnimationByName(asaInfo_1.AsaInfo.surfing.anim.waveSL).frameCount;
          var middle = (downFrames - 1) * 0.5;
          var diff = Math.abs(framePosition - middle);
          var factor = (middle - diff) / middle;
          return factor < 0 ? 0 : factor > 1 ? 1 : factor;
        };
        /**
         * フレームごとの処理を行うメソッド
         */


        WaveManager.prototype.onUpdate = function () {
          if (this.pcState === PcState.NORMAL) {
            this.updateInNormal();
          } else {
            this.updateInMiss();
          }
        };
        /**
         * タッチした結果を処理するメソッド
         */


        WaveManager.prototype.onTouch = function () {
          if (this.pcState === PcState.DAMAGE) {
            this.changeWaveState(WaveState.UP);
          }

          this.upCount = 17;
        };
        /**
         * ミス時の処理を行うメソッド
         */


        WaveManager.prototype.onMiss = function () {
          if (this.waveState !== WaveState.UP) {
            this.changeWaveState(WaveState.UP);
          } // ウイリー角度当たり


          if (this.actorPC.angle > -70) {
            this.actorPC.angle -= 6;
          } else {
            ;
          }

          this.upCount = 8;
        };
        /**
         * 通常時のフレームごとの処理を行うメソッド
         */


        WaveManager.prototype.updateInNormal = function () {
          if (this.runupFrames > 0) {
            --this.runupFrames;

            if (this.runupFrames <= 0) {
              this.actorPC.play(asaInfo_1.AsaInfo.surfing.anim.pcNormal, 0, true, 1);
            }
          } //ウイリー角度フロア戻り


          if (this.waveState === WaveState.FLOOR) {
            if (this.actorPC.angle < -3) {
              this.actorPC.angle += 1;
            } else {
              this.actorPC.angle = -1.5;
            }
          }

          if (this.waveState === WaveState.UP) {
            --this.upCount; // ウイリー角度上昇中

            if (this.actorPC.angle < -30) {
              this.actorPC.angle += 1;
            } else {
              this.actorPC.angle -= 4;
            }

            if (this.upCount === 0 || this.actorWave.currentFrame === this.actorWave.animation.frameCount - 1) {
              this.upCount = 0;
              this.changeWaveState(WaveState.DOWN);
            }
          } else if (this.waveState === WaveState.DOWN) {
            // ウイリー角度下降中
            if (this.actorPC.angle < -20) {
              this.actorPC.angle += 0.5;
            } else {
              this.actorPC.angle = -20;
            }

            if (this.actorWave.currentFrame === this.actorWave.animation.frameCount - 1) {
              this.changeWaveState(WaveState.FLOOR);
            }
          }

          this.actorPC.modified();
          this.actorPC.calc();
          this.actorWave.modified();
          this.actorWave.calc();
          this.actorPlane.modified();
          this.actorPlane.calc();
          gameUtil_1.gameUtil.setMatrixDx(this.attachmentPC.matrix, define_1.define.PC_OVERHANG_MAX * this.getScrollFactor());
        };
        /**
         * ミス演出中のフレームごとの処理を行うメソッド
         */


        WaveManager.prototype.updateInMiss = function () {
          this.isStartedPcReturn_ = false;

          if (this.actorPC.currentFrame === this.actorPC.animation.frameCount - 1) {
            if (this.pcState === PcState.DAMAGE) {
              // 復帰に移行する
              this.actorPC.angle = -5;

              if (this.waveState !== WaveState.FLOOR) {
                this.actorWave.play(asaInfo_1.AsaInfo.surfing.anim.waveLowerMost, 0, true, 1);
                this.waveState = WaveState.FLOOR;
                gameUtil_1.gameUtil.setMatrixDx(this.attachmentPC.matrix, 0);
              }

              this.actorPC.play(asaInfo_1.AsaInfo.surfing.anim.pcReturn, 0, false, 1);
              this.pcState = PcState.RETURN;
              this.isStartedPcReturn_ = true;
            } else {
              // 通常（復帰後の無敵状態）に移行する
              this.actorPC.play(asaInfo_1.AsaInfo.surfing.anim.pcRunup, 0, true, 1);
              this.pcState = PcState.NORMAL;
              this.runupFrames = define_1.define.RUNUP_FRAMES;
              this.upCount = 0;
              this.touchable = true;
            }
          } else {
            this.actorPC.modified();
            this.actorPC.calc();
          } // actorPCのアタッチ先のmodifiedを呼ばないと再描画されない


          this.actorWave.modified();
        };
        /**
         * 波の状態を切り替える
         * @param {WaveState} _newState 切り替え後の状態
         */


        WaveManager.prototype.changeWaveState = function (_newState) {
          // 現在の状態とアニメ位置から上昇アニメでの位置を求める
          var framePosition = this.getUpFramePosition(); // 上昇アニメでの位置に応じて切り替え後のアニメ位置を設定する

          var asaResource = asaEx_1.asaEx.ResourceManager.getResource(this.scene, asaInfo_1.AsaInfo.surfing.pj);
          var downFrames = asaResource.getAnimationByName(asaInfo_1.AsaInfo.surfing.anim.waveLS).frameCount;

          switch (_newState) {
            case WaveState.UP:
              this.actorWave.play(asaInfo_1.AsaInfo.surfing.anim.waveSL, framePosition, false, define_1.define.PLAYSPEED_UP, true);
              break;

            case WaveState.DOWN:
              this.actorWave.play(asaInfo_1.AsaInfo.surfing.anim.waveLS, downFrames - 1 - framePosition, false, define_1.define.PLAYSPEED_DOWN, true);
              break;

            case WaveState.FLOOR:
              this.actorWave.play(asaInfo_1.AsaInfo.surfing.anim.waveLowerMost, 0, true, 1, true);
              break;
          }

          this.waveState = _newState;
        };
        /**
         * 上昇アニメでの位置を求めるメソッド
         * @return {number} 上昇アニメでの位置
         */


        WaveManager.prototype.getUpFramePosition = function () {
          var framePosition = 0;

          switch (this.waveState) {
            case WaveState.UP:
              framePosition = this.actorWave.currentFrame;
              break;

            case WaveState.DOWN:
              framePosition = this.actorWave.animation.frameCount - 1 - this.actorWave.currentFrame;
              break;

            case WaveState.FLOOR:
              framePosition = 0;
              break;
          }

          return framePosition;
        };

        return WaveManager;
      }(g.E);

      exports.WaveManager = WaveManager;
    }, {
      "../util/asaEx": 59,
      "../util/entityUtil": 61,
      "../util/gameUtil": 62,
      "./asaInfo": 31,
      "./define": 33
    }],
    42: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 起動方法
       * @export
       * @enum {number}
       */

      var LaunchType;

      (function (LaunchType) {
        /** 未指定 */
        LaunchType[LaunchType["NOTHING"] = 0] = "NOTHING";
        /** 放送者プレイ */

        LaunchType[LaunchType["SELF"] = 1] = "SELF";
        /** 抽選されたユーザーがプレイ */

        LaunchType[LaunchType["LOTTERY"] = 2] = "LOTTERY";
        /** みんなでプレイ */

        LaunchType[LaunchType["RANKING"] = 3] = "RANKING";
      })(LaunchType = exports.LaunchType || (exports.LaunchType = {}));
      /** 特定のシーンを判定する文字列 */


      var INITIAL_SCENE_STRING = "game";
      /** 起動方法の放送者プレイを判定する文字列 */

      var LAUNCH_TYPE_SELF_STRING = "self";
      /** 起動方法の抽選されたユーザーがプレイを判定する文字列 */

      var LAUNCH_TYPE_LOTTERY_STRING = "lottery";
      /** 起動方法のみんなでプレイを判定する文字列 */

      var LAUNCH_TYPE_RANKING_STRING = "ranking";
      /** ゲームシーン以外のシーンで消費する時間 */

      var TIME_EXPECT_GAME_SCENE = 32;
      /**
       * 共通パラメータの読み込みクラス
       * 省略されたパラメータ項目の補完などを行う
       */

      var CommonParameterReader =
      /** @class */
      function () {
        function CommonParameterReader() {}
        /**
         * 起動パラメータから対応するメンバ変数を設定する
         * @param {RireGameParameters} parameters 起動パラメータ
         */


        CommonParameterReader.read = function (parameters) {
          this.initialScene = "";
          this.isInitialSceneGame = false;
          this.muteAudio = false;
          this.nicowari = false;
          this.useGameTimeLimit = false;
          this.gameTimeLimit = 0;
          this.useDifficulty = false;
          this.difficulty = 1;
          this.launchType = LaunchType.NOTHING;

          if (typeof parameters.nicowari === "boolean") {
            this.nicowari = parameters.nicowari;
          } // console.log("read: nicowari:" + this.nicowari + ".");


          if (this.nicowari) {
            return;
          }

          if (typeof parameters.initialScene === "string") {
            this.initialScene = parameters.initialScene;
          }

          if (this.initialScene === INITIAL_SCENE_STRING) {
            this.isInitialSceneGame = true;
          } // console.log("read: initialScene:" + this.initialScene + ", isInitialSceneGame:" + this.isInitialSceneGame + ".");


          if (typeof parameters.muteAudio === "boolean") {
            this.muteAudio = parameters.muteAudio;
          } // console.log("read: muteAudio:" + this.muteAudio + ".");


          if (typeof parameters.totalTimeLimit === "number") {
            this.useGameTimeLimit = true;
            this.gameTimeLimit = Math.max(0, parameters.totalTimeLimit - TIME_EXPECT_GAME_SCENE);
          } // console.log("read: useGameTimeLimit:" + this.useGameTimeLimit + ", gameTimeLimit:" + this.gameTimeLimit + ".");
          // console.log("read: useGameTimeMax:" + this.useGameTimeMax + ".");


          if (typeof parameters.difficulty === "number") {
            this.useDifficulty = true;

            if (parameters.difficulty < 1) {
              this.difficulty = 1;
            } else if (parameters.difficulty > 10) {
              this.difficulty = 10;
            } else {
              this.difficulty = parameters.difficulty;
            }
          } // console.log("read: useDifficulty:" + this.useDifficulty + ", difficulty:" + this.difficulty + ".");


          if (typeof parameters.randomSeed === "number") {
            this.randomGenerator = new g.XorshiftRandomGenerator(parameters.randomSeed);
          }

          if (typeof parameters.launchType === "string") {
            if (parameters.launchType === LAUNCH_TYPE_SELF_STRING) {
              this.launchType = LaunchType.SELF;
            } else if (parameters.launchType === LAUNCH_TYPE_LOTTERY_STRING) {
              this.launchType = LaunchType.LOTTERY;
            } else if (parameters.launchType === LAUNCH_TYPE_RANKING_STRING) {
              this.launchType = LaunchType.RANKING;
            }
          }
        };

        return CommonParameterReader;
      }();

      exports.CommonParameterReader = CommonParameterReader;
    }, {}],
    43: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var entityUtil_1 = require("../util/entityUtil");
      /**
       * ゲームの実体を実装するベースクラス
       */


      var GameBase =
      /** @class */
      function (_super) {
        __extends(GameBase, _super);

        function GameBase(_scene) {
          return _super.call(this, {
            scene: _scene
          }) || this;
        }
        /**
         * このクラスで使用するオブジェクトを生成するメソッド
         * Scene#loadedを起点とする処理からコンストラクタの直後に呼ばれる。
         * このクラスはゲーム画面終了時も破棄されず、次のゲームで再利用される。
         * そのためゲーム状態の初期化はinitではなくshowContentで行う必要がある。
         */


        GameBase.prototype.init = function () {
          this.timeCaution = new g.Trigger();
          this.timeCautionCancel = new g.Trigger();
          this.timeup = new g.Trigger();
          this.timeout = new g.Trigger();
          this.gameClear = new g.Trigger();
          this.gameOver = new g.Trigger();
          entityUtil_1.entityUtil.hideEntity(this);
        };
        /**
         * 表示系以外のオブジェクトをdestroyするメソッド
         * 表示系のオブジェクトはg.Eのdestroyに任せる。
         * @override
         */


        GameBase.prototype.destroy = function () {
          if (this.destroyed()) {
            return;
          }

          if (this.timeCaution) {
            this.timeCaution.destroy();
            this.timeCaution = null;
          }

          if (this.timeCautionCancel) {
            this.timeCautionCancel.destroy();
            this.timeCautionCancel = null;
          }

          if (this.timeup) {
            this.timeup.destroy();
            this.timeup = null;
          }

          if (this.timeout) {
            this.timeout.destroy();
            this.timeout = null;
          }

          if (this.gameClear) {
            this.gameClear.destroy();
            this.gameClear = null;
          }

          if (this.gameOver) {
            this.gameOver.destroy();
            this.gameOver = null;
          }

          _super.prototype.destroy.call(this);
        };
        /**
         * タイトル画面のBGMのアセット名を返すメソッド
         * 共通フロー側でBGMを鳴らさない場合は実装クラスでオーバーライドして
         * 空文字列を返すようにする
         * @return {string} アセット名
         */


        GameBase.prototype.getTitleBgmName = function () {
          return "";
        };
        /**
         * ゲーム中のBGMのアセット名を返すメソッド
         * 共通フロー側でBGMを鳴らさない場合は実装クラスでオーバーライドして
         * 空文字列を返すようにする
         * @return {string} アセット名
         */


        GameBase.prototype.getMainBgmName = function () {
          return "";
        };
        /**
         * 表示を開始するメソッド
         * ゲーム画面に遷移するワイプ演出で表示が始まる時点で呼ばれる。
         */


        GameBase.prototype.showContent = function () {
          entityUtil_1.entityUtil.showEntity(this);
        };
        /**
         * ゲーム前ガイド表示を開始するメソッド
         * ゲーム画面に遷移したあとReady～Startジングルの前に呼ばれ、
         * ゲーム前ガイド表示を開始する。
         * ゲーム前ガイド表示を行わない場合はfalseを返す。
         * trueを返すとonUpdatePreGameGuideが呼ばれるようになる。
         * @return {boolean} ゲーム前ガイド表示を行わない場合はfalse
         */


        GameBase.prototype.startPreGameGuide = function () {
          return false;
        };
        /**
         * ゲーム開始前のReadyGoジングル表示を行うかどうかを返すメソッド
         * ReadyGoジングル表示を行わない場合は実装クラスでこのメソッドを
         * オーバーライドしてfalseを返す
         * @return {boolean} ReadyGoジングル表示を行う場合はtrue
         */


        GameBase.prototype.needsReadyGoJingle = function () {
          return true;
        };
        /**
         * 表示を終了するメソッド
         * このサブシーンから遷移するワイプ演出で表示が終わる時点で呼ばれる。
         */


        GameBase.prototype.hideContent = function () {
          entityUtil_1.entityUtil.hideEntity(this);
        };
        /**
         * Scene#updateを起点とする処理から呼ばれるメソッド
         * startPreGameGuideでtrueを返した場合に呼ばれ始め、
         * この関数でtrueを返すと呼び出しが止まるとともに
         * Ready～Startジングルが開始される。
         * @return {boolean} ゲーム前ガイド表示を終了する場合はtrue
         */


        GameBase.prototype.onUpdatePreGameGuide = function () {
          return true;
        };

        return GameBase;
      }(g.E);

      exports.GameBase = GameBase;
    }, {
      "../util/entityUtil": 61
    }],
    44: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * Sceneの生成と各種ハンドラ設定を行う抽象クラス
       * このクラスのインスタンスはcreateSceneで生成したSceneのTriggerなどから
       * 参照されることによって保持される。
       */

      var SceneController =
      /** @class */
      function () {
        function SceneController() {// NOP
        }

        return SceneController;
      }();

      exports.SceneController = SceneController;
    }, {}],
    45: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 具体的なシーンの処理と表示を行う抽象クラス
       */

      var Subscene =
      /** @class */
      function (_super) {
        __extends(Subscene, _super);

        function Subscene(_scene) {
          return _super.call(this, {
            scene: _scene
          }) || this;
        }

        return Subscene;
      }(g.E);

      exports.Subscene = Subscene;
    }, {}],
    46: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var commonDefine_1 = require("./commonDefine");

      var entityUtil_1 = require("../util/entityUtil");

      var gameUtil_1 = require("../util/gameUtil");
      /**
       * 残り時間警告の赤点滅演出を管理するクラス
       */


      var CautionFilledRect =
      /** @class */
      function (_super) {
        __extends(CautionFilledRect, _super);

        function CautionFilledRect(_scene) {
          var _this = _super.call(this, {
            scene: _scene,
            cssColor: commonDefine_1.commonDefine.CAUTION_FILLRECT_COLOR,
            width: _scene.game.width,
            height: _scene.game.height
          }) || this;

          _this.hide();

          return _this;
        }
        /**
         * 点滅状態を取得する
         * @return {boolean} 点滅中ならばtrue
         */


        CautionFilledRect.prototype.isBlinking = function () {
          return this.isBlinking_;
        };
        /**
         * 赤点滅演出を開始する
         */


        CautionFilledRect.prototype.startBlink = function () {
          this.isBlinking_ = true;
          this.setTween();
          entityUtil_1.entityUtil.showEntity(this);
        };
        /**
         * 赤点滅演出を終了する
         */


        CautionFilledRect.prototype.stopBlink = function () {
          this.isBlinking_ = false;
          entityUtil_1.entityUtil.hideEntity(this); // stopBlinkのあと実行中のtweenが終了する前にstartBlinkされると
          // 正常に動かないが仕様上起きない前提とする。
        };
        /**
         * 赤点滅一周期分のtweenを設定する
         */


        CautionFilledRect.prototype.setTween = function () {
          var _this = this;

          this.opacity = commonDefine_1.commonDefine.CAUTION_FILLRECT_OPACITY_OFF;
          var timeline = this.scene.game.vars.scenedata.timeline;
          var fps = this.scene.game.fps;
          gameUtil_1.gameUtil.createTween(timeline, this).to({
            opacity: commonDefine_1.commonDefine.CAUTION_FILLRECT_OPACITY_ON
          }, commonDefine_1.commonDefine.CAUTION_TIME_ON * 1000 / fps).to({
            opacity: commonDefine_1.commonDefine.CAUTION_FILLRECT_OPACITY_OFF
          }, commonDefine_1.commonDefine.CAUTION_TIME_OFF * 1000 / fps).call(function () {
            if (_this.isBlinking_) {
              _this.setTween();
            }
          });
        };

        return CautionFilledRect;
      }(g.FilledRect);

      exports.CautionFilledRect = CautionFilledRect;
    }, {
      "../util/entityUtil": 61,
      "../util/gameUtil": 62,
      "./commonDefine": 49
    }],
    47: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 共通演出用画像アセット関連の静的情報
       */

      var CommonAsaInfo =
      /** @class */
      function () {
        function CommonAsaInfo() {} // tslint:disable-next-line:typedef


        CommonAsaInfo.nwTitle = {
          pj: "pj_nw_title",
          anim: {
            title: "title_title",
            description: "description_description"
          }
        }; // tslint:disable-next-line:typedef

        CommonAsaInfo.nwCommon = {
          pj: "pj_nw_common",
          anim: {
            fadeRtoL: "fade_RtoL",
            fadeLtoR: "fade_LtoR",
            readyGo: "readygo_readygo",
            gameClear: "gameclear_gameclear",
            timeup: "timeup_timeup",
            result: "result_result",
            timeout: "timeout_timeout",
            gameOver: "gameover_gameover"
          }
        }; // tslint:disable-next-line:typedef

        CommonAsaInfo.nwInformation = {
          pj: "pj_before_the_start",
          anim: {
            self: "before_the_start_still_1",
            lottery: "before_the_start_still_2",
            ranking: "before_the_start_still_3"
          }
        };
        return CommonAsaInfo;
      }();

      exports.CommonAsaInfo = CommonAsaInfo;
    }, {}],
    48: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 共通演出用画像アセット関連の静的情報
       */

      var CommonAssetInfo =
      /** @class */
      function () {
        function CommonAssetInfo() {} // tslint:disable-next-line:typedef


        CommonAssetInfo.numResult = {
          img: "img_num_result",
          json: "json_num_result",
          frames: {
            cross: "num_result_0011.png",
            plus: "num_result_0012.png",
            minus: "num_result_0013.png"
          },
          numFrames: ["num_result_0001.png", "num_result_0002.png", "num_result_0003.png", "num_result_0004.png", "num_result_0005.png", "num_result_0006.png", "num_result_0007.png", "num_result_0008.png", "num_result_0009.png", "num_result_0010.png"],
          fontWidth: 70,
          fontHeight: 81
        };
        /** リザルトでのtips画像01 */

        CommonAssetInfo.tipsImg01 = {
          img: "result_chara_img_01"
        };
        /** リザルトでのtips画像02 */

        CommonAssetInfo.tipsImg02 = {
          img: "result_chara_img_02"
        };
        /** リザルトでのtips画像03 */

        CommonAssetInfo.tipsImg03 = {
          img: "result_chara_img_03"
        };
        return CommonAssetInfo;
      }();

      exports.CommonAssetInfo = CommonAssetInfo;
    }, {}],
    49: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 共通演出関連の静的情報
       */

      var commonDefine;

      (function (commonDefine) {
        /** 背景透過部分の黒アルファの不透明度 */
        commonDefine.BG_SHADE_OPACITY = 1.0;
        /** デバッグ用：タイトル画面/説明画面をスキップするフラグ */

        commonDefine.DEBUG_SKIP_PREGAMESUBSCENE = false;
        /**
         * タイトル画面と説明画面でタッチ受付を開始するまでの時間[ms]
         * 0の場合はタッチ受付を開始しない
         */

        commonDefine.TOUCH_SKIP_WAIT = 0;
        /** ゲーム開始情報画面開始からタイトル画面に遷移するまでの時間[ms] */

        commonDefine.INFORMATION_WAIT = 7000;
        /** タイトル画面開始から説明画面に遷移するまでの時間[ms] */

        commonDefine.TITLE_WAIT = 5000;
        /** 説明画面開始からゲーム画面に遷移するまでの時間[ms] */

        commonDefine.DESCRIPTION_WAIT = 10000;
        /** タイムアップ後リザルト画面に遷移するまでの時間[ms] */

        commonDefine.TIMEUP_WAIT = 3000;
        /** 結果画面でリトライ操作を受け付けるフラグ */

        commonDefine.ENABLE_RETRY = false;
        /** 残り時間警告の点滅時間：OFF→ON */

        commonDefine.CAUTION_TIME_ON = 5;
        /** 残り時間警告の点滅時間：ON→OFF */

        commonDefine.CAUTION_TIME_OFF = 40;
        /** 残り時間警告の赤点滅の色 */

        commonDefine.CAUTION_FILLRECT_COLOR = "red";
        /** 残り時間警告の赤点滅の不透明度：OFF */

        commonDefine.CAUTION_FILLRECT_OPACITY_OFF = 0.1;
        /** 残り時間警告の赤点滅の不透明度：ON */

        commonDefine.CAUTION_FILLRECT_OPACITY_ON = 0.3;
        /** 残り時間警告の時間表示のスケール：OFF */

        commonDefine.CAUTION_TIME_SCALE_OFF = 1.0;
        /** 残り時間警告の時間表示のスケール：ON */

        commonDefine.CAUTION_TIME_SCALE_ON = 1.2;
        /** リザルトの点数の桁数 */

        commonDefine.RESULT_SCORE_DIGIT = 5;
        /** リザルト画面でスコアをロール表示する時間[ms] */

        commonDefine.RESULT_ROLL_WAIT = 1500;
        /** tipsを表示するフラグ */

        commonDefine.SHOW_TIPS = false;
        /** tipsを表示しない場合のリザルトオブジェクトのY座標補正値 */

        commonDefine.RESULT_OBJECTS_OFFSET_Y = 76;
        /** tipsアセット変数名の先頭部分 */

        commonDefine.TIPS_VAR_NAME_HEAD = "tipsImg";
        /** tips画像サイズ */

        commonDefine.TIPS_IMG_SIZE = {
          width: 410,
          height: 120
        };
        /** tips画像左上座標 */

        commonDefine.TIPS_IMG_POS = {
          x: 115,
          y: 220
        };
      })(commonDefine = exports.commonDefine || (exports.commonDefine = {}));
    }, {}],
    50: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 共通音声アセット関連の静的情報
       */

      var CommonSoundInfo =
      /** @class */
      function () {
        function CommonSoundInfo() {} // tslint:disable-next-line:typedef


        CommonSoundInfo.seSet = {
          ready: "se_ready_start",
          timeup: "se_timeup",
          rollResult: "se_No8_RollCount2",
          rollResultFinish: "se_No8_RollCount_Finish"
        };
        return CommonSoundInfo;
      }();

      exports.CommonSoundInfo = CommonSoundInfo;
    }, {}],
    51: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var subscene_1 = require("../commonNicowariGame/subscene");

      var commonAsaInfo_1 = require("./commonAsaInfo");

      var asaEx_1 = require("../util/asaEx");

      var spriteUtil_1 = require("../util/spriteUtil");

      var entityUtil_1 = require("../util/entityUtil");

      var commonDefine_1 = require("./commonDefine");
      /**
       * 説明文言サブシーンの処理と表示を行うクラス
       */


      var DescriptionSubscene =
      /** @class */
      function (_super) {
        __extends(DescriptionSubscene, _super);

        function DescriptionSubscene(_scene) {
          return _super.call(this, _scene) || this;
        }
        /**
         * このクラスで使用するオブジェクトを生成する
         * @override
         */


        DescriptionSubscene.prototype.init = function () {
          this.autoNext = commonDefine_1.commonDefine.DESCRIPTION_WAIT > 0;
          this.inContent = false;
          this.requestedNextSubscene = new g.Trigger();
          var game = this.scene.game;
          var desc = this.asaDescription = new asaEx_1.asaEx.Actor(this.scene, commonAsaInfo_1.CommonAsaInfo.nwTitle.pj);
          desc.x = game.width / 2;
          desc.y = game.height / 2;
          desc.update.handle(spriteUtil_1.spriteUtil.makeActorUpdater(desc));
          desc.hide();
          entityUtil_1.entityUtil.appendEntity(desc, this);
          entityUtil_1.entityUtil.hideEntity(this);
        };
        /**
         * 表示系以外のオブジェクトをdestroyする
         * 表示系のオブジェクトはg.Eのdestroyに任せる
         * @override
         */


        DescriptionSubscene.prototype.destroy = function () {
          if (this.destroyed()) {
            return;
          }

          if (this.requestedNextSubscene) {
            this.requestedNextSubscene.destroy();
            this.requestedNextSubscene = null;
          }

          _super.prototype.destroy.call(this);
        };
        /**
         * 表示を開始する
         * このサブシーンに遷移するワイプ演出で表示が始まる時点で呼ばれる
         * @override
         */


        DescriptionSubscene.prototype.showContent = function () {
          this.asaDescription.play(commonAsaInfo_1.CommonAsaInfo.nwTitle.anim.description, 0, false, 1);
          entityUtil_1.entityUtil.showEntity(this.asaDescription);
          entityUtil_1.entityUtil.showEntity(this);
        };
        /**
         * 動作を開始する
         * このサブシーンに遷移するワイプ演出が完了した時点で呼ばれる
         * @override
         */


        DescriptionSubscene.prototype.startContent = function () {
          this.inContent = true;

          if (this.autoNext) {
            this.scene.setTimeout(commonDefine_1.commonDefine.DESCRIPTION_WAIT, this, this.onTimeout);

            if (commonDefine_1.commonDefine.TOUCH_SKIP_WAIT > 0) {
              this.scene.setTimeout(commonDefine_1.commonDefine.TOUCH_SKIP_WAIT, this, this.onTimeoutToTouch);
            }
          } else {
            this.scene.pointDownCapture.handle(this, this.onTouch);
          }
        };
        /**
         * Scene#updateを起点とする処理から呼ばれる
         * @override
         */


        DescriptionSubscene.prototype.onUpdate = function () {// NOP
        };
        /**
         * 動作を停止する
         * このサブシーンから遷移するワイプ演出が始まる時点で呼ばれる
         * @override
         */


        DescriptionSubscene.prototype.stopContent = function () {
          // console.log("DescriptionSubscene.stopContent: inContent:"+this.inContent+".");
          this.inContent = false;
          this.scene.pointDownCapture.removeAll(this);
        };
        /**
         * 表示を終了する
         * このサブシーンから遷移するワイプ演出で表示が終わる時点で呼ばれる
         * @override
         */


        DescriptionSubscene.prototype.hideContent = function () {
          entityUtil_1.entityUtil.hideEntity(this);
          entityUtil_1.entityUtil.hideEntity(this.asaDescription);
        };
        /**
         * Scene#setTimeoutのハンドラ
         * 次のシーンへの遷移を要求する
         */


        DescriptionSubscene.prototype.onTimeout = function () {
          // console.log("DescriptionSubscene.onTimeout: inContent:"+this.inContent+".");
          if (this.inContent) {
            this.requestedNextSubscene.fire();
          }
        };
        /**
         * Scene#setTimeoutのハンドラ
         * タッチ受付を開始する
         */


        DescriptionSubscene.prototype.onTimeoutToTouch = function () {
          // console.log("DescriptionSubscene.onTimeoutToTouch: inContent:"+this.inContent+".");
          if (this.inContent) {
            this.scene.pointDownCapture.handle(this, this.onTouch);
          }
        };
        /**
         * Scene#pointDownCaptureのハンドラ
         * 次のシーンへの遷移を要求する
         * @param {g.PointDownEvent} _e イベントパラメータ
         * @return {boolean} trueを返し、ハンドラ登録を解除する
         */


        DescriptionSubscene.prototype.onTouch = function (_e) {
          // console.log("DescriptionSubscene.onTouch: inContent:"+this.inContent+".");
          if (this.inContent) {
            this.requestedNextSubscene.fire();
          }

          return true;
        };

        return DescriptionSubscene;
      }(subscene_1.Subscene);

      exports.DescriptionSubscene = DescriptionSubscene;
    }, {
      "../commonNicowariGame/subscene": 45,
      "../util/asaEx": 59,
      "../util/entityUtil": 61,
      "../util/spriteUtil": 63,
      "./commonAsaInfo": 47,
      "./commonDefine": 49
    }],
    52: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var subscene_1 = require("../commonNicowariGame/subscene");

      var commonAsaInfo_1 = require("./commonAsaInfo");

      var commonSoundInfo_1 = require("./commonSoundInfo");

      var commonDefine_1 = require("./commonDefine");

      var asaEx_1 = require("../util/asaEx");

      var spriteUtil_1 = require("../util/spriteUtil");

      var entityUtil_1 = require("../util/entityUtil");

      var audioUtil_1 = require("../util/audioUtil");

      var cautionFilledRect_1 = require("./cautionFilledRect");

      var gameCreator_1 = require("../classes/gameCreator");
      /**
       * ゲームサブシーンの処理と表示を行うクラス
       */


      var GameSubscene =
      /** @class */
      function (_super) {
        __extends(GameSubscene, _super);

        function GameSubscene(_scene) {
          return _super.call(this, _scene) || this;
        }
        /**
         * このクラスで使用するオブジェクトを生成する
         * @override
         */


        GameSubscene.prototype.init = function () {
          this.requestedNextSubscene = new g.Trigger();
          var game = this.scene.game;
          var cautionFill = this.cautionFill = new cautionFilledRect_1.CautionFilledRect(this.scene);
          entityUtil_1.entityUtil.appendEntity(cautionFill, this);
          this.inPreGameGuide = false;
          var content = this.gameContent = gameCreator_1.GameCreator.createGame(this.scene);
          content.init();
          entityUtil_1.entityUtil.appendEntity(content, this);
          var jingle = this.asaJingle = new asaEx_1.asaEx.Actor(this.scene, commonAsaInfo_1.CommonAsaInfo.nwCommon.pj);
          jingle.x = game.width / 2;
          jingle.y = game.height / 2;
          jingle.update.handle(spriteUtil_1.spriteUtil.makeActorUpdater(jingle));
          jingle.hide();
          entityUtil_1.entityUtil.appendEntity(jingle, this);
          entityUtil_1.entityUtil.hideEntity(this);
        };
        /**
         * 表示系以外のオブジェクトをdestroyする
         * 表示系のオブジェクトはg.Eのdestroyに任せる
         * @override
         */


        GameSubscene.prototype.destroy = function () {
          if (this.destroyed()) {
            return;
          }

          if (this.requestedNextSubscene) {
            this.requestedNextSubscene.destroy();
            this.requestedNextSubscene = null;
          }

          _super.prototype.destroy.call(this);
        };
        /**
         * タイトル画面のBGMのアセット名を返すメソッド
         * @return {string} アセット名
         */


        GameSubscene.prototype.getTitleBgmName = function () {
          return this.gameContent.getTitleBgmName();
        };
        /**
         * 表示を開始する
         * このサブシーンに遷移するワイプ演出で表示が始まる時点で呼ばれる
         * @override
         */


        GameSubscene.prototype.showContent = function () {
          this.gameContent.showContent();
          entityUtil_1.entityUtil.showEntity(this.gameContent);
          entityUtil_1.entityUtil.showEntity(this);
        };
        /**
         * 動作を開始する
         * このサブシーンに遷移するワイプ演出が完了した時点で呼ばれる
         * @override
         */


        GameSubscene.prototype.startContent = function () {
          this.inPreGameGuide = this.gameContent.startPreGameGuide();

          if (!this.inPreGameGuide) {
            this.startReady();
          }
        };
        /**
         * Scene#updateを起点とする処理から呼ばれる
         * @override
         */


        GameSubscene.prototype.onUpdate = function () {
          if (this.inPreGameGuide) {
            if (this.gameContent.onUpdatePreGameGuide()) {
              this.inPreGameGuide = false;
              this.startReady();
            }
          }

          this.gameContent.onUpdate();
        };
        /**
         * 動作を停止する
         * このサブシーンから遷移するワイプ演出が始まる時点で呼ばれる
         * @override
         */


        GameSubscene.prototype.stopContent = function () {// NOP
        };
        /**
         * 表示を終了する
         * このサブシーンから遷移するワイプ演出で表示が終わる時点で呼ばれる
         * @override
         */


        GameSubscene.prototype.hideContent = function () {
          entityUtil_1.entityUtil.hideEntity(this);
          entityUtil_1.entityUtil.hideEntity(this.asaJingle);
          entityUtil_1.entityUtil.hideEntity(this.gameContent);
          this.gameContent.hideContent();
        };
        /**
         * ReadyGoジングルを開始する
         */


        GameSubscene.prototype.startReady = function () {
          if (this.gameContent.needsReadyGoJingle()) {
            this.asaJingle.play(commonAsaInfo_1.CommonAsaInfo.nwCommon.anim.readyGo, 0, false, 1);
            this.asaJingle.ended.handle(this, this.onReadyEnd);
            entityUtil_1.entityUtil.showEntity(this.asaJingle);
            audioUtil_1.audioUtil.play(commonSoundInfo_1.CommonSoundInfo.seSet.ready);
          } else {
            this.startGame();
          }
        };
        /**
         * Actor#endedのハンドラ
         * ReadyGoアニメの終了時用
         * @return {boolean} trueを返し、ハンドラ登録を解除する
         */


        GameSubscene.prototype.onReadyEnd = function () {
          entityUtil_1.entityUtil.hideEntity(this.asaJingle);
          this.startGame();
          return true;
        };
        /**
         * ゲームを開始する
         */


        GameSubscene.prototype.startGame = function () {
          audioUtil_1.audioUtil.play(this.gameContent.getMainBgmName());
          this.gameContent.timeCaution.handle(this, this.onTimeCaution);
          this.gameContent.timeCautionCancel.handle(this, this.onTimeCautionCancel);
          this.gameContent.timeup.handle(this, this.onTimeup);
          this.gameContent.timeout.handle(this, this.onTimeout);
          this.gameContent.gameClear.handle(this, this.onGameClear);
          this.gameContent.gameOver.handle(this, this.onGameOver);
          this.gameContent.startGame();
        };
        /**
         * GaemBase#timeCautionのハンドラ
         * 残り時間警告の赤点滅を開始する
         */


        GameSubscene.prototype.onTimeCaution = function () {
          this.cautionFill.startBlink();
        };
        /**
         * GaemBase#timeCautionCancelのハンドラ
         * 残り時間警告の赤点滅を中断する
         */


        GameSubscene.prototype.onTimeCautionCancel = function () {
          this.cautionFill.stopBlink();
        };
        /**
         * GaemBase#timeupのハンドラ
         * タイムアップ演出を開始する
         * @return {boolean} trueを返し、ハンドラ登録を解除する
         */


        GameSubscene.prototype.onTimeup = function () {
          this.finishGame(commonAsaInfo_1.CommonAsaInfo.nwCommon.anim.timeup);
          return true;
        };
        /**
         * GaemBase#timeoutのハンドラ
         * タイムアウト演出を開始する
         * @return {boolean} trueを返し、ハンドラ登録を解除する
         */


        GameSubscene.prototype.onTimeout = function () {
          this.finishGame(commonAsaInfo_1.CommonAsaInfo.nwCommon.anim.timeout);
          return true;
        };
        /**
         * GaemBase#gameClearのハンドラ
         * ゲームクリア演出を開始する
         * @return {boolean} trueを返し、ハンドラ登録を解除する
         */


        GameSubscene.prototype.onGameClear = function () {
          this.finishGame(commonAsaInfo_1.CommonAsaInfo.nwCommon.anim.gameClear);
          return true;
        };
        /**
         * GaemBase#gameOverのハンドラ
         * ゲームオーバー演出を開始する
         * @return {boolean} trueを返し、ハンドラ登録を解除する
         */


        GameSubscene.prototype.onGameOver = function () {
          this.finishGame(commonAsaInfo_1.CommonAsaInfo.nwCommon.anim.gameOver);
          return true;
        };
        /**
         * タイムアップ/タイムアウト/ゲームクリア/ゲームオーバー時の処理を行う
         * @param {string} _jingleAnimName ジングルアニメ名
         */


        GameSubscene.prototype.finishGame = function (_jingleAnimName) {
          audioUtil_1.audioUtil.stop(this.gameContent.getMainBgmName());
          this.cautionFill.stopBlink();
          this.gameContent.timeCaution.removeAll(this);
          this.gameContent.timeCautionCancel.removeAll(this);
          this.gameContent.timeup.removeAll(this);
          this.gameContent.timeout.removeAll(this);
          this.gameContent.gameClear.removeAll(this);
          this.gameContent.gameOver.removeAll(this);
          this.asaJingle.play(_jingleAnimName, 0, false, 1, true);
          entityUtil_1.entityUtil.showEntity(this.asaJingle);
          audioUtil_1.audioUtil.play(commonSoundInfo_1.CommonSoundInfo.seSet.timeup);
          this.scene.setTimeout(commonDefine_1.commonDefine.TIMEUP_WAIT, this, this.onTimeupEnd);
        };
        /**
         * Scene#setTimeoutのハンドラ
         * Timeup演出の終了時用
         * 次のシーンへの遷移を要求する
         */


        GameSubscene.prototype.onTimeupEnd = function () {
          this.requestedNextSubscene.fire();
        };

        return GameSubscene;
      }(subscene_1.Subscene);

      exports.GameSubscene = GameSubscene;
    }, {
      "../classes/gameCreator": 34,
      "../commonNicowariGame/subscene": 45,
      "../util/asaEx": 59,
      "../util/audioUtil": 60,
      "../util/entityUtil": 61,
      "../util/spriteUtil": 63,
      "./cautionFilledRect": 46,
      "./commonAsaInfo": 47,
      "./commonDefine": 49,
      "./commonSoundInfo": 50
    }],
    53: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var subscene_1 = require("../commonNicowariGame/subscene");

      var commonAsaInfo_1 = require("./commonAsaInfo");

      var asaEx_1 = require("../util/asaEx");

      var spriteUtil_1 = require("../util/spriteUtil");

      var entityUtil_1 = require("../util/entityUtil");

      var commonDefine_1 = require("./commonDefine");

      var commonParameterReader_1 = require("../commonNicowariGame/commonParameterReader");
      /**
       * 視聴者へのゲーム開始情報表示サブシーンの処理と表示を行うクラス
       */


      var InformationSubscene =
      /** @class */
      function (_super) {
        __extends(InformationSubscene, _super);

        function InformationSubscene(_scene) {
          return _super.call(this, _scene) || this;
        }
        /**
         * このクラスで使用するオブジェクトを生成する
         * @override
         */


        InformationSubscene.prototype.init = function () {
          this.autoNext = commonDefine_1.commonDefine.INFORMATION_WAIT > 0;
          this.inContent = false;
          this.requestedNextSubscene = new g.Trigger();
          var game = this.scene.game;
          var infoAnim = this.asaInformation = new asaEx_1.asaEx.Actor(this.scene, commonAsaInfo_1.CommonAsaInfo.nwInformation.pj);
          infoAnim.x = game.width / 2;
          infoAnim.y = game.height / 2;
          infoAnim.update.handle(spriteUtil_1.spriteUtil.makeActorUpdater(infoAnim));
          infoAnim.hide();
          entityUtil_1.entityUtil.appendEntity(infoAnim, this);
          entityUtil_1.entityUtil.hideEntity(this);
        };
        /**
         * 表示系以外のオブジェクトをdestroyする
         * 表示系のオブジェクトはg.Eのdestroyに任せる
         * @override
         */


        InformationSubscene.prototype.destroy = function () {
          if (this.destroyed()) {
            return;
          }

          if (this.requestedNextSubscene) {
            this.requestedNextSubscene.destroy();
            this.requestedNextSubscene = null;
          }

          _super.prototype.destroy.call(this);
        };
        /**
         * 表示を開始する
         * このサブシーンに遷移するワイプ演出で表示が始まる時点で呼ばれる
         * @override
         */


        InformationSubscene.prototype.showContent = function () {
          var anim = "";

          if (commonParameterReader_1.CommonParameterReader.launchType === commonParameterReader_1.LaunchType.SELF) {
            anim = commonAsaInfo_1.CommonAsaInfo.nwInformation.anim.self;
          } else if (commonParameterReader_1.CommonParameterReader.launchType === commonParameterReader_1.LaunchType.LOTTERY) {
            anim = commonAsaInfo_1.CommonAsaInfo.nwInformation.anim.lottery;
          } else if (commonParameterReader_1.CommonParameterReader.launchType === commonParameterReader_1.LaunchType.RANKING) {
            anim = commonAsaInfo_1.CommonAsaInfo.nwInformation.anim.ranking;
          } else {
            return;
          }

          this.asaInformation.play(anim, 0, false, 1);
          entityUtil_1.entityUtil.showEntity(this.asaInformation);
          entityUtil_1.entityUtil.showEntity(this);
        };
        /**
         * 動作を開始する
         * このサブシーンに遷移するワイプ演出が完了した時点で呼ばれる
         * @override
         */


        InformationSubscene.prototype.startContent = function () {
          this.inContent = true;

          if (this.autoNext) {
            this.scene.setTimeout(commonDefine_1.commonDefine.INFORMATION_WAIT, this, this.onTimeout);

            if (commonDefine_1.commonDefine.TOUCH_SKIP_WAIT > 0) {
              this.scene.setTimeout(commonDefine_1.commonDefine.TOUCH_SKIP_WAIT, this, this.onTimeoutToTouch);
            }
          } else {
            this.scene.pointDownCapture.handle(this, this.onTouch);
          }
        };
        /**
         * Scene#updateを起点とする処理から呼ばれる
         * @override
         */


        InformationSubscene.prototype.onUpdate = function () {// NOP
        };
        /**
         * 動作を停止する
         * このサブシーンから遷移するワイプ演出が始まる時点で呼ばれる
         * @override
         */


        InformationSubscene.prototype.stopContent = function () {
          this.inContent = false;
          this.scene.pointDownCapture.removeAll(this);
        };
        /**
         * 表示を終了する
         * このサブシーンから遷移するワイプ演出で表示が終わる時点で呼ばれる
         * @override
         */


        InformationSubscene.prototype.hideContent = function () {
          entityUtil_1.entityUtil.hideEntity(this);
          entityUtil_1.entityUtil.hideEntity(this.asaInformation);
        };
        /**
         * Scene#setTimeoutのハンドラ
         * 次のシーンへの遷移を要求する
         */


        InformationSubscene.prototype.onTimeout = function () {
          if (this.inContent) {
            this.requestedNextSubscene.fire();
          }
        };
        /**
         * Scene#setTimeoutのハンドラ
         * タッチ受付を開始する
         */


        InformationSubscene.prototype.onTimeoutToTouch = function () {
          if (this.inContent) {
            this.scene.pointDownCapture.handle(this, this.onTouch);
          }
        };
        /**
         * Scene#pointDownCaptureのハンドラ
         * 次のシーンへの遷移を要求する
         * @param {g.PointDownEvent} _e イベントパラメータ
         * @return {boolean} trueを返し、ハンドラ登録を解除する
         */


        InformationSubscene.prototype.onTouch = function (_e) {
          if (this.inContent) {
            this.requestedNextSubscene.fire();
          }

          return true;
        };

        return InformationSubscene;
      }(subscene_1.Subscene);

      exports.InformationSubscene = InformationSubscene;
    }, {
      "../commonNicowariGame/commonParameterReader": 42,
      "../commonNicowariGame/subscene": 45,
      "../util/asaEx": 59,
      "../util/entityUtil": 61,
      "../util/spriteUtil": 63,
      "./commonAsaInfo": 47,
      "./commonDefine": 49
    }],
    54: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var sceneController_1 = require("../commonNicowariGame/sceneController");

      var tl = require("@akashic-extension/akashic-timeline");

      var commonAsaInfo_1 = require("./commonAsaInfo");

      var commonAssetInfo_1 = require("./commonAssetInfo");

      var commonSoundInfo_1 = require("./commonSoundInfo");

      var commonDefine_1 = require("./commonDefine");

      var asaInfo_1 = require("../classes/asaInfo");

      var assetInfo_1 = require("../classes/assetInfo");

      var soundInfo_1 = require("../classes/soundInfo");

      var miscAssetInfo_1 = require("../classes/miscAssetInfo");

      var asaEx_1 = require("../util/asaEx");

      var gameUtil_1 = require("../util/gameUtil");

      var spriteUtil_1 = require("../util/spriteUtil");

      var entityUtil_1 = require("../util/entityUtil");

      var audioUtil_1 = require("../util/audioUtil");

      var titleSubscene_1 = require("./titleSubscene");

      var descriptionSubscene_1 = require("./descriptionSubscene");

      var gameSubscene_1 = require("./gameSubscene");

      var resultSubscene_1 = require("./resultSubscene");

      var wipeManager_1 = require("./wipeManager");

      var commonParameterReader_1 = require("../commonNicowariGame/commonParameterReader");

      var informationSubscene_1 = require("./informationSubscene");
      /**
       * 起動パラメータイベントの判定を行うメソッド
       * @param {g.MessageEvent} e MessageEventオブジェクト
       * @return {boolean} 起動パラメータイベントであればtrue
       */


      function isCOESessionStartMessage(e) {
        return e.data.type === "start";
      }
      /**
       * mainScene用のSceneを生成するクラス
       */


      var MainSceneController =
      /** @class */
      function (_super) {
        __extends(MainSceneController, _super);

        function MainSceneController() {
          return _super.call(this) || this;
        }
        /**
         * このクラスのインスタンスと、そのインスタンスで処理するSceneを生成する
         * @param {g.Game} _game Scene生成に使用するGame
         * @return {g.Scene} 生成したScene
         */


        MainSceneController.createMainScene = function (_game) {
          var controller = new MainSceneController();
          return controller.createScene(g.game);
        };
        /**
         * このクラスで処理するSceneを生成する
         * @param {g.Game} _game Scene生成に使用するGame
         * @return {g.Scene} 生成したScene
         * @override
         */


        MainSceneController.prototype.createScene = function (_game) {
          var _this = this;

          gameUtil_1.gameUtil.initGameState(); // レイアウト変更要求

          if (_game.external.send) {
            _game.external.send({
              type: "nx:layout",
              layout: "under-comment",
              background: "hidden"
            });
          }

          var assetIds = [];
          spriteUtil_1.spriteUtil.addAssetIdsFromAssetInfoMap(commonAssetInfo_1.CommonAssetInfo, assetIds);
          spriteUtil_1.spriteUtil.addAssetIdsFromAssetInfoMap(assetInfo_1.AssetInfo, assetIds);
          asaEx_1.asaEx.ResourceManager.addAsaAssetIds(spriteUtil_1.spriteUtil.getPjNamesFromAsainfoMap(commonAsaInfo_1.CommonAsaInfo), _game.assets, assetIds);
          asaEx_1.asaEx.ResourceManager.addAsaAssetIds(spriteUtil_1.spriteUtil.getPjNamesFromAsainfoMap(asaInfo_1.AsaInfo), _game.assets, assetIds);
          audioUtil_1.audioUtil.addAssetIdsFromSoundInfoMap(commonSoundInfo_1.CommonSoundInfo, assetIds);
          audioUtil_1.audioUtil.addAssetIdsFromSoundInfoMap(soundInfo_1.SoundInfo, assetIds);
          gameUtil_1.gameUtil.addAssetIdsFromMiscAssetInfoMap(miscAssetInfo_1.MiscAssetInfo, assetIds); // console.log("createScene: assetIds:"+assetIds.join(",")+".");

          var scene = new g.Scene({
            game: _game,
            assetIds: assetIds
          });
          var parameters = null;
          scene.loaded.handle(function () {
            // loaded完了後、OperationEventを処理するため1 tick遅延させる
            scene.update.handle(function () {
              // console.log("scene.update: parameters:" + parameters + ".");
              if (parameters) {
                // 起動パラメータの保持
                scene.game.vars.parameters = parameters;
                commonParameterReader_1.CommonParameterReader.read(parameters);
              } else {
                scene.game.vars.parameters = {};
                commonParameterReader_1.CommonParameterReader.read({});
              }

              _this.onLoaded(scene);

              return true;
            });
            return true;
          });
          scene.message.handle(function (e) {
            // console.log("scene.message: e:" + JSON.stringify(e) + ".");
            if (isCOESessionStartMessage(e)) {
              parameters = e.data.parameters;
              return true;
            }
          });
          return scene;
        };
        /**
         * Scene#loadedのハンドラ
         * onUpdateを呼ぶScene#updateのハンドラをこの中で登録する
         * @param {g.Scene} _scene 処理対象のScene
         * @return {boolean} 通常trueを返し、ハンドラ登録を解除する
         * @override
         */


        MainSceneController.prototype.onLoaded = function (_scene) {
          var _this = this;

          var game = _scene.game;
          game.vars.scenedata = {}; // このシーンで使いまわすTimelineインスタンス

          game.vars.scenedata.timeline = new tl.Timeline(_scene);
          this.mainLayer = new g.E({
            scene: _scene
          });
          entityUtil_1.entityUtil.appendEntity(this.mainLayer, _scene);
          this.wipeLayer = new g.E({
            scene: _scene
          });
          entityUtil_1.entityUtil.appendEntity(this.wipeLayer, _scene);
          this.wipeManager = new wipeManager_1.WipeManager(_scene);
          entityUtil_1.entityUtil.appendEntity(this.wipeManager, this.wipeLayer);
          var date = new Date();

          if (5 <= date.getHours() && date.getHours() <= 18) //昼背景
            {
              var shade = new g.FilledRect({
                scene: _scene,
                cssColor: "#A4C6FF",
                opacity: commonDefine_1.commonDefine.BG_SHADE_OPACITY,
                width: _scene.game.width,
                height: _scene.game.height
              });
              entityUtil_1.entityUtil.appendEntity(shade, this.mainLayer);
            } //夜背景 
          else {
              var shade = new g.FilledRect({
                scene: _scene,
                cssColor: "#000044",
                opacity: commonDefine_1.commonDefine.BG_SHADE_OPACITY,
                width: _scene.game.width,
                height: _scene.game.height
              });
              entityUtil_1.entityUtil.appendEntity(shade, this.mainLayer);
            }

          var shade = new g.FilledRect({
            scene: _scene,
            x: -100,
            y: 330,
            width: 10000,
            height: 100,
            cssColor: "#CD853F"
          });
          entityUtil_1.entityUtil.appendEntity(shade, this.mainLayer);
          var infoSubScene = this.informationSubscene = new informationSubscene_1.InformationSubscene(_scene);
          infoSubScene.init();
          infoSubScene.requestedNextSubscene.handle(this, this.goNextFromInformation);
          entityUtil_1.entityUtil.appendEntity(infoSubScene, this.mainLayer);
          var title = this.titleSubscene = new titleSubscene_1.TitleSubscene(_scene);
          title.init();
          title.requestedNextSubscene.handle(this, this.goNextFromTitle);
          entityUtil_1.entityUtil.appendEntity(title, this.mainLayer);
          var desc = this.descriptionSubscene = new descriptionSubscene_1.DescriptionSubscene(_scene);
          desc.init();
          desc.requestedNextSubscene.handle(this, this.goNextFromDescription);
          entityUtil_1.entityUtil.appendEntity(desc, this.mainLayer);
          var main = this.gameSubscene = new gameSubscene_1.GameSubscene(_scene);
          main.init();
          main.requestedNextSubscene.handle(this, this.goNextFromGame);
          entityUtil_1.entityUtil.appendEntity(main, this.mainLayer);
          var result = this.resultSubscene = new resultSubscene_1.ResultSubscene(_scene);
          result.init();
          result.requestedNextSubscene.handle(this, this.goNextFromResult);
          entityUtil_1.entityUtil.appendEntity(result, this.mainLayer);

          if (commonParameterReader_1.CommonParameterReader.muteAudio) {
            audioUtil_1.audioUtil.setMute(true);
          }

          title.setBgmName(main.getTitleBgmName());

          if (commonDefine_1.commonDefine.DEBUG_SKIP_PREGAMESUBSCENE) {
            this.changeSubscene(this.gameSubscene);
          } else {
            if (commonParameterReader_1.CommonParameterReader.isInitialSceneGame) {
              this.changeSubscene(this.descriptionSubscene);
            } else {
              if (commonParameterReader_1.CommonParameterReader.launchType === commonParameterReader_1.LaunchType.NOTHING) {
                this.changeSubscene(this.titleSubscene);
              } else {
                this.changeSubscene(this.informationSubscene);
              }
            }
          }

          _scene.update.handle(function () {
            return _this.onUpdate(_scene);
          });

          _scene.stateChanged.handle(function (e) {
            if (e === g.SceneState.Destroyed) {
              asaEx_1.asaEx.ResourceManager.removeAllLoadedResource();
              delete game.vars.scenedata;
              return true;
            }

            return false;
          });

          return true;
        };
        /**
         * Scene#updateのハンドラ
         * @param {g.Scene} _scene 処理対象のScene
         * @return {boolean} 通常falseを返す
         * @override
         */


        MainSceneController.prototype.onUpdate = function (_scene) {
          this.currentSubscene.onUpdate();
          return false;
        };
        /**
         * currentSubsceneをワイプなしで変更する
         * @param {Subscene} _next 変更後のサブシーン
         */


        MainSceneController.prototype.changeSubscene = function (_next) {
          if (this.currentSubscene) {
            this.currentSubscene.stopContent();
            this.currentSubscene.hideContent();
          }

          this.currentSubscene = _next;
          this.currentSubscene.showContent();
          this.currentSubscene.startContent();
        };
        /**
         * currentSubsceneをワイプありで変更する
         * @param {boolean} _isRtoL trueならばRtoL、falseならばLtoRのワイプを使用する
         * @param {Subscene} _next 変更後のサブシーン
         */


        MainSceneController.prototype.trasitionSubscene = function (_isRtoL, _next) {
          var _this = this;

          if (this.currentSubscene) {
            this.currentSubscene.stopContent();
          }

          this.wipeManager.startWipe(_isRtoL, function () {
            if (_this.currentSubscene) {
              _this.currentSubscene.hideContent();
            }

            _this.currentSubscene = _next;

            _this.currentSubscene.showContent();
          }, function () {
            _this.currentSubscene.startContent();
          });
        };
        /**
         * ゲーム開始説明画面からタイトルに遷移する
         * InformationSubScene#requestedNextSubsceneのハンドラ
         */


        MainSceneController.prototype.goNextFromInformation = function () {
          this.trasitionSubscene(true, this.titleSubscene);
        };
        /**
         * タイトルから説明に遷移する
         * TitleSubscene#requestedNextSubsceneのハンドラ
         */


        MainSceneController.prototype.goNextFromTitle = function () {
          this.trasitionSubscene(true, this.descriptionSubscene);
        };
        /**
         * 説明からゲームに遷移する
         * DescriptionSubscene#requestedNextSubsceneのハンドラ
         */


        MainSceneController.prototype.goNextFromDescription = function () {
          this.trasitionSubscene(true, this.gameSubscene);
        };
        /**
         * ゲームからリザルトに遷移する
         * GameSubscene#requestedNextSubsceneのハンドラ
         */


        MainSceneController.prototype.goNextFromGame = function () {
          this.trasitionSubscene(false, this.resultSubscene);
        };
        /**
         * リザルトからタイトルに遷移する
         * ResultSubscene#requestedNextSubsceneのハンドラ
         */


        MainSceneController.prototype.goNextFromResult = function () {
          if (commonDefine_1.commonDefine.DEBUG_SKIP_PREGAMESUBSCENE) {
            this.changeSubscene(this.gameSubscene);
          } else {
            if (commonParameterReader_1.CommonParameterReader.isInitialSceneGame) {
              this.changeSubscene(this.descriptionSubscene);
            } else {
              this.changeSubscene(this.informationSubscene);
            }
          }
        };

        return MainSceneController;
      }(sceneController_1.SceneController);

      exports.MainSceneController = MainSceneController;
    }, {
      "../classes/asaInfo": 31,
      "../classes/assetInfo": 32,
      "../classes/miscAssetInfo": 36,
      "../classes/soundInfo": 38,
      "../commonNicowariGame/commonParameterReader": 42,
      "../commonNicowariGame/sceneController": 44,
      "../util/asaEx": 59,
      "../util/audioUtil": 60,
      "../util/entityUtil": 61,
      "../util/gameUtil": 62,
      "../util/spriteUtil": 63,
      "./commonAsaInfo": 47,
      "./commonAssetInfo": 48,
      "./commonDefine": 49,
      "./commonSoundInfo": 50,
      "./descriptionSubscene": 51,
      "./gameSubscene": 52,
      "./informationSubscene": 53,
      "./resultSubscene": 55,
      "./titleSubscene": 56,
      "./wipeManager": 57,
      "@akashic-extension/akashic-timeline": 30
    }],
    55: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var commonAsaInfo_1 = require("./commonAsaInfo");

      var commonAssetInfo_1 = require("./commonAssetInfo");

      var commonSoundInfo_1 = require("./commonSoundInfo");

      var commonDefine_1 = require("./commonDefine");

      var asaEx_1 = require("../util/asaEx");

      var spriteUtil_1 = require("../util/spriteUtil");

      var entityUtil_1 = require("../util/entityUtil");

      var gameUtil_1 = require("../util/gameUtil");

      var audioUtil_1 = require("../util/audioUtil");

      var subscene_1 = require("../commonNicowariGame/subscene");
      /**
       * リザルトサブシーンの処理と表示を行うクラス
       */


      var ResultSubscene =
      /** @class */
      function (_super) {
        __extends(ResultSubscene, _super);

        function ResultSubscene(_scene) {
          var _this = _super.call(this, _scene) || this;
          /** tips画像リスト */


          _this.tipsImgList = [];
          return _this;
        }
        /**
         * このクラスで使用するオブジェクトを生成する
         * @override
         */


        ResultSubscene.prototype.init = function () {
          this.requestedNextSubscene = new g.Trigger();
          var game = this.scene.game;

          if (commonDefine_1.commonDefine.SHOW_TIPS) {
            this.offsetY = 0;
            this.initTipsImgList();
          } else {
            this.offsetY = commonDefine_1.commonDefine.RESULT_OBJECTS_OFFSET_Y;
          }

          var result = this.asaResult = new asaEx_1.asaEx.Actor(this.scene, commonAsaInfo_1.CommonAsaInfo.nwCommon.pj);
          result.x = game.width / 2;
          result.y = game.height / 2 + this.offsetY;
          result.update.handle(spriteUtil_1.spriteUtil.makeActorUpdater(result));
          result.hide();
          entityUtil_1.entityUtil.appendEntity(result, this);
          this.scoreValue = 0;
          var font = gameUtil_1.gameUtil.createNumFontWithAssetInfo(commonAssetInfo_1.CommonAssetInfo.numResult, this.scene.assets);
          var score = this.scoreLabel = entityUtil_1.entityUtil.createNumLabel(this.scene, font, commonDefine_1.commonDefine.RESULT_SCORE_DIGIT);
          entityUtil_1.entityUtil.moveNumLabelTo(score, 320 + (game.width - 480) / 2, 84 + this.offsetY);
          score.hide();
          entityUtil_1.entityUtil.appendEntity(score, this);
          this.isRolling = false;
          entityUtil_1.entityUtil.hideEntity(this);
        };
        /**
         * 表示系以外のオブジェクトをdestroyする
         * 表示系のオブジェクトはg.Eのdestroyに任せる
         * @override
         */


        ResultSubscene.prototype.destroy = function () {
          if (this.destroyed()) {
            return;
          }

          if (this.requestedNextSubscene) {
            this.requestedNextSubscene.destroy();
            this.requestedNextSubscene = null;
          }

          _super.prototype.destroy.call(this);
        };
        /**
         * 表示を開始する
         * このサブシーンに遷移するワイプ演出で表示が始まる時点で呼ばれる
         * @override
         */


        ResultSubscene.prototype.showContent = function () {
          this.scoreValue = gameUtil_1.gameUtil.getGameScore();
          this.scoreLabel.hide();
          entityUtil_1.entityUtil.showEntity(this);
        };
        /**
         * 動作を開始する
         * このサブシーンに遷移するワイプ演出が完了した時点で呼ばれる
         * @override
         */


        ResultSubscene.prototype.startContent = function () {
          this.asaResult.play(commonAsaInfo_1.CommonAsaInfo.nwCommon.anim.result, 0, false, 1);
          this.createTips();
          audioUtil_1.audioUtil.play(commonSoundInfo_1.CommonSoundInfo.seSet.rollResult);
          this.isRolling = true;
          this.setScoreLabelText();
          entityUtil_1.entityUtil.showEntity(this.scoreLabel);
          entityUtil_1.entityUtil.showEntity(this.asaResult);
          this.scene.setTimeout(commonDefine_1.commonDefine.RESULT_ROLL_WAIT, this, this.onRollEnd);
        };
        /**
         * Scene#updateを起点とする処理から呼ばれる
         * @override
         */


        ResultSubscene.prototype.onUpdate = function () {
          if (this.isRolling) {
            this.setScoreLabelText();
          }
        };
        /**
         * 動作を停止する
         * このサブシーンから遷移するワイプ演出が始まる時点で呼ばれる
         * @override
         */


        ResultSubscene.prototype.stopContent = function () {// NOP
        };
        /**
         * 表示を終了する
         * このサブシーンから遷移するワイプ演出で表示が終わる時点で呼ばれる
         * @override
         */


        ResultSubscene.prototype.hideContent = function () {
          entityUtil_1.entityUtil.hideEntity(this);
          entityUtil_1.entityUtil.hideEntity(this.asaResult);
        };
        /**
         * スコアラベルを設定する
         */


        ResultSubscene.prototype.setScoreLabelText = function () {
          var value = this.scoreValue;
          var len = String(value).length;

          if (this.isRolling) {
            value = this.scene.game.random[0].get(Math.pow(10, len - 1), Math.pow(10, len) - 1);
          }

          entityUtil_1.entityUtil.setLabelText(this.scoreLabel, String(value));
        };
        /**
         * Scene#setTimeoutのハンドラ
         * ロール演出の終了時用
         */


        ResultSubscene.prototype.onRollEnd = function () {
          audioUtil_1.audioUtil.stop(commonSoundInfo_1.CommonSoundInfo.seSet.rollResult);
          audioUtil_1.audioUtil.play(commonSoundInfo_1.CommonSoundInfo.seSet.rollResultFinish);
          this.isRolling = false;
          this.setScoreLabelText();

          if (typeof window !== "undefined" && window.RPGAtsumaru) {
            // RPG アツマール上でのみ実行されるコード
            var scoreboards = window.RPGAtsumaru.experimental.scoreboards;
            scoreboards.setRecord(1, g.game.vars.gameState.score).then(function () {
              window.setTimeout(function () {
                scoreboards.display(1);
              }, 3000);
            });

            if (commonDefine_1.commonDefine.ENABLE_RETRY) {
              // リトライ操作を受け付ける場合
              this.scene.pointDownCapture.handle(this, this.onTouch);
            }
          }
        };
        /**
         * Scene#pointDownCaptureのハンドラ
         * 次のシーンへの遷移を要求する
         * @param {g.PointDownEvent} _e イベントパラメータ
         * @return {boolean} trueを返し、ハンドラ登録を解除する
         */


        ResultSubscene.prototype.onTouch = function (_e) {
          this.requestedNextSubscene.fire();
          return true;
        };
        /**
         * tips画像を作成する
         */


        ResultSubscene.prototype.createTips = function () {
          if (this.tipsImgList.length === 0) return;
          var randIndex = gameUtil_1.gameUtil.getRandomLessThanMax(this.tipsImgList.length);
          var asset = this.tipsImgList[randIndex];
          var size = commonDefine_1.commonDefine.TIPS_IMG_SIZE;
          var spr = new g.Sprite({
            scene: this.scene,
            src: this.scene.assets[asset],
            width: size.width,
            height: size.height
          });
          spr.moveTo(commonDefine_1.commonDefine.TIPS_IMG_POS);
          entityUtil_1.entityUtil.appendEntity(spr, this);
        };
        /**
         * CommonAssetInfoからtips画像アセットをリスト化する
         */


        ResultSubscene.prototype.initTipsImgList = function () {
          var _this = this;

          this.tipsImgList = [];
          var wk = commonAssetInfo_1.CommonAssetInfo;
          Object.keys(wk).filter(function (e) {
            return e.indexOf(commonDefine_1.commonDefine.TIPS_VAR_NAME_HEAD) === 0; // commonDefine.TIPS_VAR_NAME_HEADで始まるオブジェクト
          }).forEach(function (val) {
            var info = wk[val]; // console.log(info.img);

            _this.tipsImgList.push(info.img);
          });
        };

        return ResultSubscene;
      }(subscene_1.Subscene);

      exports.ResultSubscene = ResultSubscene;
    }, {
      "../commonNicowariGame/subscene": 45,
      "../util/asaEx": 59,
      "../util/audioUtil": 60,
      "../util/entityUtil": 61,
      "../util/gameUtil": 62,
      "../util/spriteUtil": 63,
      "./commonAsaInfo": 47,
      "./commonAssetInfo": 48,
      "./commonDefine": 49,
      "./commonSoundInfo": 50
    }],
    56: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var subscene_1 = require("../commonNicowariGame/subscene");

      var commonAsaInfo_1 = require("./commonAsaInfo");

      var asaEx_1 = require("../util/asaEx");

      var spriteUtil_1 = require("../util/spriteUtil");

      var entityUtil_1 = require("../util/entityUtil");

      var audioUtil_1 = require("../util/audioUtil");

      var commonDefine_1 = require("./commonDefine");
      /**
       * タイトルサブシーンの処理と表示を行うクラス
       */


      var TitleSubscene =
      /** @class */
      function (_super) {
        __extends(TitleSubscene, _super);

        function TitleSubscene(_scene) {
          return _super.call(this, _scene) || this;
        }
        /**
         * このクラスで使用するオブジェクトを生成する
         * @override
         */


        TitleSubscene.prototype.init = function () {
          this.autoNext = commonDefine_1.commonDefine.TITLE_WAIT > 0;
          this.inContent = false;
          this.bgmName = "";
          this.requestedNextSubscene = new g.Trigger();
          var game = this.scene.game;
          var title = this.asaTitle = new asaEx_1.asaEx.Actor(this.scene, commonAsaInfo_1.CommonAsaInfo.nwTitle.pj);
          title.x = game.width / 2;
          title.y = game.height / 2;
          title.update.handle(spriteUtil_1.spriteUtil.makeActorUpdater(title));
          title.hide();
          entityUtil_1.entityUtil.appendEntity(title, this);
          entityUtil_1.entityUtil.hideEntity(this);
        };
        /**
         * 表示系以外のオブジェクトをdestroyする
         * 表示系のオブジェクトはg.Eのdestroyに任せる
         * @override
         */


        TitleSubscene.prototype.destroy = function () {
          if (this.destroyed()) {
            return;
          }

          if (this.requestedNextSubscene) {
            this.requestedNextSubscene.destroy();
            this.requestedNextSubscene = null;
          }

          _super.prototype.destroy.call(this);
        };
        /**
         * タイトル画面のBGMのアセット名を設定するメソッド
         * @param {string} _bgmName タイトル画面のBGMのアセット名
         */


        TitleSubscene.prototype.setBgmName = function (_bgmName) {
          this.bgmName = _bgmName;
        };
        /**
         * 表示を開始する
         * このサブシーンに遷移するワイプ演出で表示が始まる時点で呼ばれる
         * @override
         */


        TitleSubscene.prototype.showContent = function () {
          audioUtil_1.audioUtil.play(this.bgmName);
          entityUtil_1.entityUtil.showEntity(this);
        };
        /**
         * 動作を開始する
         * このサブシーンに遷移するワイプ演出が完了した時点で呼ばれる
         * @override
         */


        TitleSubscene.prototype.startContent = function () {
          this.inContent = true;
          this.asaTitle.play(commonAsaInfo_1.CommonAsaInfo.nwTitle.anim.title, 0, false, 1);
          entityUtil_1.entityUtil.showEntity(this.asaTitle);

          if (this.autoNext) {
            this.scene.setTimeout(commonDefine_1.commonDefine.TITLE_WAIT, this, this.onTimeout);

            if (commonDefine_1.commonDefine.TOUCH_SKIP_WAIT > 0) {
              this.scene.setTimeout(commonDefine_1.commonDefine.TOUCH_SKIP_WAIT, this, this.onTimeoutToTouch);
            }
          } else {
            this.asaTitle.ended.handle(this, this.onTitleEnd);
          }
        };
        /**
         * Scene#updateを起点とする処理から呼ばれる
         * @override
         */


        TitleSubscene.prototype.onUpdate = function () {// NOP
        };
        /**
         * 動作を停止する
         * このサブシーンから遷移するワイプ演出が始まる時点で呼ばれる
         * @override
         */


        TitleSubscene.prototype.stopContent = function () {
          // console.log("TitleSubscene.stopContent: inContent:"+this.inContent+".");
          this.inContent = false;
          this.scene.pointDownCapture.removeAll(this);
        };
        /**
         * 表示を終了する
         * このサブシーンから遷移するワイプ演出で表示が終わる時点で呼ばれる
         * @override
         */


        TitleSubscene.prototype.hideContent = function () {
          audioUtil_1.audioUtil.stop(this.bgmName);
          entityUtil_1.entityUtil.hideEntity(this);
          entityUtil_1.entityUtil.hideEntity(this.asaTitle);
        };
        /**
         * Scene#setTimeoutのハンドラ
         * 次のシーンへの遷移を要求する
         */


        TitleSubscene.prototype.onTimeout = function () {
          // console.log("TitleSubscene.onTimeout: inContent:"+this.inContent+".");
          if (this.inContent) {
            this.requestedNextSubscene.fire();
          }
        };
        /**
         * Scene#setTimeoutのハンドラ
         * タッチ受付を開始する
         */


        TitleSubscene.prototype.onTimeoutToTouch = function () {
          // console.log("TitleSubscene.onTimeoutToTouch: inContent:"+this.inContent+".");
          if (this.inContent) {
            this.scene.pointDownCapture.handle(this, this.onTouch);
          }
        };
        /**
         * Actor#endedのハンドラ
         * タイトルロゴアニメの終了時用
         * @return {boolean} trueを返し、ハンドラ登録を解除する
         */


        TitleSubscene.prototype.onTitleEnd = function () {
          if (this.inContent) {
            this.scene.pointDownCapture.handle(this, this.onTouch);
          }

          return true;
        };
        /**
         * Scene#pointDownCaptureのハンドラ
         * 次のシーンへの遷移を要求する
         * @param {g.PointDownEvent} e イベントパラメータ
         * @return {boolean} trueを返し、ハンドラ登録を解除する
         */


        TitleSubscene.prototype.onTouch = function (_e) {
          // console.log("TitleSubscene.onTouch: inContent:"+this.inContent+".");
          if (this.inContent) {
            this.requestedNextSubscene.fire();
          }

          return true;
        };

        return TitleSubscene;
      }(subscene_1.Subscene);

      exports.TitleSubscene = TitleSubscene;
    }, {
      "../commonNicowariGame/subscene": 45,
      "../util/asaEx": 59,
      "../util/audioUtil": 60,
      "../util/entityUtil": 61,
      "../util/spriteUtil": 63,
      "./commonAsaInfo": 47,
      "./commonDefine": 49
    }],
    57: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var gameUtil_1 = require("../util/gameUtil");

      var entityUtil_1 = require("../util/entityUtil");

      var commonAsaInfo_1 = require("./commonAsaInfo");

      var asaEx_1 = require("../util/asaEx");
      /**
       * ワイプ演出を管理するクラス
       */


      var WipeManager =
      /** @class */
      function (_super) {
        __extends(WipeManager, _super);

        function WipeManager(_scene) {
          var _this = _super.call(this, {
            scene: _scene
          }) || this;

          _this.fadeAsa = new asaEx_1.asaEx.Actor(_scene, commonAsaInfo_1.CommonAsaInfo.nwCommon.pj);
          _this.fadeAsa.x = _scene.game.width / 2;
          _this.fadeAsa.y = _scene.game.height / 2;
          _this.fadeAsa.pause = true;

          _this.append(_this.fadeAsa);

          entityUtil_1.entityUtil.hideEntity(_this.fadeAsa);
          return _this;
        }
        /**
         * @override g.E#destroy
         */


        WipeManager.prototype.destroy = function () {
          if (this.destroyed()) {
            return;
          }

          if (!!this.fadeAsa) {
            this.fadeAsa.destroy();
            this.fadeAsa = null;
          }

          _super.prototype.destroy.call(this);
        };
        /**
         * ワイプ演出を開始する
         * @param {boolean} _isRtoL trueならばRtoL、falseならばLtoRのアニメを使用する
         * @param {() => void} _funcMid 全画面が黒になった時点で呼ばれる関数
         * @param {() => void} _funcFinal ワイプ演出が終了した時点で呼ばれる関数
         */


        WipeManager.prototype.startWipe = function (_isRtoL, _funcMid, _funcFinal) {
          var _this = this;

          var animName = _isRtoL ? commonAsaInfo_1.CommonAsaInfo.nwCommon.anim.fadeRtoL : commonAsaInfo_1.CommonAsaInfo.nwCommon.anim.fadeLtoR;
          this.fadeAsa.play(animName, 0, false, 1.0);
          this.fadeAsa.pause = false;
          entityUtil_1.entityUtil.showEntity(this.fadeAsa); // ワイプアニメの黒幕移動部分のフレーム数

          var wipeFrames = 6; // 黒幕で完全に画面が隠れるまでのフレーム数

          var inFrames = wipeFrames / 2 | 0;
          var outFrames = wipeFrames - inFrames;
          var timeline = this.scene.game.vars.scenedata.timeline;
          gameUtil_1.gameUtil.createTween(timeline, this.fadeAsa).every(function () {
            _this.fadeAsa.modified();

            _this.fadeAsa.calc();
          }, gameUtil_1.gameUtil.frame2MSec(inFrames)).call(function () {
            if (_funcMid) {
              _funcMid();
            }
          }).every(function () {
            _this.fadeAsa.modified();

            _this.fadeAsa.calc();
          }, gameUtil_1.gameUtil.frame2MSec(outFrames)).call(function () {
            _this.fadeAsa.pause = true;
            entityUtil_1.entityUtil.hideEntity(_this.fadeAsa);

            if (_funcFinal) {
              _funcFinal();
            }
          });
        };

        return WipeManager;
      }(g.E);

      exports.WipeManager = WipeManager;
    }, {
      "../util/asaEx": 59,
      "../util/entityUtil": 61,
      "../util/gameUtil": 62,
      "./commonAsaInfo": 47
    }],
    58: [function (require, module, exports) {
      "use strict";

      var mainSceneController_1 = require("./common/mainSceneController");

      module.exports = function () {
        return mainSceneController_1.MainSceneController.createMainScene(g.game);
      };
    }, {
      "./common/mainSceneController": 54
    }],
    59: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var asa = require("@akashic-extension/akashic-animation");
      /**
       * asa.Actor機能拡張を目的としたクラス群
       */


      var asaEx;

      (function (asaEx) {
        /**
         * asa関連データの管理クラス
         * 以下の機能を提供する
         * ・シーンロード時のアセット名配列生成
         * ・asa.Resourceの生成と保持
         * ・アニメ名に対応するボーン名を取得
         */
        var ResourceManager =
        /** @class */
        function () {
          function ResourceManager() {}
          /**
           * asapjのアセット名配列から必要なファイルのアセット名を追加先配列に追加する
           * @param _pjNames asapjファイルのアセット名配列
           * @param _assets アセットのマップ
           * @param _assetIds アセット名を追加する配列
           */


          ResourceManager.addAsaAssetIds = function (_pjNames, _assets, _assetIds) {
            var ids = ResourceManager.getAssetIds(_pjNames, _assets); // g.game.logger.debug("addAsaAssetIds: before: assetIds.length:"+assetIds.length+", pjNames.length:"+pjNames.length+".");

            _assetIds.push.apply(_assetIds, ids); // g.game.logger.debug("addAsaAssetIds: after: assetIds.length:"+assetIds.length+".");

          };
          /**
           * asapjのアセット名配列から必要なファイルのアセット名の配列を生成する
           * @param _pjNames asapjファイルのアセット名配列
           * @param _assets アセットのマップ
           * @return asapjから参照されるファイルのアセット名配列
           */


          ResourceManager.getAssetIds = function (_pjNames, _assets) {
            var res = [];
            var iEnd = _pjNames.length;

            for (var i = 0; i < iEnd; ++i) {
              var pjName = _pjNames[i]; // console.log("makeAnimBoneTable: pjNames["+i+"]:"+pjName+".");

              if (!_assets[pjName]) {
                g.game.logger.error("ResourceManager.getAssetIds: not found asapj:" + pjName + " in assets. Not set global option in game.json?");
                return null;
              }

              var pjJson = _assets[pjName].data;
              var pjData = JSON.parse(pjJson);
              var fileNames = [pjName].concat(pjData.contents.boneSetFileNames, pjData.contents.skinFileNames, pjData.contents.animationFileNames);
              res = res.concat(makeAssetNames_(fileNames));
            }

            return res;
          };
          /**
           * asapjのアセット名に応じてasa.Resourceのインスタンスを返す
           * まだg.game.vars.asaResourcesに存在しないasapjの場合は新たなasa.Resourceを生成し、
           * g.game.vars.asaResourcesに追加する
           * @param _scene g.Sceneのインスタンス
           * @param _pjName asapjファイルのアセット名
           * @return asa.Resourceのインスタンス
           */


          ResourceManager.getResource = function (_scene, _pjName) {
            if (!g.game.vars.asaResources) {
              g.game.vars.asaResources = {};
            } // console.log("getResource: pjName:"+pjName+".");


            var resources = g.game.vars.asaResources;
            var res = null;

            if (resources.hasOwnProperty(_pjName)) {
              res = resources[_pjName];
            } else {
              res = new asa.Resource();
              res.loadProject(_pjName, _scene.assets);
              resources[_pjName] = res;
            }

            return res;
          };
          /**
           * asa.Resourceのインスタンスからスキン名の配列を生成する
           * @param _resource asa.Resourceのインスタンス
           * @return スキン名の配列
           */


          ResourceManager.getSkinNames = function (_resource) {
            var res = [];
            var iEnd = _resource.skins.length;

            for (var i = 0; i < iEnd; ++i) {
              res[res.length] = _resource.skins[i].name;
            }

            return res;
          };
          /**
           * アニメ名からボーン名を取得する
           * @param _pjName asapjのアセット名
           * @param _animName アニメ名
           * @return ボーン名
           */


          ResourceManager.getBoneName = function (_pjName, _animName) {
            var tableMap = g.game.vars.asaAnimBoneTableMap;
            var table = tableMap[_pjName]; // console.log("getBoneName: table["+anName+"]:"+table[anName]+".");

            return table[_animName];
          };
          /**
           * 指定したasapjの情報をg.game.vars.asaAnimBoneTableMapと
           * g.game.vars.asaResourcesから削除する
           * @param _pjName asapjのアセット名
           */


          ResourceManager.removeLoadedResource = function (pjName) {
            if (g.game.vars.asaAnimBoneTableMap) {
              if (g.game.vars.asaAnimBoneTableMap.hasOwnProperty(pjName)) {
                delete g.game.vars.asaAnimBoneTableMap[pjName];
              }
            }

            if (g.game.vars.asaResources) {
              if (g.game.vars.asaResources.hasOwnProperty(pjName)) {
                delete g.game.vars.asaResources[pjName];
              }
            }
          };
          /**
           * g.game.vars.asaAnimBoneTableMapとg.game.vars.asaResourcesの内容を
           * すべて削除する
           */


          ResourceManager.removeAllLoadedResource = function () {
            if (g.game.vars.asaAnimBoneTableMap) {
              delete g.game.vars.asaAnimBoneTableMap;
            }

            if (g.game.vars.asaResources) {
              delete g.game.vars.asaResources;
            }
          };

          return ResourceManager;
        }();

        asaEx.ResourceManager = ResourceManager;
        /**
         * asa.Actorを機能拡張したクラス
         * 以下の機能を提供する
         * ・インスタンス生成時にasapjのアセット名から自動的に
         *   asa.ActorParameterObjectを生成する
         * （asa.Resourceの生成もResourceManagerを利用して自動的に行う）
         * ・play時にアニメ名に対応したボーンに自動的に切り替える
         * ・ボーン名を指定してボーンの現在の座標を取得する
         */

        var Actor =
        /** @class */
        function (_super) {
          __extends(Actor, _super);
          /**
           * Actorコンストラクタ
           * @param _scene g.Sceneのインスタンス
           * @param _pjName asapjのアセット名
           * @param opt_animName (optional)アニメ名
           * @param opt_loopFlag
           * (optional)再生をループするか指定するフラグ。真の時ループ再生。
           * 省略時はtrue。
           */


          function Actor(_scene, _pjName, opt_animName, opt_loopFlag) {
            if (opt_loopFlag === void 0) {
              opt_loopFlag = true;
            }

            var _this = this;

            if (!g.game.vars.asaAnimBoneTableMap) {
              g.game.vars.asaAnimBoneTableMap = {};
            }

            if (!g.game.vars.asaAnimBoneTableMap.hasOwnProperty(_pjName)) {
              g.game.vars.asaAnimBoneTableMap[_pjName] = loadAnimBoneTable_(_pjName, _scene.assets);
            }

            var resource = ResourceManager.getResource(_scene, _pjName);

            if (!opt_animName) {
              opt_animName = resource.animations[0].name;
            }

            var param = {
              scene: _scene,
              resource: resource,
              animationName: opt_animName,
              skinNames: ResourceManager.getSkinNames(resource),
              boneSetName: ResourceManager.getBoneName(_pjName, opt_animName),
              width: 1,
              height: 1
            };
            _this = _super.call(this, param) || this;
            _this.loop = opt_loopFlag;
            _this.pjName = _pjName;
            return _this;
          }
          /**
           * アニメーションを再生する
           * @param _animName アニメ名
           * @param _startFrame 再生開始フレーム
           * @param _loopFlag 再生をループするか指定するフラグ。真の時ループ再生
           * @param _playSpeed 再生速度。1.0で通常の再生速度
           * @param opt_noCalcFlag (optional)super.playのあとに、calcを行うか指定するフラグ。trueの場合はcalcを行わない。
           * @override
           */


          Actor.prototype.play = function (_animName, _startFrame, _loopFlag, _playSpeed, opt_noCalcFlag) {
            if (opt_noCalcFlag === void 0) {
              opt_noCalcFlag = false;
            }

            var currBnName = this.getBoneName();
            var nextBnName = this.getBoneName(_animName); // console.log("AsaEx.Actor.play: anName:"+anName+".");

            if (currBnName !== nextBnName) {
              this.changeBone(nextBnName);
            }

            _super.prototype.play.call(this, _animName, _startFrame, _loopFlag, _playSpeed);

            if (!opt_noCalcFlag) {
              this.modified();
              this.calc();
            }
          };
          /**
           * Actorの位置を原点としたボーンの座標を取得する
           * @param _boneName ボーン名
           * @param opt_matrix (optional)ボーンに対する位置や向きを変える変換行列
           * @return ボーンの座標
           */


          Actor.prototype.getBonePosition = function (_boneName, opt_matrix) {
            var inScene = this.getBonePositionInScene(_boneName, opt_matrix);

            var rootMatrix = this.getMatrix()._matrix;

            return {
              x: inScene.x - rootMatrix[4],
              y: inScene.y - rootMatrix[5]
            };
          };
          /**
           * Scene上のボーンの座標を取得する
           * @param _boneName ボーン名
           * @param opt_matrix (optional)ボーンに対する位置や向きを変える変換行列
           * @return ボーンの座標
           */


          Actor.prototype.getBonePositionInScene = function (_boneName, opt_matrix) {
            var bones = this.skeleton.bones;
            var iEnd = bones.length;

            for (var i = 0; i < iEnd; ++i) {
              // console.log("getBonePosition: bones["+i+"].name:"+bones[i].name+", boneName:"+boneName+".");
              if (bones[i].name === _boneName) {
                var boneMatrix = this.skeleton.composedCaches[bones[i].arrayIndex].m._matrix;

                if (opt_matrix) {
                  boneMatrix = applyMatrix(boneMatrix, opt_matrix._matrix);
                } // console.log("getBonePosition: bones["+i+"].name:"+bones[i].name+", x:"+matrix[4]+", y:"+matrix[5]+".");


                return {
                  x: boneMatrix[4],
                  y: boneMatrix[5]
                };
              }
            }

            return {
              x: 0,
              y: 0
            };
          };
          /**
           * アニメ名に対応するボーン名を取得する
           * @param _animName アニメ名
           * @return ボーン名
           */


          Actor.prototype.getBoneName = function (_animName) {
            if (!_animName) {
              _animName = this.animation.name;
            }

            return ResourceManager.getBoneName(this.pjName, _animName);
          };
          /**
           * ボーンを切り替える
           * @param _boneName ボーン名
           */


          Actor.prototype.changeBone = function (_boneName) {
            var _this = this; // vvv akashic-animation/lib/Actor.js より引用
            // skeleton


            var boneSet = this.resource.getBoneSetByName(_boneName);
            this.skeleton = new asa.Skeleton(boneSet.bones, function () {
              return _this.getMatrix();
            }); // collider

            this.colliders = [];
            setupCollider_(boneSet.bones, this); // ^^^ akashic-animation/lib/Actor.js より引用
          };

          return Actor;
        }(asa.Actor);

        asaEx.Actor = Actor;
        /**
         * 変換行列を掛ける
         * @param _m1 掛けられる変換行列
         * @param _m2 掛ける変換行列
         * @return 掛けた結果
         */

        function applyMatrix(_m1, _m2) {
          var m0 = [1, 0, 0, 1, 0, 0];
          m0[0] = _m1[0] * _m2[0] + _m1[2] * _m2[1];
          m0[1] = _m1[1] * _m2[0] + _m1[3] * _m2[1];
          m0[2] = _m1[0] * _m2[2] + _m1[2] * _m2[3];
          m0[3] = _m1[1] * _m2[2] + _m1[3] * _m2[3];
          m0[4] = _m1[0] * _m2[4] + _m1[2] * _m2[5] + _m1[4];
          m0[5] = _m1[1] * _m2[4] + _m1[3] * _m2[5] + _m1[5];
          return m0;
        }

        asaEx.applyMatrix = applyMatrix; // vvv akashic-animation/sample/src/demo.ts より引用

        /**
         * 変換行列の逆行列を生成する
         * @param _m 変換行列
         * @return 逆行列
         */

        function invertMatrix(_m) {
          var a = _m[0];
          var b = _m[1];
          var c = _m[2];
          var d = _m[3];
          var dt = a * d - b * c; // det

          if (dt === 0) {
            return undefined;
          }

          var e = _m[4];
          var f = _m[5];
          var mi = new Array(6);
          mi[0] = d / dt;
          mi[1] = -b / dt;
          mi[2] = -c / dt;
          mi[3] = a / dt;
          mi[4] = (c * f - d * e) / dt;
          mi[5] = -(a * f - b * e) / dt;
          return mi;
        }

        asaEx.invertMatrix = invertMatrix; // ^^^ akashic-animation/sample/src/demo.ts より引用

        /**
         * g.E用アタッチメント
         * g.Eをasa.Actorのボーンにアタッチするためのasa.Attachmentサブクラス
         */

        var EntityAttachment =
        /** @class */
        function (_super) {
          __extends(EntityAttachment, _super);
          /**
           * ActorAttachmentコンストラクタ
           * @param _actor アタッチするActorのインスタンス
           * @param opt_matrix (optional)アタッチ先のボーンに対しての位置や向きを変えるための変換行列
           */


          function EntityAttachment(_entity, opt_matrix) {
            var _this = _super.call(this) || this;

            _this.entity = _entity;
            _this.matrix = opt_matrix || new g.PlainMatrix(); // g.game.logger.debug("ActorAttachment: matrix._matrix:["+this.matrix._matrix.join()+"].");

            _this.cancelParentSR = false;
            return _this;
          }
          /**
           * Actor#renderPosturesから呼ばれるAttachment#renderの実装
           * @param _renderer g.Rendererのインスタンス
           * @override
           */


          EntityAttachment.prototype.render = function (_renderer) {
            if (this.cancelParentSR) {
              // vvv akashic-animation/lib/Skeleton.js より引用
              var m0 = [1, 0, 0, 1, 0, 0];
              var m1 = this.posture.m._matrix;
              var m2 = this.matrix._matrix; // m0 = m1 * m2

              m0[0] = m1[0] * m2[0] + m1[2] * m2[1];
              m0[1] = m1[1] * m2[0] + m1[3] * m2[1];
              m0[2] = m1[0] * m2[2] + m1[2] * m2[3];
              m0[3] = m1[1] * m2[2] + m1[3] * m2[3];
              m0[4] = m1[0] * m2[4] + m1[2] * m2[5] + m1[4];
              m0[5] = m1[1] * m2[4] + m1[3] * m2[5] + m1[5]; // ^^^ akashic-animation/lib/Skeleton.js より引用
              // g.game.logger.debug("ActorAttachment.render: m0:["+m0.join()+"].");
              // vvv akashic-animation/sample/src/demo.ts より引用

              var mi = invertMatrix(this.posture.m._matrix);

              if (!mi) {
                return;
              }

              _renderer.save();

              {
                _renderer.transform(mi); // cancel posture matrix


                _renderer.translate(m0[4], m0[5]);

                this.entity.render(_renderer);
              }

              _renderer.restore(); // ^^^ akashic-animation/sample/src/demo.ts より引用

            } else {
              _renderer.save();

              {
                _renderer.transform(this.matrix._matrix);

                this.entity.render(_renderer);
              }

              _renderer.restore();
            }
          };

          return EntityAttachment;
        }(asa.Attachment);

        asaEx.EntityAttachment = EntityAttachment;
        /**
         * Actor用アタッチメント
         * asa.Actorを他のActorのボーンにアタッチするためのasa.Attachmentサブクラス
         * EntityAttachmentに置き換えられるが、互換性のためEntityAttachmentの
         * コンストラクタのみをオーバーライドしたクラスとして残している
         */

        var ActorAttachment =
        /** @class */
        function (_super) {
          __extends(ActorAttachment, _super);
          /**
           * ActorAttachmentコンストラクタ
           * @param _actor アタッチするActorのインスタンス
           * @param opt_matrix (optional)アタッチ先のボーンに対しての位置や向きを変えるための変換行列
           */


          function ActorAttachment(_actor, opt_matrix) {
            var _this = this;

            if (opt_matrix) {
              _this = _super.call(this, _actor, opt_matrix) || this;
            } else {
              _this = _super.call(this, _actor) || this;
            }

            return _this;
          }

          return ActorAttachment;
        }(EntityAttachment);

        asaEx.ActorAttachment = ActorAttachment;
        /**
         * ファイル名の配列からアセット名の配列を生成する
         * @param _fileNames ファイル名の配列
         * @return アセット名の配列
         * @private
         */

        function makeAssetNames_(_fileNames) {
          var res = [];
          var iEnd = _fileNames.length;

          for (var i = 0; i < iEnd; ++i) {
            // アセット名は拡張子を除いたファイル名
            var name_1 = _fileNames[i].split(".")[0];

            res[res.length] = name_1; // console.log("makeAssetNames: res["+(res.length-1)+"]:"+res[res.length-1]+".");

            if (name_1.indexOf("sk_") === 0) {
              // スキンアセット名からプリフィクスを除いたものを
              // イメージアセット名とする
              res[res.length] = name_1.substr(3);
            }
          }

          return res;
        }
        /**
         * アニメ名に対応するボーン名のテーブルを生成する
         * @param _combinationInfos ボーン名に対するアニメ名の対応情報
         * @return キーをアニメ名、値をボーン名としたマップ
         * @private
         */


        function makeAnimBoneTable_(_combinationInfos) {
          var res = {};
          var iEnd = _combinationInfos.length;

          for (var i = 0; i < iEnd; ++i) {
            var info = _combinationInfos[i];
            var bnName = info.boneName;
            var anNames = info.animationNames;
            var jEnd = anNames.length;

            for (var j = 0; j < jEnd; ++j) {
              res[anNames[j]] = bnName; // console.log("makeAnimBoneTable: anNames["+j+"]:"+anNames[j]+", bnName:"+bnName+".");
            }
          }

          return res;
        }
        /**
         * asapjファイルからアニメ名に対応するボーン名のテーブルを生成する
         * @param _pjName asapjファイルのアセット名
         * @param _assets アセットのマップ
         * @return キーをアニメ名、値をボーン名としたマップ
         * @private
         */


        function loadAnimBoneTable_(_pjName, _assets) {
          // g.game.logger.debug("AsaEx.loadAnimBoneTable: pjName:"+pjName+".");
          if (!_assets[_pjName]) {
            g.game.logger.error("AsaEx.loadAnimBoneTable: not found asapj:" + _pjName + " in assets.");
            return null;
          }

          var res = null;
          var pjJson = _assets[_pjName].data;
          var pjData = JSON.parse(pjJson);

          if (!!pjData.contents.userData && !!pjData.contents.userData.combinationInfo) {
            res = makeAnimBoneTable_(pjData.contents.userData.combinationInfo);
          } else {
            g.game.logger.error("AsaEx.loadAnimBoneTable: not found combinationInfo in " + _pjName + ". Use -c option with ss2asa.");
          }

          return res;
        }
      })(asaEx = exports.asaEx || (exports.asaEx = {})); // vvv akashic-animation/lib/Actor.js より引用


      function setupColliderForCell_(_info, _bone) {
        var collider;

        switch (_info.boundType) {
          case "aabb":
          case "box":
            collider = new asa.BoneCellCollider(_bone.name, _info.boundType === "aabb");
            break;

          default:
            g.game.logger.warn("Invalid type combination: " + _info.geometryType + ", " + _info.boundType);
            break;
        }

        return collider;
      }

      function setupColliderForCircle_(_info, _bone) {
        var collider;

        switch (_info.boundType) {
          case "aabb":
          case "circle":
            collider = new asa.CircleCollider(_bone.name, _info.boundType === "aabb", _info.scaleOption);
            break;

          default:
            g.game.logger.warn("Invalid type combination: " + _info.geometryType + ", " + _info.boundType);
            break;
        }

        return collider;
      }

      function setupCollider_(_bones, _actor) {
        _bones.forEach(function (_bone) {
          if (!_bone.colliderInfos) {
            return;
          }

          _bone.colliderInfos.forEach(function (_info) {
            var collider;

            switch (_info.geometryType) {
              case "cell":
                collider = setupColliderForCell_(_info, _bone);
                break;

              case "circle":
                collider = setupColliderForCircle_(_info, _bone);
                break;

              case "box":
                g.game.logger.warn("Not implemented geometory type " + _info.geometryType);
                break;

              default:
                g.game.logger.warn("Unknown geometory type " + _info.geometryType);
                break;
            }

            if (collider) {
              _actor.addCollider(collider);
            }
          });
        });
      } // ^^^ akashic-animation/lib/Actor.js より引用

    }, {
      "@akashic-extension/akashic-animation": 25
    }],
    60: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 音声関連のユーティリティ関数群
       */

      var audioUtil;

      (function (audioUtil) {
        /** 再生中の音声管理情報リスト */
        var playingAudioInfoList = [];
        /** ミュートフラグ */

        var muted = false;
        /**
         * SoundInfoTypeのマップからアセット名を配列に追加する
         * @param _map      SoundInfoTypeのマップ
         * @param _assetIds アセット名配列
         */

        function addAssetIdsFromSoundInfoMap(_map, _assetIds) {
          var checkServer = g.game.vars.hasOwnProperty("isServer");
          var isServer = checkServer ? g.game.vars.isServer : false;
          var isServerStr = isServer ? "true" : "false";
          Object.keys(_map).forEach(function (i) {
            var info = _map[i];

            if (checkServer && info.hasOwnProperty("isServer") && isServerStr !== info["isServer"]) {
              return;
            }

            Object.keys(info).forEach(function (j) {
              if (j === "isServer") return;
              var assetId = info[j];
              if (!assetId) return;
              _assetIds[_assetIds.length] = assetId;
            });
          });
        }

        audioUtil.addAssetIdsFromSoundInfoMap = addAssetIdsFromSoundInfoMap;
        /**
         * ミュートフラグを設定するメソッド
         * @param _mute 設定する値
         */

        function setMute(_mute) {
          muted = _mute;
        }

        audioUtil.setMute = setMute;
        /**
         * ミュート状態を取得するメソッド
         * @return ミュート中ならtrue
         */

        function isMuted() {
          return muted;
        }

        audioUtil.isMuted = isMuted;
        /**
         * 指定した音声アセットの g.AudioAsset#inUse を呼ぶ
         * @param _soundId   対象の音声アセット名
         * @param opt_assets (optional)g.Assetのマップ
         * （省略時はg.game.scene().assetsを使用する）
         * @return           inUseの戻り値
         */

        function inUse(_soundId, opt_assets) {
          if (!_soundId) {
            return false;
          }

          if (!opt_assets) {
            opt_assets = g.game.scene().assets;
          }

          var asset = opt_assets[_soundId];

          if (!asset) {
            g.game.logger.error("AudioUtil.inUse: not found " + _soundId + " in opt_assets.");
            return false;
          }

          return asset.inUse();
        }

        audioUtil.inUse = inUse;
        /**
         * 指定した音声アセットの g.AudioAsset#play を呼ぶ
         * @param _soundId   対象の音声アセット名
         * @param opt_assets (optional)g.Assetのマップ
         * （省略時はg.game.scene().assetsを使用する）
         * @return            playの戻り値
         */

        function play(_soundId, opt_assets) {
          if (muted) {
            return null;
          }

          if (!_soundId) {
            return null;
          }

          if (!opt_assets) {
            opt_assets = g.game.scene().assets;
          }

          var asset = opt_assets[_soundId];

          if (!asset) {
            g.game.logger.error("AudioUtil.play: not found " + _soundId + " in opt_assets.");
            return null;
          }

          var info = getPlayingAudioInfo(asset);

          if (info === null) {
            playingAudioInfoList.push({
              audioAsset: asset,
              lastPlayStartTime: Date.now()
            });
          } else {
            info.lastPlayStartTime = Date.now();
          }

          return asset.play();
        }

        audioUtil.play = play;
        /**
         * 指定した音声アセットの g.AudioAsset#stop を呼ぶ
         * @param _soundId   対象の音声アセット名
         * @param opt_assets (optional)g.Assetのマップ
         * （省略時はg.game.scene().assetsを使用する）
         */

        function stop(_soundId, opt_assets) {
          if (!_soundId) {
            return;
          }

          if (!opt_assets) {
            opt_assets = g.game.scene().assets;
          }

          var asset = opt_assets[_soundId];

          if (!asset) {
            g.game.logger.error("AudioUtil.stop: not found " + _soundId + " in opt_assets.");
            return;
          }

          var info = getPlayingAudioInfo(asset);

          if (info !== null) {
            info.lastPlayStartTime = Date.now() - getDuration(_soundId) - 1; // 終了している時間に調整
          }

          asset.stop();
        }

        audioUtil.stop = stop;
        /**
         * 指定した音声アセットの 再生時間を取得するメソッド
         * @param _soundId   対象の音声アセット名
         * @param opt_assets (optional)g.Assetのマップ
         * （省略時はg.game.scene().assetsを使用する）
         * @return           再生時間
         */

        function getDuration(_soundId, opt_assets) {
          if (!_soundId) {
            return 0;
          }

          if (!opt_assets) {
            opt_assets = g.game.scene().assets;
          }

          var asset = opt_assets[_soundId];

          if (!asset) {
            g.game.logger.error("AudioUtil.getDuration: not found " + _soundId + " in opt_assets.");
            return 0;
          }

          return asset.duration;
        }

        audioUtil.getDuration = getDuration;
        /**
         * 音声アセットが再生中かどうか判定する
         * SEのようなループさせない音声に対しての使用を想定しており、
         * BGMのようなループする音声に対する使用は非推奨
         * @param _soundId   対象の音声アセット名
         * @param opt_assets (optional)g.Assetのマップ
         * @return           再生中ならtrue
         */

        function isPlaying(_soundId, opt_assets) {
          if (!_soundId) {
            return false;
          }

          if (!opt_assets) {
            opt_assets = g.game.scene().assets;
          }

          var asset = opt_assets[_soundId];

          if (!asset) {
            g.game.logger.error("AudioUtil.isPlaying: not found " + _soundId + " in opt_assets.");
            return false;
          }

          var info = getPlayingAudioInfo(asset);

          if (info === null) {
            return false;
          } else {
            return getDuration(_soundId) > Date.now() - info.lastPlayStartTime;
          }
        }

        audioUtil.isPlaying = isPlaying;
        /**
         * 再生中の音声管理情報を取得
         * @param  _asset 対象の音声アセット
         * @return        リストにない場合はnullを返す
         */

        function getPlayingAudioInfo(_asset) {
          var list = playingAudioInfoList.filter(function (v) {
            return v.audioAsset === _asset;
          });

          if (list.length > 0) {
            return list[0];
          }

          return null;
        }
      })(audioUtil = exports.audioUtil || (exports.audioUtil = {}));
    }, {}],
    61: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * g.Eとそのサブクラス（g.Spriteを除く）を扱うユーティリティ関数群
       */

      var entityUtil;

      (function (entityUtil) {
        /**
         * Entityのappendとmodifiedを行う
         * @param _entity addend対象のエンティティ
         * @param _parent addend先のエンティティ
         */
        function appendEntity(_entity, _parent) {
          _parent.append(_entity);

          _entity.modified();
        }

        entityUtil.appendEntity = appendEntity;
        /**
         * Entityのhideとmodifiedを行う
         * @param _entity 処理対象のEntity
         */

        function hideEntity(_entity) {
          _entity.hide();

          _entity.modified();
        }

        entityUtil.hideEntity = hideEntity;
        /**
         * Entityのshowとmodifiedを行う
         * @param _entity 処理対象のEntity
         */

        function showEntity(_entity) {
          _entity.show();

          _entity.modified();
        }

        entityUtil.showEntity = showEntity;
        /**
         * Entityのx/yの設定とmodifiedを行う
         * @param _entity 処理対象のEntity
         * @param _x      設定するx座標
         * @param _y      設定するy座標
         */

        function setXY(_entity, _x, _y) {
          _entity.x = _x;
          _entity.y = _y;

          _entity.modified();
        }

        entityUtil.setXY = setXY;
        /**
         * Entityのxの設定とmodifiedを行う
         * @param _entity 処理対象のEntity
         * @param _x      設定するx座標
         */

        function setX(_entity, _x) {
          _entity.x = _x;

          _entity.modified();
        }

        entityUtil.setX = setX;
        /**
         * Entityのyの設定とmodifiedを行う
         * @param _entity 処理対象のEntity
         * @param _y      設定するy座標
         */

        function setY(_entity, _y) {
          _entity.y = _y;

          _entity.modified();
        }

        entityUtil.setY = setY;
        /**
         * Entityのopacityの設定とmodifiedを行う
         * @param _entity 処理対象のEntity
         * @param _opacity 設定する値
         */

        function setOpacity(_entity, _opacity) {
          _entity.opacity = _opacity;

          _entity.modified();
        }

        entityUtil.setOpacity = setOpacity;
        /**
         * EntityのscaleX/scaleYの設定とmodifiedを行う
         * @param _entity 処理対象のEntity
         * @param _scale  設定する値
         */

        function setScale(_entity, _scale) {
          _entity.scaleX = _scale;
          _entity.scaleY = _scale;

          _entity.modified();
        }

        entityUtil.setScale = setScale;
        /**
         * Labelの生成とaligning、fontSizeの設定を行う
         * @param  _scene      Labelの生成に使用するScene
         * @param  _text       Labelに初期設定する文字列
         * @param  _bitmapFont 使用するBitmapFont
         * @param  _maxLength  想定する桁数
         * @param  _align      設定するTextAlign
         * @return             生成したLabel
         */

        function createLabel(_scene, _text, _bitmapFont, _maxLength, _align) {
          var label = new g.Label({
            scene: _scene,
            text: _text,
            bitmapFont: _bitmapFont,
            fontSize: _bitmapFont.defaultGlyphHeight
          });
          label.aligning(_bitmapFont.defaultGlyphWidth * _maxLength, _align);
          label.invalidate();
          return label;
        }

        entityUtil.createLabel = createLabel;
        /**
         * 数字用のcreateLabelのショートハンド
         * _textは桁数分の9埋め文字列、_alignはRightに設定する。
         * @param  _scene      Labelの生成に使用するScene
         * @param  _bitmapFont 使用するBitmapFont
         * @param  _digit      想定する桁数
         * @return             生成したLabel
         */

        function createNumLabel(_scene, _bitmapFont, _digit) {
          var nums = [];

          for (var i = 0; i < _digit; ++i) {
            nums[nums.length] = "9";
          }

          var text = nums.join("");
          var label = createLabel(_scene, text, _bitmapFont, _digit, g.TextAlign.Right);
          return label;
        }

        entityUtil.createNumLabel = createNumLabel;
        /**
         * 右端の数字の左上を指定してラベルの位置を設定するメソッド
         * @param  _label 処理対象のLabel
         * @param  _x     右端の数字の左上のx座標
         * @param  _y     右端の数字の左上のy座標
         */

        function moveNumLabelTo(_label, _x, _y) {
          _label.x = _x + _label.bitmapFont.defaultGlyphWidth - _label.width;
          _label.y = _y;

          _label.modified();
        }

        entityUtil.moveNumLabelTo = moveNumLabelTo;
        /**
         * Label.textの設定とinvalidateを行う
         * @param _label 処理対象のLabel
         * @param _text  設定する文字列
         */

        function setLabelText(_label, _text) {
          _label.text = _text;

          _label.invalidate();
        }

        entityUtil.setLabelText = setLabelText;
        /**
         * Entityの子要素を全てdestroyする
         * @param _e 処理対象のE
         */

        function destroyAllChildren(_e) {
          if (!_e.children) return; // Childrenが未定義であれば何もしない

          var end = _e.children.length - 1;

          for (var i = end; i >= 0; --i) {
            if (!_e.children[i].destroyed()) {
              _e.children[i].destroy();
            }
          }
        }

        entityUtil.destroyAllChildren = destroyAllChildren;
      })(entityUtil = exports.entityUtil || (exports.entityUtil = {}));
    }, {}],
    62: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /** 0のキャラクターコード */

      exports.CHAR_CODE_0 = 48;
      /** 9のキャラクターコード+1 */

      exports.CHAR_CODE_10 = 58;
      /**
       * ゲームから利用するユーティリティ関数群
       */

      var gameUtil;

      (function (gameUtil) {
        /**
         * MiscAssetInfoTypeのマップからアセット名を配列に追加する
         * @param _map      MiscAssetInfoTypeのマップ
         * @param _assetIds アセット名配列
         */
        function addAssetIdsFromMiscAssetInfoMap(_map, _assetIds) {
          var checkServer = g.game.vars.hasOwnProperty("isServer");
          var isServer = checkServer ? g.game.vars.isServer : false;
          Object.keys(_map).forEach(function (i) {
            var info = _map[i];

            if (checkServer && info.hasOwnProperty("isServer") && isServer !== info.isServer) {
              return;
            }

            _assetIds[_assetIds.length] = info.name;
          });
        }

        gameUtil.addAssetIdsFromMiscAssetInfoMap = addAssetIdsFromMiscAssetInfoMap;
        /**
         * マップオブジェクトの要素の配列を生成する
         * @param _map マップオブジェクト
         * @return     要素の配列
         */

        function getArrayFromMap(_map) {
          var array = [];
          Object.keys(_map).forEach(function (i) {
            array[array.length] = _map[i];
          });
          return array;
        }

        gameUtil.getArrayFromMap = getArrayFromMap;
        /**
         * 与えられたパラメータでBitmapFont生成用のGlyphAreaのマップを生成する
         * @param _charWidth     文字の幅
         * @param _charHeight    文字の高さ
         * @param _charsInRow    1行の文字数
         * @param _charCodeStart 文字コードの開始値
         * @param _charCodeEnd   文字コードの終了値+1
         * @return               GlyphAreaのマップ
         */

        function makeGlyphMap(_charWidth, _charHeight, _charsInRow, _charCodeStart, charCodeEnd) {
          var map = {};

          for (var i = 0; i < charCodeEnd - _charCodeStart; ++i) {
            map[i + _charCodeStart] = {
              x: i % _charsInRow * _charWidth,
              y: Math.floor(i / _charsInRow) * _charHeight
            };
          }

          return map;
        }

        gameUtil.makeGlyphMap = makeGlyphMap;
        /**
         * スプライトシートのjsonとフレーム名配列からBitmapFont生成用の
         * GlyphAreaのマップを生成する
         * @param _charCodeStart 文字コードの開始値
         * @param _charCodeEnd   文字コードの終了値+1
         * @param _json          スプライトシートのjson
         * @param _frames        フレーム名配列
         * @return               GlyphAreaのマップ
         */

        function makeGlyphMapFromFrames(_charCodeStart, _charCodeEnd, _json, _frames) {
          var map = {};

          for (var i = 0; i < _charCodeEnd - _charCodeStart; ++i) {
            var frame = _json.frames[_frames[i]].frame;
            map[i + _charCodeStart] = {
              x: frame.x,
              y: frame.y,
              width: frame.w,
              height: frame.h
            };
          }

          return map;
        }

        gameUtil.makeGlyphMapFromFrames = makeGlyphMapFromFrames;
        /**
         * GlyphAreaのマップに1文字分の情報を追加する
         * @param _oneChar   追加する文字
         * @param _json      スプライトシートのjson
         * @param _frameName フレーム名
         * @param _map       GlyphAreaのマップ
         */

        function addOneGlyphMapFromFrame(_oneChar, _json, _frameName, _map) {
          var frame = _json.frames[_frameName].frame;
          _map[_oneChar.charCodeAt(0)] = {
            x: frame.x,
            y: frame.y,
            width: frame.w,
            height: frame.h
          };
        }

        gameUtil.addOneGlyphMapFromFrame = addOneGlyphMapFromFrame;
        /**
         * AssetInfoの情報からBitmapFontを生成する
         * @param _info   アセット情報
         * @param _assets (optional)g.Assetのマップ
         * （省略時はg.game.scene().assetsを使用する）
         * @return         生成したBitmapFont
         */

        function createNumFontWithAssetInfo(_info, opt_assets) {
          if (!opt_assets) {
            opt_assets = g.game.scene().assets;
          }

          var frameMap = JSON.parse(opt_assets[_info.json].data);
          var glyphMap = gameUtil.makeGlyphMapFromFrames(exports.CHAR_CODE_0, exports.CHAR_CODE_10, frameMap, _info.numFrames);

          if (_info.nonnumFrames) {
            var iEnd = _info.nonnumFrames.length;

            for (var i = 0; i < iEnd; ++i) {
              var oneChar = _info.nonnumFrames[i];
              addOneGlyphMapFromFrame(oneChar.char, frameMap, oneChar.frame, glyphMap);
            }
          }

          var missingGlyph;

          if (_info.missing) {
            var frame = frameMap.frames[_info.missing].frame;
            missingGlyph = {
              x: frame.x,
              y: frame.y,
              width: frame.w,
              height: frame.h
            };
          }

          var font = new g.BitmapFont(opt_assets[_info.img], glyphMap, _info.fontWidth, _info.fontHeight, missingGlyph);
          return font;
        }

        gameUtil.createNumFontWithAssetInfo = createNumFontWithAssetInfo;
        /**
         * tl.Timeline#createのショートハンド
         * @param  _timeline Timelineインスタンス
         * @param  _entity   Tweenの生成用エンティティ
         * @return           生成されたTween
         */

        function createTween(_timeline, _entity) {
          return _timeline.create(_entity, {
            modified: _entity.modified,
            destroyed: _entity.destroyed
          });
        }

        gameUtil.createTween = createTween;
        /**
         * Matrixのdx項を返すメソッド
         * @param  _matrix Matrixインスタンス
         * @return         dxの値
         */

        function getMatrixDx(_matrix) {
          return _matrix._matrix[4];
        }

        gameUtil.getMatrixDx = getMatrixDx;
        /**
         * Matrixのdy項を返すメソッド
         * @param  _matrix Matrixインスタンス
         * @return         dyの値
         */

        function getMatrixDy(_matrix) {
          return _matrix._matrix[5];
        }

        gameUtil.getMatrixDy = getMatrixDy;
        /**
         * Matrixのdx項を設定するメソッド
         * @param   _matrix Matrixインスタンス
         * @return          設定するdxの値
         */

        function setMatrixDx(_matrix, _dx) {
          _matrix._matrix[4] = _dx;
        }

        gameUtil.setMatrixDx = setMatrixDx;
        /**
         * Matrixのdy項を設定するメソッド
         * @param _matrix Matrixインスタンス
         * @param _dy     設定するdyの値
         */

        function setMatrixDy(_matrix, _dy) {
          _matrix._matrix[5] = _dy;
        }

        gameUtil.setMatrixDy = setMatrixDy;
        /**
         * g.game.vars.gameStateを初期化するメソッド
         */

        function initGameState() {
          var gameState = {
            score: 0,
            isFinished: false
          };
          g.game.vars.gameState = gameState; // console.log("initGameState: gameState.score:" + g.game.vars.gameState.score + ".");
        }

        gameUtil.initGameState = initGameState;
        /**
         * g.game.vars.gameStateのスコアを更新するメソッド
         * @param _score スコア値
         */

        function updateGameStateScore(_score) {
          var gameState = g.game.vars.gameState;

          if (gameState && !gameState.isFinished) {
            gameState.score = _score;
          } // console.log("updateGameStateScore: gameState.score:" + g.game.vars.gameState.score + ".");

        }

        gameUtil.updateGameStateScore = updateGameStateScore;
        /**
         * g.game.vars.scenedataにスコアを保存する
         * @param _score 保存する値
         */

        function setGameScore(_score) {
          g.game.vars.scenedata.gameScore = _score; // console.log("setGameScore: gameScore:" + g.game.vars.scenedata.gameScore + ".");

          g.game.vars.gameState.isFinished = true;
        }

        gameUtil.setGameScore = setGameScore;
        /**
         * g.game.vars.scenedataからスコアを取得する
         * @return 取得した値（setGameScoreされていない場合は0）
         */

        function getGameScore() {
          // console.log("getGameScore: gameScore:"+g.game.vars.scenedata.gameScore+".");
          var score = g.game.vars.scenedata.gameScore;

          if (!score) {
            score = 0;
          }

          return score;
        }

        gameUtil.getGameScore = getGameScore;
        /**
         * フレームから秒へ換算する（小数部あり）
         * @param _frame フレーム数
         * @return 秒数
         */

        function frame2Sec(_frame) {
          return _frame / g.game.fps;
        }

        gameUtil.frame2Sec = frame2Sec;
        /**
         * 秒からフレームへ換算する（小数部あり）
         * @param _seconds 秒数
         * @return フレーム数
         */

        function sec2Frame(_seconds) {
          return _seconds * g.game.fps;
        }

        gameUtil.sec2Frame = sec2Frame;
        /**
         * フレームからミリ秒へ換算する（小数部あり）
         * @param _frame フレーム数
         * @return ミリ秒数
         */

        function frame2MSec(_frame) {
          return _frame * 1000 / g.game.fps;
        }

        gameUtil.frame2MSec = frame2MSec;
        /**
         * ミリ秒からフレームへ換算する（小数部あり）
         * @param _milliseconds ミリ秒数
         * @return フレーム数
         */

        function mSec2Frame(_milliseconds) {
          return _milliseconds / 1000 * g.game.fps;
        }

        gameUtil.mSec2Frame = mSec2Frame;
        /**
         * ゼロ以上で指定した最大値未満のランダムな整数を返す
         * @param _max       最大値
         * @param opt_random (optional)RandomGeneratorインスタンス
         * （省略時はg.game.random[0]を使用する）
         * @return           ランダムな整数
         */

        function getRandomLessThanMax(_max, opt_random) {
          if (!opt_random) {
            opt_random = g.game.random[0];
          }

          return opt_random.get(0, _max * 1000 - 1) / 1000 | 0;
        }

        gameUtil.getRandomLessThanMax = getRandomLessThanMax;
        /**
         * 2つの値と比率から中間値を計算する
         * @param  _min 値1
         * @param  _max 値2
         * @param  _rate 比率
         * @return       比率による中間値
         */

        function blendValue(_min, _max, _rate) {
          return _min + (_max - _min) * _rate;
        }

        gameUtil.blendValue = blendValue;
        /**
         * bからaに向かう2次元ベクトルを求める
         * @param  _a 2次元ベクトル
         * @param  _b 2次元ベクトル
         * @return    bからaへのベクトル
         */

        function vec2Sub(_a, _b) {
          return {
            x: _a.x - _b.x,
            y: _a.y - _b.y
          };
        }

        gameUtil.vec2Sub = vec2Sub;
        /**
         * スカラー倍した2次元ベクトルを求める
         * @param  _a     2次元ベクトル
         * @param  _scale 倍率
         * @return        scale倍した2次元ベクトル
         */

        function vec2Scale(_a, _scale) {
          return {
            x: _a.x * _scale,
            y: _a.y * _scale
          };
        }

        gameUtil.vec2Scale = vec2Scale;
        /**
         * bからaに向かう2次元ベクトルの長さの2乗を求める
         * @param _a 2次元ベクトル
         * @param _b 2次元ベクトル
         * @return   bからaへのベクトルの長さの2乗
         */

        function vec2SubLengthSq(_a, _b) {
          var dx = _a.x - _b.x;
          var dy = _a.y - _b.y;
          return dx * dx + dy * dy;
        }

        gameUtil.vec2SubLengthSq = vec2SubLengthSq;
        /**
         * 2次元ベクトルの長さを求める
         * @param  _a 2次元ベクトル
         * @return    ベクトルの長さ
         */

        function vec2Length(_a) {
          return Math.sqrt(_a.x * _a.x + _a.y * _a.y);
        }

        gameUtil.vec2Length = vec2Length;
        /**
         * 配列をシャッフルして新しい配列を返す
         * @param _array     シャッフルする配列
         * @param opt_random (optional)RandomGeneratorインスタンス
         * （省略時はg.game.random[0]を使用する）
         * @return           シャッフルされた配列
         */

        function shuffle(_array, opt_random) {
          if (!opt_random) {
            opt_random = g.game.random[0];
          }

          var copyArray = _array.slice();

          var m = copyArray.length;
          var t;
          var i;

          while (m) {
            i = getRandomLessThanMax(--m, opt_random);
            t = copyArray[m];
            copyArray[m] = copyArray[i];
            copyArray[i] = t;
          }

          return copyArray;
        }

        gameUtil.shuffle = shuffle;
      })(gameUtil = exports.gameUtil || (exports.gameUtil = {}));
    }, {}],
    63: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var gameUtil_1 = require("./gameUtil");
      /**
       * g.Spriteとasa.Actor関連のユーティリティ関数群
       */


      var spriteUtil;

      (function (spriteUtil) {
        /**
         * フレーム名に対応するフレーム矩形を取得する
         * @param _data スプライトシートのjson
         * @param _key フレーム名
         * @return      フレーム矩形
         */
        function getRectData(_data, _key) {
          var rect = {
            x: _data.frames[_key].frame.x,
            y: _data.frames[_key].frame.y,
            w: _data.frames[_key].frame.w,
            h: _data.frames[_key].frame.h
          };
          return rect;
        }

        spriteUtil.getRectData = getRectData;
        /**
         * スプライトシートのjsonとフレーム名からSpriteのパラメータを設定する
         * @param _jsonData  スプライトシートのjson
         * @param _frameName フレーム名
         * @param _sprite    対象のSprite
         */

        function setSpriteFrame(_jsonData, _frameName, _sprite) {
          var rect = getRectData(_jsonData, _frameName);
          _sprite.srcX = rect.x;
          _sprite.srcY = rect.y;
          _sprite.srcWidth = rect.w;
          _sprite.srcHeight = rect.h;
          _sprite.width = rect.w;
          _sprite.height = rect.h;

          _sprite.invalidate();
        }

        spriteUtil.setSpriteFrame = setSpriteFrame;
        /**
         * Spriteの生成とsetSpriteFrameを行う
         * @param _spriteOption Sprite生成用パラメータ
         * @param _jsonData     スプライトシートのjson
         * @param _frameName    フレーム名
         * @return              生成したSprite
         */

        function createFrameSprite(_spriteOption, _jsonData, _frameName) {
          var sprite = new g.Sprite(_spriteOption);
          setSpriteFrame(_jsonData, _frameName, sprite);
          return sprite;
        }

        spriteUtil.createFrameSprite = createFrameSprite;
        /**
         * AssetInfoの情報からSpriteParameterObjectを生成する
         * @param _info     アセット情報
         * @param opt_scene (optional)g.Sceneインスタンス
         * （省略時はg.game.scene()を使用する）
         * @return          生成したSpriteParameterObject
         */

        function createSpriteParameter(_info, opt_scene) {
          if (!opt_scene) {
            opt_scene = g.game.scene();
          }

          var spriteParam = {
            scene: opt_scene,
            src: opt_scene.assets[_info.img]
          };
          return spriteParam;
        }

        spriteUtil.createSpriteParameter = createSpriteParameter;
        /**
         * AssetInfoの情報からSpriteFrameMapを生成する
         * @param _info      アセット情報
         * @param opt_assets (optional)g.Assetのマップ
         * （省略時はg.game.scene().assetsを使用する）
         * @return           生成したSpriteFrameMap
         */

        function createSpriteFrameMap(_info, opt_assets) {
          if (!opt_assets) {
            opt_assets = g.game.scene().assets;
          }

          var frameMap = JSON.parse(opt_assets[_info.json].data);
          return frameMap;
        }

        spriteUtil.createSpriteFrameMap = createSpriteFrameMap;
        /**
         * スプライトの画像だけ変更
         * @param _sprite 変更したいスプライトオブジェクト
         * @param _asset この画像に変更したい
         */

        function changeSpriteSurface(_sprite, _asset) {
          _sprite.surface = _asset.asSurface();

          _sprite.invalidate();
        }

        spriteUtil.changeSpriteSurface = changeSpriteSurface;
        /**
         * asa.Actorをmodify/calcする関数を返す
         * @param _actor 対象のasa.Actor
         * @return       modify/calcする関数
         */

        function makeActorUpdater(_actor) {
          return function () {
            if (_actor.visible() && !_actor.pause) {
              _actor.modified();

              _actor.calc();
            }
          };
        }

        spriteUtil.makeActorUpdater = makeActorUpdater;
        /**
         * asa.Actorを指定時間modify/calcしてdestroyする
         * @param _timeline      tl.Timelineインスタンス
         * @param _actor         対象のasa.Actor
         * @param _frameDuration destroyするまでのフレーム数
         * @param _onFinish      destroyした時点で呼ばれる関数
         * @return               tl.Tweenインスタンス
         */

        function setDelayDestroy(_timeline, _actor, _frameDuration, _onFinish) {
          var fps = _timeline._scene.game.fps;
          return gameUtil_1.gameUtil.createTween(_timeline, _actor).every(function (e, p) {
            _actor.modified();

            _actor.calc();
          }, _frameDuration * 1000 / fps).call(function () {
            _actor.destroy();

            if (!!_onFinish) {
              _onFinish();
            }
          });
        }

        spriteUtil.setDelayDestroy = setDelayDestroy;
        /**
         * AssetInfoTypeのマップからアセット名を配列に追加する
         * @param _map      AssetInfoTypeのマップ
         * @param _assetIds アセット名配列
         */

        function addAssetIdsFromAssetInfoMap(_map, _assetIds) {
          var checkServer = g.game.vars.hasOwnProperty("isServer");
          var isServer = checkServer ? g.game.vars.isServer : false;
          Object.keys(_map).forEach(function (i) {
            var info = _map[i];

            if (checkServer && info.hasOwnProperty("isServer") && isServer !== info.isServer) {
              return;
            }

            _assetIds[_assetIds.length] = info.img;
            if (!info.json) return;
            _assetIds[_assetIds.length] = info.json;
          });
        }

        spriteUtil.addAssetIdsFromAssetInfoMap = addAssetIdsFromAssetInfoMap;
        /**
         * AsaInfoTypeのマップからasapj名の配列を生成する
         * @param  _map AsaInfoTypeのマップ
         * @return      asapj名の配列
         */

        function getPjNamesFromAsainfoMap(_map) {
          var checkServer = g.game.vars.hasOwnProperty("isServer");
          var isServer = checkServer ? g.game.vars.isServer : false;
          var array = [];
          Object.keys(_map).forEach(function (i) {
            var info = _map[i];

            if (checkServer && info.hasOwnProperty("isServer") && isServer !== info.isServer) {
              return;
            }

            array[array.length] = info.pj;
          });
          return array;
        }

        spriteUtil.getPjNamesFromAsainfoMap = getPjNamesFromAsainfoMap;
      })(spriteUtil = exports.spriteUtil || (exports.spriteUtil = {}));
    }, {
      "./gameUtil": 62
    }],
    64: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * Tiledのデータを扱うユーティリティ関数群
       */

      var tiledUtil;

      (function (tiledUtil) {
        /** TileMap#orientationの値：orthogonal */
        tiledUtil.ORIENTATION_ORTHOGONAL = "orthogonal";
        /** TileMap#orientationの値：isometric */

        tiledUtil.ORIENTATION_ISOMETRIC = "isometric";
        /** TileMap#orientationの値：staggered */

        tiledUtil.ORIENTATION_STAGGERED = "staggered";
        /** TileMap#renderorderの値：right-down */

        tiledUtil.RENDERORDER_RIGHT_DOWN = "right-down";
        /** LayerFormat#typeの値：tilelayer */

        tiledUtil.LAYERTYPE_TILELAYER = "tilelayer";
        /** LayerFormat#typeの値：objectgroup */

        tiledUtil.LAYERTYPE_OBJECTGROUP = "objectgroup";
        /** LayerFormat#typeの値：imagelayer */

        tiledUtil.LAYERTYPE_IMAGELAYER = "imagelayer";
        /**
         * jsonからMapオブジェクトを生成する
         * @param _mapJsonName jsonアセット名
         * @param opt_assets   (optional)g.Assetのマップ
         * （省略時はg.game.scene().assetsを使用する）
         * @return             生成したMapオブジェクト
         */

        function loadMapdata(_mapJsonName, opt_assets) {
          if (!opt_assets) {
            opt_assets = g.game.scene().assets;
          } // console.log("loadMapdata: _mapJsonName:"+_mapJsonName+", keys(opt_assets):"+Object.keys(opt_assets).join()+".");


          var map = JSON.parse(opt_assets[_mapJsonName].data);
          return map;
        }

        tiledUtil.loadMapdata = loadMapdata;
        /**
         * jsonからObjectLayerのobjectsを取得する
         * @param _mapJsonName        jsonアセット名
         * @param opt_assets          (optional)g.Assetのマップ
         * （省略時はg.game.scene().assetsを使用する）
         * @param opt_enableOffset    (optional)オブジェクトレイヤーのオフセットx,yを反映する
         *  (省略時はオフセットx,yを反映しない)
         * @param opt_useLayerVisible (optional)オブジェクトレイヤーのvisibleフラグを判定する
         *  (省略時はvisibleフラグを判定しない)
         * @return                    生成したMapオブジェクト
         */

        function getObjects(_mapJsonName, opt_assets, opt_enableOffset, opt_useLayerVisible) {
          if (opt_enableOffset === void 0) {
            opt_enableOffset = false;
          }

          if (opt_useLayerVisible === void 0) {
            opt_useLayerVisible = false;
          }

          var map = loadMapdata(_mapJsonName, opt_assets);
          var layers = map.layers;
          var iEnd = layers.length;
          var resAry = [];

          var _loop_1 = function _loop_1(i) {
            if (opt_useLayerVisible && !layers[i].visible) {
              return "continue";
            }

            if (layers[i].type === tiledUtil.LAYERTYPE_OBJECTGROUP) {
              // オブジェクトレイヤーのオフセットを反映する場合
              if (opt_enableOffset) {
                // オフセットが0,0の場合JSONに書き出されない為undefinedなら無効とする
                if (layers[i].offsetx !== undefined && layers[i].offsety !== undefined) {
                  layers[i].objects.forEach(function (item) {
                    item.x += layers[i].offsetx;
                    item.y += layers[i].offsety;
                  });
                }
              } // オブジェクトレイヤーの中身を連結する


              resAry = resAry.concat(layers[i].objects);
            }
          };

          for (var i = 0; i < iEnd; ++i) {
            _loop_1(i);
          }

          return resAry;
        }

        tiledUtil.getObjects = getObjects;
        /**
         * jsonからObjectLayerのobjectsを2次元配列で取得する
         * @param _mapJsonName jsonアセット名
         * @param opt_assets (optional)g.Assetのマップ
         * （省略時はg.game.scene().assetsを使用する）
         * @return           生成したMapオブジェクト
         */

        function getObjects2Array(_mapJsonName, opt_assets) {
          var resObjAry = [];
          var map = loadMapdata(_mapJsonName, opt_assets);
          var layers = map.layers;
          var iEnd = layers.length;

          for (var i = 0; i < iEnd; ++i) {
            if (layers[i].type === tiledUtil.LAYERTYPE_OBJECTGROUP) {
              resObjAry.push(layers[i].objects);
            }
          }

          return resObjAry;
        }

        tiledUtil.getObjects2Array = getObjects2Array;
      })(tiledUtil = exports.tiledUtil || (exports.tiledUtil = {}));
    }, {}]
  }, {}, [58])(58);
});